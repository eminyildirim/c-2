﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormEkleme
{
    public partial class Form3 : Form
    {
        String a1, b1;
        public Form3(String aa,String bb)
        {
            a1 = aa;
            b1 = bb;
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
