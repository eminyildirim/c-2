﻿namespace DERS1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lsonuc = new System.Windows.Forms.Label();
            this.b1 = new System.Windows.Forms.Button();
            this.b2 = new System.Windows.Forms.Button();
            this.b3 = new System.Windows.Forms.Button();
            this.b6 = new System.Windows.Forms.Button();
            this.b5 = new System.Windows.Forms.Button();
            this.b4 = new System.Windows.Forms.Button();
            this.b9 = new System.Windows.Forms.Button();
            this.b8 = new System.Windows.Forms.Button();
            this.b7 = new System.Windows.Forms.Button();
            this.bvirgul = new System.Windows.Forms.Button();
            this.b0 = new System.Windows.Forms.Button();
            this.bae = new System.Windows.Forms.Button();
            this.besit = new System.Windows.Forms.Button();
            this.bcarp = new System.Windows.Forms.Button();
            this.beksi = new System.Windows.Forms.Button();
            this.barti = new System.Windows.Forms.Button();
            this.tbcoklu = new System.Windows.Forms.TextBox();
            this.tbgirilen = new System.Windows.Forms.TextBox();
            this.bbol = new System.Windows.Forms.Button();
            this.bgeri = new System.Windows.Forms.Button();
            this.btumsil = new System.Windows.Forms.Button();
            this.bsil = new System.Windows.Forms.Button();
            this.fileSystemWatcher1 = new System.IO.FileSystemWatcher();
            this.b1x = new System.Windows.Forms.Button();
            this.bkok = new System.Windows.Forms.Button();
            this.byuzde = new System.Windows.Forms.Button();
            this.bkare = new System.Windows.Forms.Button();
            this.tbsonuc = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).BeginInit();
            this.SuspendLayout();
            // 
            // lsonuc
            // 
            this.lsonuc.AutoSize = true;
            this.lsonuc.Location = new System.Drawing.Point(132, 114);
            this.lsonuc.Name = "lsonuc";
            this.lsonuc.Size = new System.Drawing.Size(0, 13);
            this.lsonuc.TabIndex = 8;
            // 
            // b1
            // 
            this.b1.Location = new System.Drawing.Point(24, 307);
            this.b1.Name = "b1";
            this.b1.Size = new System.Drawing.Size(40, 23);
            this.b1.TabIndex = 9;
            this.b1.Tag = "1";
            this.b1.Text = "1";
            this.b1.UseVisualStyleBackColor = true;
            this.b1.Click += new System.EventHandler(this.B_Sayilar);
            // 
            // b2
            // 
            this.b2.Location = new System.Drawing.Point(70, 307);
            this.b2.Name = "b2";
            this.b2.Size = new System.Drawing.Size(40, 23);
            this.b2.TabIndex = 10;
            this.b2.Tag = "2";
            this.b2.Text = "2";
            this.b2.UseVisualStyleBackColor = true;
            this.b2.Click += new System.EventHandler(this.B_Sayilar);
            // 
            // b3
            // 
            this.b3.Location = new System.Drawing.Point(116, 307);
            this.b3.Name = "b3";
            this.b3.Size = new System.Drawing.Size(40, 23);
            this.b3.TabIndex = 11;
            this.b3.Tag = "3";
            this.b3.Text = "3";
            this.b3.UseVisualStyleBackColor = true;
            this.b3.Click += new System.EventHandler(this.B_Sayilar);
            // 
            // b6
            // 
            this.b6.Location = new System.Drawing.Point(116, 278);
            this.b6.Name = "b6";
            this.b6.Size = new System.Drawing.Size(40, 23);
            this.b6.TabIndex = 14;
            this.b6.Tag = "6";
            this.b6.Text = "6";
            this.b6.UseVisualStyleBackColor = true;
            this.b6.Click += new System.EventHandler(this.B_Sayilar);
            // 
            // b5
            // 
            this.b5.Location = new System.Drawing.Point(70, 278);
            this.b5.Name = "b5";
            this.b5.Size = new System.Drawing.Size(40, 23);
            this.b5.TabIndex = 13;
            this.b5.Tag = "5";
            this.b5.Text = "5";
            this.b5.UseVisualStyleBackColor = true;
            this.b5.Click += new System.EventHandler(this.B_Sayilar);
            // 
            // b4
            // 
            this.b4.Location = new System.Drawing.Point(24, 278);
            this.b4.Name = "b4";
            this.b4.Size = new System.Drawing.Size(40, 23);
            this.b4.TabIndex = 12;
            this.b4.Tag = "4";
            this.b4.Text = "4";
            this.b4.UseVisualStyleBackColor = true;
            this.b4.Click += new System.EventHandler(this.B_Sayilar);
            // 
            // b9
            // 
            this.b9.Location = new System.Drawing.Point(116, 249);
            this.b9.Name = "b9";
            this.b9.Size = new System.Drawing.Size(40, 23);
            this.b9.TabIndex = 17;
            this.b9.Tag = "9";
            this.b9.Text = "9";
            this.b9.UseVisualStyleBackColor = true;
            this.b9.Click += new System.EventHandler(this.B_Sayilar);
            // 
            // b8
            // 
            this.b8.Location = new System.Drawing.Point(70, 249);
            this.b8.Name = "b8";
            this.b8.Size = new System.Drawing.Size(40, 23);
            this.b8.TabIndex = 16;
            this.b8.Tag = "8";
            this.b8.Text = "8";
            this.b8.UseVisualStyleBackColor = true;
            this.b8.Click += new System.EventHandler(this.B_Sayilar);
            // 
            // b7
            // 
            this.b7.Location = new System.Drawing.Point(24, 249);
            this.b7.Name = "b7";
            this.b7.Size = new System.Drawing.Size(40, 23);
            this.b7.TabIndex = 15;
            this.b7.Tag = "7";
            this.b7.Text = "7";
            this.b7.UseVisualStyleBackColor = true;
            this.b7.Click += new System.EventHandler(this.B_Sayilar);
            // 
            // bvirgul
            // 
            this.bvirgul.Location = new System.Drawing.Point(116, 336);
            this.bvirgul.Name = "bvirgul";
            this.bvirgul.Size = new System.Drawing.Size(40, 23);
            this.bvirgul.TabIndex = 20;
            this.bvirgul.Tag = ",";
            this.bvirgul.Text = ",";
            this.bvirgul.UseVisualStyleBackColor = true;
            // 
            // b0
            // 
            this.b0.Location = new System.Drawing.Point(70, 336);
            this.b0.Name = "b0";
            this.b0.Size = new System.Drawing.Size(40, 23);
            this.b0.TabIndex = 19;
            this.b0.Tag = "0";
            this.b0.Text = "0";
            this.b0.UseVisualStyleBackColor = true;
            this.b0.Click += new System.EventHandler(this.B_Sayilar);
            // 
            // bae
            // 
            this.bae.Location = new System.Drawing.Point(24, 336);
            this.bae.Name = "bae";
            this.bae.Size = new System.Drawing.Size(40, 23);
            this.bae.TabIndex = 18;
            this.bae.Tag = "+-";
            this.bae.Text = "+-";
            this.bae.UseVisualStyleBackColor = true;
            // 
            // besit
            // 
            this.besit.Location = new System.Drawing.Point(162, 336);
            this.besit.Name = "besit";
            this.besit.Size = new System.Drawing.Size(40, 23);
            this.besit.TabIndex = 24;
            this.besit.Tag = "=";
            this.besit.Text = "=";
            this.besit.UseVisualStyleBackColor = true;
            this.besit.Click += new System.EventHandler(this.besit_Click);
            // 
            // bcarp
            // 
            this.bcarp.Location = new System.Drawing.Point(162, 249);
            this.bcarp.Name = "bcarp";
            this.bcarp.Size = new System.Drawing.Size(40, 23);
            this.bcarp.TabIndex = 23;
            this.bcarp.Tag = "*";
            this.bcarp.Text = "*";
            this.bcarp.UseVisualStyleBackColor = true;
            this.bcarp.Click += new System.EventHandler(this.barti_Click);
            // 
            // beksi
            // 
            this.beksi.Location = new System.Drawing.Point(162, 278);
            this.beksi.Name = "beksi";
            this.beksi.Size = new System.Drawing.Size(40, 23);
            this.beksi.TabIndex = 22;
            this.beksi.Tag = "-";
            this.beksi.Text = "-";
            this.beksi.UseVisualStyleBackColor = true;
            this.beksi.Click += new System.EventHandler(this.barti_Click);
            // 
            // barti
            // 
            this.barti.Location = new System.Drawing.Point(162, 307);
            this.barti.Name = "barti";
            this.barti.Size = new System.Drawing.Size(40, 23);
            this.barti.TabIndex = 21;
            this.barti.Tag = "+";
            this.barti.Text = "+";
            this.barti.UseVisualStyleBackColor = true;
            this.barti.Click += new System.EventHandler(this.barti_Click);
            // 
            // tbcoklu
            // 
            this.tbcoklu.Location = new System.Drawing.Point(19, 7);
            this.tbcoklu.Multiline = true;
            this.tbcoklu.Name = "tbcoklu";
            this.tbcoklu.Size = new System.Drawing.Size(193, 136);
            this.tbcoklu.TabIndex = 25;
            // 
            // tbgirilen
            // 
            this.tbgirilen.Location = new System.Drawing.Point(19, 149);
            this.tbgirilen.Name = "tbgirilen";
            this.tbgirilen.Size = new System.Drawing.Size(193, 20);
            this.tbgirilen.TabIndex = 26;
            // 
            // bbol
            // 
            this.bbol.Location = new System.Drawing.Point(162, 218);
            this.bbol.Name = "bbol";
            this.bbol.Size = new System.Drawing.Size(40, 23);
            this.bbol.TabIndex = 30;
            this.bbol.Tag = "/";
            this.bbol.Text = "/";
            this.bbol.UseVisualStyleBackColor = true;
            this.bbol.Click += new System.EventHandler(this.barti_Click);
            // 
            // bgeri
            // 
            this.bgeri.Font = new System.Drawing.Font("Wingdings", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.bgeri.Location = new System.Drawing.Point(116, 218);
            this.bgeri.Name = "bgeri";
            this.bgeri.Size = new System.Drawing.Size(40, 23);
            this.bgeri.TabIndex = 29;
            this.bgeri.Tag = "";
            this.bgeri.Text = "Õ";
            this.bgeri.UseVisualStyleBackColor = true;
            this.bgeri.Click += new System.EventHandler(this.bgeri_Click);
            // 
            // btumsil
            // 
            this.btumsil.Location = new System.Drawing.Point(70, 218);
            this.btumsil.Name = "btumsil";
            this.btumsil.Size = new System.Drawing.Size(40, 23);
            this.btumsil.TabIndex = 28;
            this.btumsil.Tag = "C";
            this.btumsil.Text = "C";
            this.btumsil.UseVisualStyleBackColor = true;
            this.btumsil.Click += new System.EventHandler(this.btumsil_Click);
            // 
            // bsil
            // 
            this.bsil.Location = new System.Drawing.Point(24, 218);
            this.bsil.Name = "bsil";
            this.bsil.Size = new System.Drawing.Size(40, 23);
            this.bsil.TabIndex = 27;
            this.bsil.Tag = "CE";
            this.bsil.Text = "CE";
            this.bsil.UseVisualStyleBackColor = true;
            this.bsil.Click += new System.EventHandler(this.bsil_Click);
            // 
            // fileSystemWatcher1
            // 
            this.fileSystemWatcher1.EnableRaisingEvents = true;
            this.fileSystemWatcher1.SynchronizingObject = this;
            // 
            // b1x
            // 
            this.b1x.Location = new System.Drawing.Point(162, 189);
            this.b1x.Name = "b1x";
            this.b1x.Size = new System.Drawing.Size(40, 23);
            this.b1x.TabIndex = 34;
            this.b1x.Tag = "";
            this.b1x.Text = "1/X";
            this.b1x.UseVisualStyleBackColor = true;
            this.b1x.Click += new System.EventHandler(this.b1x_Click);
            // 
            // bkok
            // 
            this.bkok.Location = new System.Drawing.Point(70, 189);
            this.bkok.Name = "bkok";
            this.bkok.Size = new System.Drawing.Size(40, 23);
            this.bkok.TabIndex = 32;
            this.bkok.Tag = "C";
            this.bkok.Text = "Kök";
            this.bkok.UseVisualStyleBackColor = true;
            this.bkok.Click += new System.EventHandler(this.bkok_Click);
            // 
            // byuzde
            // 
            this.byuzde.Location = new System.Drawing.Point(24, 189);
            this.byuzde.Name = "byuzde";
            this.byuzde.Size = new System.Drawing.Size(40, 23);
            this.byuzde.TabIndex = 31;
            this.byuzde.Tag = "%";
            this.byuzde.Text = "%";
            this.byuzde.UseVisualStyleBackColor = true;
            this.byuzde.Click += new System.EventHandler(this.byuzde_Click);
            // 
            // bkare
            // 
            this.bkare.Location = new System.Drawing.Point(116, 189);
            this.bkare.Name = "bkare";
            this.bkare.Size = new System.Drawing.Size(40, 23);
            this.bkare.TabIndex = 35;
            this.bkare.Tag = "";
            this.bkare.Text = "Kare";
            this.bkare.UseVisualStyleBackColor = true;
            this.bkare.Click += new System.EventHandler(this.bkare_Click);
            // 
            // tbsonuc
            // 
            this.tbsonuc.Location = new System.Drawing.Point(24, 380);
            this.tbsonuc.Name = "tbsonuc";
            this.tbsonuc.Size = new System.Drawing.Size(178, 20);
            this.tbsonuc.TabIndex = 36;
            this.tbsonuc.Visible = false;
            this.tbsonuc.TextChanged += new System.EventHandler(this.tbsonuc_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(237, 433);
            this.Controls.Add(this.tbsonuc);
            this.Controls.Add(this.bkare);
            this.Controls.Add(this.b1x);
            this.Controls.Add(this.bkok);
            this.Controls.Add(this.byuzde);
            this.Controls.Add(this.bbol);
            this.Controls.Add(this.bgeri);
            this.Controls.Add(this.btumsil);
            this.Controls.Add(this.bsil);
            this.Controls.Add(this.tbgirilen);
            this.Controls.Add(this.tbcoklu);
            this.Controls.Add(this.besit);
            this.Controls.Add(this.bcarp);
            this.Controls.Add(this.beksi);
            this.Controls.Add(this.barti);
            this.Controls.Add(this.bvirgul);
            this.Controls.Add(this.b0);
            this.Controls.Add(this.bae);
            this.Controls.Add(this.b9);
            this.Controls.Add(this.b8);
            this.Controls.Add(this.b7);
            this.Controls.Add(this.b6);
            this.Controls.Add(this.b5);
            this.Controls.Add(this.b4);
            this.Controls.Add(this.b3);
            this.Controls.Add(this.b2);
            this.Controls.Add(this.b1);
            this.Controls.Add(this.lsonuc);
            this.Name = "Form1";
            this.Text = "Hesap Makinası";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Shown += new System.EventHandler(this.Form1_Shown);
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lsonuc;
        private System.Windows.Forms.Button b1;
        private System.Windows.Forms.Button b2;
        private System.Windows.Forms.Button b3;
        private System.Windows.Forms.Button b6;
        private System.Windows.Forms.Button b5;
        private System.Windows.Forms.Button b4;
        private System.Windows.Forms.Button b9;
        private System.Windows.Forms.Button b8;
        private System.Windows.Forms.Button b7;
        private System.Windows.Forms.Button bvirgul;
        private System.Windows.Forms.Button b0;
        private System.Windows.Forms.Button bae;
        private System.Windows.Forms.Button besit;
        private System.Windows.Forms.Button bcarp;
        private System.Windows.Forms.Button beksi;
        private System.Windows.Forms.Button barti;
        private System.Windows.Forms.TextBox tbcoklu;
        private System.Windows.Forms.TextBox tbgirilen;
        private System.Windows.Forms.Button bbol;
        private System.Windows.Forms.Button bgeri;
        private System.Windows.Forms.Button btumsil;
        private System.Windows.Forms.Button bsil;
        private System.IO.FileSystemWatcher fileSystemWatcher1;
        private System.Windows.Forms.Button b1x;
        private System.Windows.Forms.Button bkok;
        private System.Windows.Forms.Button byuzde;
        private System.Windows.Forms.Button bkare;
        private System.Windows.Forms.TextBox tbsonuc;
    }
}

