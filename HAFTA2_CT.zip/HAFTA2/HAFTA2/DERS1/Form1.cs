﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DERS1
{
    public partial class Form1 : Form
    {
        Double sonuc;
        Boolean yeni = false;
        String isaret = "";
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_Shown(object sender, EventArgs e)
        {

        }

        private void btntopla_Click(object sender, EventArgs e)
        {
        }
        private void B_Sayilar(object sender, EventArgs e)
        {
            if (yeni)
            {
                tbgirilen.Text = ""; yeni = false;
            }
            tbgirilen.Text = tbgirilen.Text + (sender as Button).Tag.ToString();
            if (tbgirilen.Text == "0") { tbgirilen.Text = ""; }
        }

        private void b1_Click(object sender, EventArgs e)
        {

        }

        private void bsil_Click(object sender, EventArgs e)
        {
            tbgirilen.Text = "";
        }

        private void btumsil_Click(object sender, EventArgs e)
        {
            tbgirilen.Text = "";
            //tbsonuc.Text = "";
            tbcoklu.Text = "";
            sonuc = 0;
            yeni = false;
            isaret = "";
        }

        private void bgeri_Click(object sender, EventArgs e)
        {
            if (tbgirilen.Text != "")
            {
                tbgirilen.Text = tbgirilen.Text.Substring(0, tbgirilen.Text.Length - 1);
            }
        }

        private void barti_Click(object sender, EventArgs e)
        {
            if (!yeni)
            {
                if (tbgirilen.Text != "")
                {
                    Double s = Double.Parse(tbgirilen.Text);
                    switch (isaret)
                    {
                        case "+":
                            {
                                sonuc = sonuc + (Double)s;
                                tbsonuc.Text = sonuc.ToString();
                                break;
                            }
                        case "-":
                            {
                                sonuc = sonuc - (Double)s;
                                tbsonuc.Text = sonuc.ToString();
                                break;
                            }
                        case "*":
                            {
                                sonuc = sonuc * (Double)s;
                                tbsonuc.Text = sonuc.ToString();
                                break;
                            }
                        case "/":
                            {
                                sonuc = sonuc / (Double)s;
                                tbsonuc.Text = sonuc.ToString();
                                break;
                            }
                        default:
                            sonuc = (Double)s;
                            break;
                    }
                    isaret = (sender as Button).Tag.ToString();

                    yeni = true;
                    if (Char.IsNumber(tbgirilen.Text[tbgirilen.Text.Length - 1]))
                    {
                        tbcoklu.Text = tbcoklu.Text + tbgirilen.Text + (sender as Button).Tag.ToString();

                    }
                    tbsonuc.Text = sonuc.ToString();
                }
            }
            else
            {
                isaret = (sender as Button).Tag.ToString();

                if (tbcoklu.Text == "")
                {
                    tbcoklu.Text = tbgirilen.Text;
                }
                tbcoklu.Text = tbcoklu.Text.Substring(0, tbcoklu.Text.Length - 1) + (sender as Button).Tag.ToString();
            }
        }

        private void besit_Click(object sender, EventArgs e)
        {
            if (yeni) { tbgirilen.Text = "0"; yeni = false; }
            Double s = Double.Parse(tbgirilen.Text);
            switch (isaret)
            {
                case "+":
                    {
                        sonuc = sonuc + (Double)s;
                        tbsonuc.Text = sonuc.ToString();
                        break;
                    }
                case "-":
                    {
                        sonuc = sonuc - (Double)s;
                        break;
                    }
                case "*":
                    {
                        sonuc = sonuc * (Double)s;
                        break;
                    }
                case "/":
                    {
                        sonuc = sonuc / (Double)s;

                        break;
                    }
                default:
                    sonuc = (Double)s;
                    break;
            }

            tbcoklu.Text = tbcoklu.Text + tbgirilen.Text;
            tbgirilen.Text = sonuc.ToString();
            yeni = true;

            tbcoklu.Text = "";
            sonuc = 0;

            isaret = "";

        }

        private void bkok_Click(object sender, EventArgs e)
        {
            if (tbgirilen.Text != "")
            {
                Double s = Double.Parse(tbgirilen.Text);
                sonuc = Math.Pow(s, 0.5);
                tbgirilen.Text = sonuc.ToString();
                // yeni = true;
            }
        }

        private void bkare_Click(object sender, EventArgs e)
        {
            if (tbgirilen.Text != "")
            {
                Double s = Double.Parse(tbgirilen.Text);
                sonuc = Math.Pow(s, 2);
                tbgirilen.Text = sonuc.ToString();
                //  yeni = true;
            }

        }

        private void b1x_Click(object sender, EventArgs e)
        {
            if (tbgirilen.Text != "")
            {
                Double s = Double.Parse(tbgirilen.Text);
                s = 1 / s;
                tbgirilen.Text = s.ToString();
                // yeni = true;
            }

        }

        private void tbsonuc_TextChanged(object sender, EventArgs e)
        {

        }

        private void byuzde_Click(object sender, EventArgs e)
        {
            if (tbgirilen.Text != "")
            {
                Double s = Double.Parse(tbgirilen.Text);
                s = sonuc * (s / 100);
                tbgirilen.Text = s.ToString();
                // yeni = true;
            }
        }
    }
}
