﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _02_RadioButton
{
    public partial class Form1 : Form
    {
        private int RBCheckIndex(Control C)
        {
            int k = 0;
            int kontrol = -1;
            foreach (Control item in C.Controls)
            {
                if (item is RadioButton)
                {  k++;
                    RadioButton rb = new RadioButton();
                    rb = item as RadioButton;
                    if (rb.Checked)
                    {                        
                        kontrol=int.Parse(rb.Tag.ToString());
                    }
                }
            }
            return kontrol;
        }

        private int RBListIndex(Control C)
        {
            List<Object> cs = new List<Object>();
            List<int> li = new List<int>();
            int k = 9999;
            int kontrol = -1;
            foreach (Control item in C.Controls)
            {
                if (item is RadioButton)
                {    
                    RadioButton rb = new RadioButton();
                    rb = item as RadioButton;
                    cs.Add(rb);
                }
            }
            foreach (Control item in C.Controls)
            {
                if (item is RadioButton)
                {
                    k++;
                    RadioButton rb = new RadioButton();
                    rb = item as RadioButton;
                    if (rb.Checked)
                    { if(rb.Location.X>k)
                        kontrol = int.Parse(rb.Tag.ToString());
                    }
                }
            }
            return kontrol;
        }

        private String RBCaption(Control C)
        {            
            String  kontrol = "";
            foreach (Control item in C.Controls)
            {
                if (item is RadioButton)
                {
                    RadioButton rb = new RadioButton();
                    rb = item as RadioButton;
                    if (rb.Checked)
                    {
                        kontrol = rb.Text;
                    }
                }
            }
            return kontrol;
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        { 
            foreach (Control item in groupBox1.Controls)
            {
                if (item is RadioButton)
                {
                    RadioButton rb = new RadioButton();
                    rb = item as RadioButton;
                    if (rb.Checked)
                    {
                        rb.PerformClick();
                        MessageBox.Show(rb.Tag.ToString());
                    }
                }
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton10_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show(RBCheckIndex(groupBox1).ToString());
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show(RBCheckIndex(panel1).ToString());
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show(RBCaption(groupBox1));
        }

        private void button5_Click(object sender, EventArgs e)
        {
            MessageBox.Show(RBListIndex(groupBox1).ToString());
        }
    }


    }
