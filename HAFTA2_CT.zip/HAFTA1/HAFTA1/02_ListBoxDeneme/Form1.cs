﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace _02_ListBoxDeneme
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Random rnd = new Random();
            rnd.Next(1000, 9999);
            for (int i = 0; i < 22; i++)
            { int s= rnd.Next(1000, 9999);
                listBox1.Items.Add("kullanici" + i.ToString());
                listBox2.Items.Add(s.ToString());
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            resimsec.Filter = "resim files (*.jpeg)|*.jpeg|resim files (*.jpg)|*.jpg|png files (*.png)|*.png";
            DialogResult result = resimsec.ShowDialog();
            // See if user pressed ok.
            if (result == DialogResult.OK)
            {
                this.resim.Image = new Bitmap(resimsec.OpenFile());

            }
        }

        private void btnbak_Click(object sender, EventArgs e)
        {
            int a=listBox1.Items.IndexOf(tbad.Text);
            // MessageBox.Show(a.ToString());
            if (a>-1)
            {
                if (tbsifre.Text== listBox2.Items[a].ToString())
                {
                    MessageBox.Show("login oldun");
                }
                else
                {
                    MessageBox.Show("şifre hatalı");
                }
                
            }
            else
            {
                MessageBox.Show("Kullanıcı Kayıtlı değil");
            }
        }

        private void listBox1_DoubleClick(object sender, EventArgs e)
        {
            tbad.Text = listBox1.Text;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox2.SelectedIndex = listBox1.SelectedIndex;
            String dosya = listBox1.SelectedIndex.ToString()+".png";
            if (File.Exists(dosya))
            { resim.ImageLocation = dosya;
                btnresim.ImageIndex = listBox1.SelectedIndex;
            }
            if (!File.Exists(dosya)) {
                resim.ImageLocation = "yok.png";
                btnresim.ImageIndex = -1;
            }


        }

        private void listBox2_MouseHover(object sender, EventArgs e)
        { /*
            Point point = listBox2.PointToClient(Cursor.Position);
            int index = listBox2.IndexFromPoint(point);
            if (index < 0) return;
            //Do any action with the item
            listBox2.GetItemRectangle(index).Inflate(1, 2);
*/
            listBox2.Visible = false;
        }

        private void listBox2_MouseLeave(object sender, EventArgs e)
        {
           // listBox2.Visible = true;
        }

        private void btnbak_MouseHover(object sender, EventArgs e)
        {
            btnbak.BackColor = Color.Red;
        }

        private void btnbak_MouseLeave(object sender, EventArgs e)
        {
            btnbak.BackColor = DefaultBackColor;
        }

        private void listBox2_MouseDown(object sender, MouseEventArgs e)
        {
            //listBox2.Visible = false;
        }

        private void listBox2_DragLeave(object sender, EventArgs e)
        {

        }

        private void btnresim_Click(object sender, EventArgs e)
        {
            btnbak.PerformClick();
        }
    }
}
