﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _02_ListBox
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void lbListe1_DoubleClick(object sender, EventArgs e)
        {
            if (lbListe1.SelectedIndex > -1)
            {
                lbliste2.Items.Add(lbListe1.SelectedItem.ToString());
                lbListe1.Items.RemoveAt(lbListe1.SelectedIndex);
            }
        }

        private void lbliste2_DoubleClick(object sender, EventArgs e)
        {
            if (lbliste2.SelectedIndex > -1)
            {
                lbListe1.Items.Add(lbliste2.SelectedItem.ToString());
                lbliste2.Items.RemoveAt(lbliste2.SelectedIndex);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            foreach (int item in lbListe1.SelectedIndices)
            {
               lbliste2.Items.Add(item.ToString()+"-"+lbListe1.Items[item].ToString());

            }
            foreach (int item in lbListe1.SelectedIndices)
            {
                lbListe1.SetSelected(item, false);
                lbListe1.Items.RemoveAt(item);
          
            }
            lbListe1.SelectedIndex = -1;

        }


    private void button2_Click(object sender, EventArgs e)
        {
            for (int x = lbListe1.SelectedIndices.Count - 1; x >= 0; x--)
            {
                int idx = lbListe1.SelectedIndices[x];
                lbliste2.Items.Add(lbListe1.Items[idx]);
                lbListe1.Items.RemoveAt(idx);
            }
        }
    
    }
}
