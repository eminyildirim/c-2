﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _02_Formdemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnarti_Click(object sender, EventArgs e)
        {
            int sayi,p;
            p = Int16.Parse(tbperiod.Text);
            sayi = Int16.Parse(tbsayi.Text) + p;
            if (sayi>100) { sayi = 100; }
            tbsayi.Text = sayi.ToString();
            if (sayi > 99) { btnarti.Enabled = false; }
            if (sayi>0) { btneksi.Enabled = true; }
        }

        private void btneksi_Click(object sender, EventArgs e)
        {
            int sayi,p;
            p = Int16.Parse(tbperiod.Text);
            sayi = Int16.Parse(tbsayi.Text) - p;
            if (sayi < 0) { sayi = 0; }
            tbsayi.Text = sayi.ToString();
            if (sayi < 1) { btneksi.Enabled = false; }
            if (sayi < 100) { btnarti.Enabled = true; }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btneksi.Enabled = false;
        }

        private void tbperiod_TextChanged(object sender, EventArgs e)
        {
            int sayi = 0;
            if (!int.TryParse(tbperiod.Text,out sayi)) { sayi = 1; }
            tbperiod.Text = sayi.ToString();
        }
    }
}
