﻿namespace _01_FormGiris
{
    partial class frmGiris
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbAdi = new System.Windows.Forms.TextBox();
            this.tbSoyadi = new System.Windows.Forms.TextBox();
            this.btnGoster = new System.Windows.Forms.Button();
            this.btnTemizle = new System.Windows.Forms.Button();
            this.renkdialog = new System.Windows.Forms.ColorDialog();
            this.btnRenk = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.fontsecim = new System.Windows.Forms.FontDialog();
            this.btnFontsec = new System.Windows.Forms.Button();
            this.lbAdSoyad = new System.Windows.Forms.ListBox();
            this.btnListeEkle = new System.Windows.Forms.Button();
            this.btnTextKontrol = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(98, 80);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Adı:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(101, 108);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Soyadı";
            // 
            // tbAdi
            // 
            this.tbAdi.Location = new System.Drawing.Point(154, 80);
            this.tbAdi.Name = "tbAdi";
            this.tbAdi.Size = new System.Drawing.Size(247, 22);
            this.tbAdi.TabIndex = 2;
            this.tbAdi.TextChanged += new System.EventHandler(this.tbAdi_TextChanged);
            // 
            // tbSoyadi
            // 
            this.tbSoyadi.Location = new System.Drawing.Point(154, 108);
            this.tbSoyadi.Name = "tbSoyadi";
            this.tbSoyadi.Size = new System.Drawing.Size(247, 22);
            this.tbSoyadi.TabIndex = 3;
            this.tbSoyadi.TextChanged += new System.EventHandler(this.tbSoyadi_TextChanged);
            // 
            // btnGoster
            // 
            this.btnGoster.Location = new System.Drawing.Point(482, 80);
            this.btnGoster.Name = "btnGoster";
            this.btnGoster.Size = new System.Drawing.Size(75, 31);
            this.btnGoster.TabIndex = 4;
            this.btnGoster.Text = "Göster";
            this.btnGoster.UseVisualStyleBackColor = true;
            this.btnGoster.Click += new System.EventHandler(this.btnGoster_Click);
            // 
            // btnTemizle
            // 
            this.btnTemizle.Location = new System.Drawing.Point(563, 80);
            this.btnTemizle.Name = "btnTemizle";
            this.btnTemizle.Size = new System.Drawing.Size(75, 31);
            this.btnTemizle.TabIndex = 5;
            this.btnTemizle.Text = "Temizle";
            this.btnTemizle.UseVisualStyleBackColor = true;
            this.btnTemizle.Click += new System.EventHandler(this.btnTemizle_Click);
            this.btnTemizle.MouseLeave += new System.EventHandler(this.btnTemizle_MouseLeave);
            this.btnTemizle.MouseHover += new System.EventHandler(this.btnTemizle_MouseHover);
            // 
            // btnRenk
            // 
            this.btnRenk.Location = new System.Drawing.Point(154, 193);
            this.btnRenk.Name = "btnRenk";
            this.btnRenk.Size = new System.Drawing.Size(84, 23);
            this.btnRenk.TabIndex = 6;
            this.btnRenk.Text = "Renk Seç";
            this.btnRenk.UseVisualStyleBackColor = true;
            this.btnRenk.Click += new System.EventHandler(this.btnRenk_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioButton4);
            this.groupBox1.Controls.Add(this.radioButton3);
            this.groupBox1.Controls.Add(this.radioButton2);
            this.groupBox1.Controls.Add(this.radioButton1);
            this.groupBox1.Location = new System.Drawing.Point(154, 222);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 200);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Renkler";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(16, 21);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(51, 19);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Mavi";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(16, 47);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(49, 19);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Sarı";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(16, 73);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(52, 19);
            this.radioButton3.TabIndex = 2;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "Yeşil";
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(16, 99);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(68, 19);
            this.radioButton4.TabIndex = 3;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "Kırmızı";
            this.radioButton4.UseVisualStyleBackColor = true;
            this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // btnFontsec
            // 
            this.btnFontsec.Location = new System.Drawing.Point(279, 193);
            this.btnFontsec.Name = "btnFontsec";
            this.btnFontsec.Size = new System.Drawing.Size(75, 23);
            this.btnFontsec.TabIndex = 8;
            this.btnFontsec.Text = "Font Seç";
            this.btnFontsec.UseVisualStyleBackColor = true;
            this.btnFontsec.Click += new System.EventHandler(this.btnFontsec_Click);
            // 
            // lbAdSoyad
            // 
            this.lbAdSoyad.FormattingEnabled = true;
            this.lbAdSoyad.ItemHeight = 15;
            this.lbAdSoyad.Location = new System.Drawing.Point(482, 131);
            this.lbAdSoyad.Name = "lbAdSoyad";
            this.lbAdSoyad.Size = new System.Drawing.Size(269, 274);
            this.lbAdSoyad.TabIndex = 9;
            this.lbAdSoyad.DoubleClick += new System.EventHandler(this.lbAdSoyad_DoubleClick);
            // 
            // btnListeEkle
            // 
            this.btnListeEkle.Location = new System.Drawing.Point(645, 80);
            this.btnListeEkle.Name = "btnListeEkle";
            this.btnListeEkle.Size = new System.Drawing.Size(106, 31);
            this.btnListeEkle.TabIndex = 10;
            this.btnListeEkle.Text = "Listeye Ekle";
            this.btnListeEkle.UseVisualStyleBackColor = true;
            this.btnListeEkle.Click += new System.EventHandler(this.btnListeEkle_Click);
            // 
            // btnTextKontrol
            // 
            this.btnTextKontrol.Location = new System.Drawing.Point(154, 142);
            this.btnTextKontrol.Name = "btnTextKontrol";
            this.btnTextKontrol.Size = new System.Drawing.Size(75, 23);
            this.btnTextKontrol.TabIndex = 11;
            this.btnTextKontrol.Text = "Kontrol";
            this.btnTextKontrol.UseVisualStyleBackColor = true;
            this.btnTextKontrol.Click += new System.EventHandler(this.btnTextKontrol_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(235, 146);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 15);
            this.label3.TabIndex = 12;
            this.label3.Text = "label3";
            // 
            // frmGiris
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Info;
            this.ClientSize = new System.Drawing.Size(829, 454);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnTextKontrol);
            this.Controls.Add(this.btnListeEkle);
            this.Controls.Add(this.lbAdSoyad);
            this.Controls.Add(this.btnFontsec);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnRenk);
            this.Controls.Add(this.btnTemizle);
            this.Controls.Add(this.btnGoster);
            this.Controls.Add(this.tbSoyadi);
            this.Controls.Add(this.tbAdi);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Name = "frmGiris";
            this.Text = "İlk Ders";
            this.Activated += new System.EventHandler(this.frmGiris_Activated);
            this.Load += new System.EventHandler(this.frmGiris_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbAdi;
        private System.Windows.Forms.TextBox tbSoyadi;
        private System.Windows.Forms.Button btnGoster;
        private System.Windows.Forms.Button btnTemizle;
        private System.Windows.Forms.ColorDialog renkdialog;
        private System.Windows.Forms.Button btnRenk;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.FontDialog fontsecim;
        private System.Windows.Forms.Button btnFontsec;
        private System.Windows.Forms.ListBox lbAdSoyad;
        private System.Windows.Forms.Button btnListeEkle;
        private System.Windows.Forms.Button btnTextKontrol;
        private System.Windows.Forms.Label label3;
    }
}

