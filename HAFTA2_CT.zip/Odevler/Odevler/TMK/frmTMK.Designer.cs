﻿namespace TMK
{
    partial class frmTMK
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTMK));
            this.lvOyuncu = new System.Windows.Forms.ListView();
            this.resimler = new System.Windows.Forms.ImageList(this.components);
            this.lvBilgisayar = new System.Windows.Forms.ListView();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.LOyunSonucu = new System.Windows.Forms.Label();
            this.btnVazgec = new System.Windows.Forms.Button();
            this.btnOyun = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.UDKacDefa = new System.Windows.Forms.NumericUpDown();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.GBPanel = new System.Windows.Forms.GroupBox();
            this.btnKagit = new System.Windows.Forms.Button();
            this.btnMakas = new System.Windows.Forms.Button();
            this.btnTas = new System.Windows.Forms.Button();
            this.RBKagit = new System.Windows.Forms.RadioButton();
            this.RBMakas = new System.Windows.Forms.RadioButton();
            this.RBTas = new System.Windows.Forms.RadioButton();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.UDKacDefa)).BeginInit();
            this.GBPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // lvOyuncu
            // 
            this.lvOyuncu.FullRowSelect = true;
            this.lvOyuncu.GridLines = true;
            this.lvOyuncu.Location = new System.Drawing.Point(28, 12);
            this.lvOyuncu.MultiSelect = false;
            this.lvOyuncu.Name = "lvOyuncu";
            this.lvOyuncu.Size = new System.Drawing.Size(128, 460);
            this.lvOyuncu.SmallImageList = this.resimler;
            this.lvOyuncu.TabIndex = 2;
            this.lvOyuncu.TileSize = new System.Drawing.Size(168, 30);
            this.lvOyuncu.UseCompatibleStateImageBehavior = false;
            this.lvOyuncu.View = System.Windows.Forms.View.Details;
            // 
            // resimler
            // 
            this.resimler.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("resimler.ImageStream")));
            this.resimler.TransparentColor = System.Drawing.Color.PaleTurquoise;
            this.resimler.Images.SetKeyName(0, "tas.bmp");
            this.resimler.Images.SetKeyName(1, "makas1.bmp");
            this.resimler.Images.SetKeyName(2, "kagit1.bmp");
            // 
            // lvBilgisayar
            // 
            this.lvBilgisayar.Location = new System.Drawing.Point(162, 12);
            this.lvBilgisayar.MultiSelect = false;
            this.lvBilgisayar.Name = "lvBilgisayar";
            this.lvBilgisayar.Size = new System.Drawing.Size(128, 460);
            this.lvBilgisayar.SmallImageList = this.resimler;
            this.lvBilgisayar.TabIndex = 3;
            this.lvBilgisayar.UseCompatibleStateImageBehavior = false;
            this.lvBilgisayar.View = System.Windows.Forms.View.Details;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.Info;
            this.groupBox2.Controls.Add(this.LOyunSonucu);
            this.groupBox2.Controls.Add(this.btnVazgec);
            this.groupBox2.Controls.Add(this.btnOyun);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.UDKacDefa);
            this.groupBox2.Controls.Add(this.textBox2);
            this.groupBox2.Controls.Add(this.textBox1);
            this.groupBox2.Controls.Add(this.GBPanel);
            this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.groupBox2.Location = new System.Drawing.Point(313, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(286, 217);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            // 
            // LOyunSonucu
            // 
            this.LOyunSonucu.Location = new System.Drawing.Point(21, 180);
            this.LOyunSonucu.Name = "LOyunSonucu";
            this.LOyunSonucu.Size = new System.Drawing.Size(253, 23);
            this.LOyunSonucu.TabIndex = 14;
            // 
            // btnVazgec
            // 
            this.btnVazgec.Location = new System.Drawing.Point(182, 172);
            this.btnVazgec.Name = "btnVazgec";
            this.btnVazgec.Size = new System.Drawing.Size(75, 23);
            this.btnVazgec.TabIndex = 13;
            this.btnVazgec.Text = "Vazgeç";
            this.btnVazgec.UseVisualStyleBackColor = true;
            this.btnVazgec.Visible = false;
            this.btnVazgec.Click += new System.EventHandler(this.btnVazgec_Click);
            // 
            // btnOyun
            // 
            this.btnOyun.Location = new System.Drawing.Point(182, 143);
            this.btnOyun.Name = "btnOyun";
            this.btnOyun.Size = new System.Drawing.Size(75, 23);
            this.btnOyun.TabIndex = 12;
            this.btnOyun.Text = "Basla";
            this.btnOyun.UseVisualStyleBackColor = true;
            this.btnOyun.Click += new System.EventHandler(this.btnOyun_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 147);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "Tahmin Sayısı:";
            // 
            // UDKacDefa
            // 
            this.UDKacDefa.Location = new System.Drawing.Point(98, 145);
            this.UDKacDefa.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.UDKacDefa.Name = "UDKacDefa";
            this.UDKacDefa.Size = new System.Drawing.Size(58, 20);
            this.UDKacDefa.TabIndex = 10;
            this.UDKacDefa.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.UDKacDefa.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(146, 19);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(128, 20);
            this.textBox2.TabIndex = 9;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 19);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(128, 20);
            this.textBox1.TabIndex = 8;
            // 
            // GBPanel
            // 
            this.GBPanel.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.GBPanel.Controls.Add(this.btnKagit);
            this.GBPanel.Controls.Add(this.btnMakas);
            this.GBPanel.Controls.Add(this.btnTas);
            this.GBPanel.Controls.Add(this.RBKagit);
            this.GBPanel.Controls.Add(this.RBMakas);
            this.GBPanel.Controls.Add(this.RBTas);
            this.GBPanel.Location = new System.Drawing.Point(12, 45);
            this.GBPanel.Name = "GBPanel";
            this.GBPanel.Size = new System.Drawing.Size(262, 92);
            this.GBPanel.TabIndex = 7;
            this.GBPanel.TabStop = false;
            this.GBPanel.Text = "Oyuncu Tercihi";
            // 
            // btnKagit
            // 
            this.btnKagit.AllowDrop = true;
            this.btnKagit.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnKagit.ImageIndex = 2;
            this.btnKagit.ImageList = this.resimler;
            this.btnKagit.Location = new System.Drawing.Point(187, 42);
            this.btnKagit.Name = "btnKagit";
            this.btnKagit.Size = new System.Drawing.Size(58, 44);
            this.btnKagit.TabIndex = 10;
            this.btnKagit.Tag = "2";
            this.btnKagit.UseVisualStyleBackColor = false;
            this.btnKagit.Click += new System.EventHandler(this.btnTasMakasKagit_Click);
            // 
            // btnMakas
            // 
            this.btnMakas.AllowDrop = true;
            this.btnMakas.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnMakas.ImageIndex = 1;
            this.btnMakas.ImageList = this.resimler;
            this.btnMakas.Location = new System.Drawing.Point(105, 42);
            this.btnMakas.Name = "btnMakas";
            this.btnMakas.Size = new System.Drawing.Size(58, 44);
            this.btnMakas.TabIndex = 9;
            this.btnMakas.Tag = "1";
            this.btnMakas.UseVisualStyleBackColor = false;
            this.btnMakas.Click += new System.EventHandler(this.btnTasMakasKagit_Click);
            // 
            // btnTas
            // 
            this.btnTas.AllowDrop = true;
            this.btnTas.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnTas.ImageIndex = 0;
            this.btnTas.ImageList = this.resimler;
            this.btnTas.Location = new System.Drawing.Point(25, 42);
            this.btnTas.Name = "btnTas";
            this.btnTas.Size = new System.Drawing.Size(58, 44);
            this.btnTas.TabIndex = 8;
            this.btnTas.Tag = "0";
            this.btnTas.UseVisualStyleBackColor = false;
            this.btnTas.Click += new System.EventHandler(this.btnTasMakasKagit_Click);
            // 
            // RBKagit
            // 
            this.RBKagit.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.RBKagit.Location = new System.Drawing.Point(187, 19);
            this.RBKagit.Name = "RBKagit";
            this.RBKagit.Size = new System.Drawing.Size(58, 17);
            this.RBKagit.TabIndex = 2;
            this.RBKagit.TabStop = true;
            this.RBKagit.Text = "Kağıt";
            this.RBKagit.UseVisualStyleBackColor = false;
            this.RBKagit.Click += new System.EventHandler(this.RBKagit_Click);
            // 
            // RBMakas
            // 
            this.RBMakas.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.RBMakas.Location = new System.Drawing.Point(105, 18);
            this.RBMakas.Name = "RBMakas";
            this.RBMakas.Size = new System.Drawing.Size(58, 17);
            this.RBMakas.TabIndex = 1;
            this.RBMakas.TabStop = true;
            this.RBMakas.Text = "Makas";
            this.RBMakas.UseVisualStyleBackColor = false;
            this.RBMakas.Click += new System.EventHandler(this.RBMakas_Click);
            // 
            // RBTas
            // 
            this.RBTas.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.RBTas.Location = new System.Drawing.Point(25, 18);
            this.RBTas.Name = "RBTas";
            this.RBTas.Size = new System.Drawing.Size(58, 17);
            this.RBTas.TabIndex = 0;
            this.RBTas.TabStop = true;
            this.RBTas.Text = "Taş";
            this.RBTas.UseVisualStyleBackColor = false;
            this.RBTas.Click += new System.EventHandler(this.RBTas_Click);
            // 
            // frmTMK
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(617, 483);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.lvBilgisayar);
            this.Controls.Add(this.lvOyuncu);
            this.Name = "frmTMK";
            this.Text = "Taş Makas Kağıt Oyunu";
            this.Load += new System.EventHandler(this.frmTMK_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.UDKacDefa)).EndInit();
            this.GBPanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ListView lvOyuncu;
        private System.Windows.Forms.ListView lvBilgisayar;
        private System.Windows.Forms.ImageList resimler;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.NumericUpDown UDKacDefa;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.GroupBox GBPanel;
        private System.Windows.Forms.Button btnKagit;
        private System.Windows.Forms.Button btnMakas;
        private System.Windows.Forms.Button btnTas;
        private System.Windows.Forms.RadioButton RBKagit;
        private System.Windows.Forms.RadioButton RBMakas;
        private System.Windows.Forms.RadioButton RBTas;
        private System.Windows.Forms.Button btnOyun;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnVazgec;
        private System.Windows.Forms.Label LOyunSonucu;
    }
}

