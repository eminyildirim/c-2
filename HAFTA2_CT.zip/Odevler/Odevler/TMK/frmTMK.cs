﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace TMK
{
    public partial class frmTMK : Form
    {
        // String stdDetails = "{0, -20}{1, -20}{2, -20}";
        int op = 0, bp = 0;
        Random rnd = new Random();
        Random rn2 = new Random();
        public frmTMK()
        {
            InitializeComponent();
        }
        private void frmTMK_Load(object sender, EventArgs e)
        {
            DizaynListView(lvOyuncu, "Oyuncu");
            DizaynListView(lvBilgisayar, "Bilgisayar");
            GBPanel.Enabled = false;
        }
        private void DizaynListView(ListView LV, String CText)
        {
            // LV.View = View.Details;

            LV.LabelEdit = false;
            LV.AllowColumnReorder = true;
            LV.CheckBoxes = false;
            LV.FullRowSelect = true;
            LV.GridLines = true;
            //LV.Sorting = SortOrder.Ascending;
            LV.Columns.Add(CText, -2, HorizontalAlignment.Left);
            LV.Columns[0].Width = 100;            
        }
        private void RBTas_Click(object sender, EventArgs e)           
        {
            RBSetk(0);
        }
        private void RBMakas_Click(object sender, EventArgs e)
        {
            RBSetk(1);
        }
        private void RBKagit_Click(object sender, EventArgs e)
        {
            RBSetk(2);
        }

        private void btnTasMakasKagit_Click(object sender, EventArgs e)
        {
            Button btn = new Button();
            btn = (sender as Button);
            int b = int.Parse(btn.Tag.ToString());
            RadioButton rb = new RadioButton();
            String rbname = "RB" + btn.Name.ToString().Substring(3);
            Control[] matches = this.Controls.Find(rbname,true);
            rb = matches[0] as RadioButton;
            rb.Checked = true;            
            RBSetk(b);
        }

        private void btnOyun_Click(object sender, EventArgs e)
        {

            if (UDKacDefa.Value > 14)
            {
                int h = 0, t = 0; ;

                h = 522 + ((int)UDKacDefa.Value - 10) * 30;
                if (h > (Screen.PrimaryScreen.Bounds.Height - 30)) { h = Screen.PrimaryScreen.Bounds.Height - 30; }
                frmTMK.ActiveForm.Height = h;
                t = (Screen.PrimaryScreen.Bounds.Height - (h + 30)) / 2;
                frmTMK.ActiveForm.Top = t;
                h = 522 + ((int)UDKacDefa.Value - 10) * 30;
                if (h > (Screen.PrimaryScreen.Bounds.Height - 30)) { h = Screen.PrimaryScreen.Bounds.Height - 30; }
                lvOyuncu.Height = h - 522 + 460;
                lvBilgisayar.Height = lvOyuncu.Height;
            }
            op = 0;
            bp = 0;
            GBPanel.Enabled = true;
            btnOyun.Visible = false;
            UDKacDefa.Enabled = false;
            lvOyuncu.Items.Clear();
            lvBilgisayar.Items.Clear();
            textBox1.Text = "";
            textBox2.Text = "";
            btnVazgec.Visible = true;
            btnVazgec.Top = btnOyun.Top;
            LOyunSonucu.Text = "Yeni Oyun";
        }

        private void btnVazgec_Click(object sender, EventArgs e)
        {
            GBPanel.Enabled = false;
            btnVazgec.Visible = false;
            btnOyun.Visible = true;
            UDKacDefa.Enabled = true;
            lvOyuncu.Items.Clear();
            lvBilgisayar.Items.Clear();
            textBox1.Text = "";
            textBox2.Text = "";
            RBTas.Checked = false;
            RBMakas.Checked = false;
            RBKagit.Checked = false;
            LOyunSonucu.Text = "";
        }

        private void RBSetk(int i)
        {
            int l = lvOyuncu.Items.Count + 1;

            int r = rnd.Next(117, 877);
    
            int p = rn2.Next(50, 150);
            Thread.Sleep(p);
            r = rnd.Next(119, 877);
            r = r % 3;

            int o =0,b = 0;

            switch (i)
            {
                case 0:
                    {
                        if (r==1) { o = 1;}
                        if (r==2) { b = 1; }
                        break;
                    }
                case 1:
                    {
                        if (r==0) { b = 1; }
                        if (r==2) { o = 1; }
                        break;
                    }
                case 2:
                    {
                        if (r==0) { o = 1; }
                        if (r==1) { b = 1; }
                        break;
                    }
                default:
                    break;
            }
            op = op + o;
            bp = bp + b;
            textBox1.Text = "Oyuncu:" + op.ToString();
            textBox2.Text = "Bilgisayar:" + bp.ToString();
            ListViewItem item1 = new ListViewItem(l.ToString() + ".Oyun (" + o.ToString() + ")", i);
            item1.SubItems.Add(l.ToString());
            lvOyuncu.Items.AddRange(new ListViewItem[] { item1 });

            ListViewItem item = new ListViewItem(l.ToString() + ".Oyun (" + b.ToString() + ")", r);
            item.SubItems.Add(l.ToString());
            lvBilgisayar.Items.AddRange(new ListViewItem[] { item });

            lvOyuncu.Items[lvOyuncu.Items.Count - 1].EnsureVisible();
            lvBilgisayar.Items[lvBilgisayar.Items.Count - 1].EnsureVisible();
            if (UDKacDefa.Value <= lvOyuncu.Items.Count)
            {
                GBPanel.Enabled = false;
                UDKacDefa.Enabled = true;
                btnOyun.Visible = true;
                btnVazgec.Visible = false;
                RBTas.Checked = false;
                RBMakas.Checked = false;
                RBKagit.Checked = false;
                LOyunSonucu.Text = "Oyun Berabere Bitti ";
                if (op > bp) { LOyunSonucu.Text = "Oyun Bitti ( Siz Kazandınız )"; }
                if (op < bp) { LOyunSonucu.Text = "Oyun Bitti ( Bilgisayar Kazandı )"; }
            }
        }
    }
}
