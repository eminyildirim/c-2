﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace grupboxschroll
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            groupBox1.Height = groupBox1.Height + 20;

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int btnPos = 1;

            Panel pnl = new Panel();
            pnl.AutoScroll = true;
            pnl.Top = 15;
            pnl.Left = 2;
            pnl.Width = groupBox1.Width - 8;
            pnl.Height = groupBox1.Height - 18;

            for (int i = 0; i < 22; i++)
            {
                Button _btn = new Button();
                _btn.Text = "lbl"+i.ToString();
                _btn.Top = btnPos;
                btnPos += 23;
                pnl.Controls.Add(_btn);
            }
            groupBox1.Controls.Add(pnl);
        }
    }
}
