﻿namespace Sinema
{
    partial class frmFilmGiris
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dgwFilmListesi = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FilmAdi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FilmSure = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbFilmAdi = new System.Windows.Forms.TextBox();
            this.mtbFilmSure = new System.Windows.Forms.MaskedTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgwFilmListesi)).BeginInit();
            this.SuspendLayout();
            // 
            // dgwFilmListesi
            // 
            this.dgwFilmListesi.AllowUserToAddRows = false;
            this.dgwFilmListesi.AllowUserToDeleteRows = false;
            this.dgwFilmListesi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgwFilmListesi.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.FilmAdi,
            this.FilmSure});
            this.dgwFilmListesi.Location = new System.Drawing.Point(13, 12);
            this.dgwFilmListesi.MultiSelect = false;
            this.dgwFilmListesi.Name = "dgwFilmListesi";
            this.dgwFilmListesi.ReadOnly = true;
            this.dgwFilmListesi.RowHeadersVisible = false;
            this.dgwFilmListesi.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgwFilmListesi.Size = new System.Drawing.Size(297, 359);
            this.dgwFilmListesi.TabIndex = 0;
            this.dgwFilmListesi.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgwFilmListesi_CellClick);
            // 
            // ID
            // 
            this.ID.DataPropertyName = "ID";
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            this.ID.Visible = false;
            // 
            // FilmAdi
            // 
            this.FilmAdi.DataPropertyName = "FilmAdi";
            this.FilmAdi.HeaderText = "Film Adı";
            this.FilmAdi.Name = "FilmAdi";
            this.FilmAdi.ReadOnly = true;
            this.FilmAdi.Width = 200;
            // 
            // FilmSure
            // 
            this.FilmSure.DataPropertyName = "FilmSure";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle1.Format = "N0";
            dataGridViewCellStyle1.NullValue = null;
            this.FilmSure.DefaultCellStyle = dataGridViewCellStyle1;
            this.FilmSure.HeaderText = "Film Süresi (dk)";
            this.FilmSure.Name = "FilmSure";
            this.FilmSure.ReadOnly = true;
            this.FilmSure.Width = 50;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(342, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Film Adı:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(342, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Film Süre:";
            // 
            // tbFilmAdi
            // 
            this.tbFilmAdi.Enabled = false;
            this.tbFilmAdi.Location = new System.Drawing.Point(401, 22);
            this.tbFilmAdi.Name = "tbFilmAdi";
            this.tbFilmAdi.Size = new System.Drawing.Size(256, 20);
            this.tbFilmAdi.TabIndex = 3;
            // 
            // mtbFilmSure
            // 
            this.mtbFilmSure.Enabled = false;
            this.mtbFilmSure.Location = new System.Drawing.Point(401, 48);
            this.mtbFilmSure.Mask = "999";
            this.mtbFilmSure.Name = "mtbFilmSure";
            this.mtbFilmSure.Size = new System.Drawing.Size(38, 20);
            this.mtbFilmSure.TabIndex = 4;
            // 
            // frmFilmGiris
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(681, 383);
            this.Controls.Add(this.mtbFilmSure);
            this.Controls.Add(this.tbFilmAdi);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgwFilmListesi);
            this.Name = "frmFilmGiris";
            this.Text = "frmFilmGiris";
            this.Load += new System.EventHandler(this.frmFilmGiris_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgwFilmListesi)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgwFilmListesi;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn FilmAdi;
        private System.Windows.Forms.DataGridViewTextBoxColumn FilmSure;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbFilmAdi;
        private System.Windows.Forms.MaskedTextBox mtbFilmSure;
    }
}