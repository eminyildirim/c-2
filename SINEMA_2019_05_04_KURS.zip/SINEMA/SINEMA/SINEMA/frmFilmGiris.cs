﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Sinema
{
    public partial class frmFilmGiris : Form
    {
        public frmFilmGiris()
        {
            InitializeComponent();
        }
        SqlBaglantisi bgl = new SqlBaglantisi();
        private void frmFilmGiris_Load(object sender, EventArgs e)
        {
            Listele();
            Goster(0);
        }
        void Listele()
        {
            SqlCommand cmd = new SqlCommand("Select * from dbo.Film order by ID DESC", bgl.baglanti());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dgwFilmListesi.DataSource = dt;
        }
        void Goster(int r)
        {
            tbFilmAdi.Text = dgwFilmListesi.Rows[r].Cells[1].Value.ToString();
            mtbFilmSure.Text = dgwFilmListesi.Rows[r].Cells[2].Value.ToString();

      
            /*

            SqlCommand cmd = new SqlCommand("Select * FROM dbo.TblNotlar WHERE OgrnciID = (Select ID FROM dbo.TblOgrenci WHERE Numara = @Numara)", bgl.baglanti());
            cmd.Parameters.AddWithValue("@Numara", mtbNumara.Text);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {

                tbSinav1.Text = dr.GetByte(1).ToString().ToString();
                tbSinav2.Text = dr.GetByte(2).ToString().ToString();
                tbSinav3.Text = dr.GetByte(3).ToString().ToString();
                tbProje.Text = dr.GetByte(4).ToString().ToString();

            }
            */
        }
        private void dgwFilmListesi_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            Goster(e.RowIndex);
        }
    }
}
