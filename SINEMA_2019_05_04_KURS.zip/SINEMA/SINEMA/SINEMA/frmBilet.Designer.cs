﻿namespace Sinema
{
    partial class frmBilet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBilet));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.rtbKonum = new System.Windows.Forms.RichTextBox();
            this.imList = new System.Windows.Forms.ImageList(this.components);
            this.gbSalon = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dgvSeanslar = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Seans = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Koltuklar = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvFilmler = new System.Windows.Forms.DataGridView();
            this.FilmAdi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SalonAdi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VizyonID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnFilmler = new System.Windows.Forms.Button();
            this.dtmTarih = new System.Windows.Forms.DateTimePicker();
            this.lseansID = new System.Windows.Forms.Label();
            this.btnBilet = new System.Windows.Forms.Button();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.pSecim = new System.Windows.Forms.Panel();
            this.btnSalonSema = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tbSecilenler = new System.Windows.Forms.TextBox();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.sinemaDataSet = new Sinema.sinemaDataSet();
            this.salonBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.salonTableAdapter = new Sinema.sinemaDataSetTableAdapters.SalonTableAdapter();
            this.btnGarfik = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSeanslar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFilmler)).BeginInit();
            this.pSecim.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sinemaDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.salonBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // rtbKonum
            // 
            this.rtbKonum.Location = new System.Drawing.Point(0, 494);
            this.rtbKonum.Name = "rtbKonum";
            this.rtbKonum.Size = new System.Drawing.Size(359, 19);
            this.rtbKonum.TabIndex = 2;
            this.rtbKonum.Text = "";
            this.rtbKonum.Visible = false;
            // 
            // imList
            // 
            this.imList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imList.ImageStream")));
            this.imList.TransparentColor = System.Drawing.Color.Transparent;
            this.imList.Images.SetKeyName(0, "koltuksil.png");
            this.imList.Images.SetKeyName(1, "koltukbos.png");
            this.imList.Images.SetKeyName(2, "koltukdolu.png");
            this.imList.Images.SetKeyName(3, "koltuksec.png");
            // 
            // gbSalon
            // 
            this.gbSalon.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.gbSalon.Location = new System.Drawing.Point(365, 1);
            this.gbSalon.Name = "gbSalon";
            this.gbSalon.Size = new System.Drawing.Size(921, 747);
            this.gbSalon.TabIndex = 8;
            this.gbSalon.TabStop = false;
            this.gbSalon.Text = "[ Salon ]";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dgvSeanslar);
            this.groupBox2.Controls.Add(this.dgvFilmler);
            this.groupBox2.Location = new System.Drawing.Point(12, 37);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(326, 277);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Vizyondaki Filimler";
            // 
            // dgvSeanslar
            // 
            this.dgvSeanslar.AllowUserToAddRows = false;
            this.dgvSeanslar.AllowUserToDeleteRows = false;
            this.dgvSeanslar.AllowUserToResizeRows = false;
            this.dgvSeanslar.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvSeanslar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvSeanslar.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.Seans,
            this.Koltuklar});
            this.dgvSeanslar.EnableHeadersVisualStyles = false;
            this.dgvSeanslar.Location = new System.Drawing.Point(221, 20);
            this.dgvSeanslar.MultiSelect = false;
            this.dgvSeanslar.Name = "dgvSeanslar";
            this.dgvSeanslar.ReadOnly = true;
            this.dgvSeanslar.RowHeadersVisible = false;
            this.dgvSeanslar.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvSeanslar.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgvSeanslar.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSeanslar.Size = new System.Drawing.Size(99, 251);
            this.dgvSeanslar.TabIndex = 1;
            this.dgvSeanslar.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSeanslar_CellClick);
            // 
            // ID
            // 
            this.ID.DataPropertyName = "ID";
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            this.ID.Visible = false;
            // 
            // Seans
            // 
            this.Seans.DataPropertyName = "Seans";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Seans.DefaultCellStyle = dataGridViewCellStyle1;
            this.Seans.HeaderText = "Seanslar";
            this.Seans.Name = "Seans";
            this.Seans.ReadOnly = true;
            this.Seans.Width = 60;
            // 
            // Koltuklar
            // 
            this.Koltuklar.DataPropertyName = "Koltuklar";
            this.Koltuklar.HeaderText = "Koltuklar";
            this.Koltuklar.Name = "Koltuklar";
            this.Koltuklar.ReadOnly = true;
            this.Koltuklar.Visible = false;
            // 
            // dgvFilmler
            // 
            this.dgvFilmler.AllowUserToAddRows = false;
            this.dgvFilmler.AllowUserToDeleteRows = false;
            this.dgvFilmler.AllowUserToResizeRows = false;
            this.dgvFilmler.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvFilmler.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            this.dgvFilmler.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvFilmler.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.FilmAdi,
            this.SalonAdi,
            this.VizyonID});
            this.dgvFilmler.EnableHeadersVisualStyles = false;
            this.dgvFilmler.Location = new System.Drawing.Point(8, 19);
            this.dgvFilmler.Name = "dgvFilmler";
            this.dgvFilmler.ReadOnly = true;
            this.dgvFilmler.RowHeadersVisible = false;
            this.dgvFilmler.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvFilmler.Size = new System.Drawing.Size(207, 252);
            this.dgvFilmler.TabIndex = 0;
            this.dgvFilmler.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvFilmler_CellClick);
            // 
            // FilmAdi
            // 
            this.FilmAdi.DataPropertyName = "FilmAdi";
            this.FilmAdi.HeaderText = "Film Adı";
            this.FilmAdi.Name = "FilmAdi";
            this.FilmAdi.ReadOnly = true;
            this.FilmAdi.Width = 180;
            // 
            // SalonAdi
            // 
            this.SalonAdi.DataPropertyName = "SalonAdi";
            this.SalonAdi.HeaderText = "Salon Adı";
            this.SalonAdi.Name = "SalonAdi";
            this.SalonAdi.ReadOnly = true;
            this.SalonAdi.Visible = false;
            // 
            // VizyonID
            // 
            this.VizyonID.DataPropertyName = "VizyonID";
            this.VizyonID.HeaderText = "VizyonID";
            this.VizyonID.Name = "VizyonID";
            this.VizyonID.ReadOnly = true;
            this.VizyonID.Visible = false;
            // 
            // btnFilmler
            // 
            this.btnFilmler.Location = new System.Drawing.Point(20, 352);
            this.btnFilmler.Name = "btnFilmler";
            this.btnFilmler.Size = new System.Drawing.Size(75, 23);
            this.btnFilmler.TabIndex = 14;
            this.btnFilmler.Text = "Filmler";
            this.btnFilmler.UseVisualStyleBackColor = true;
            this.btnFilmler.Click += new System.EventHandler(this.btnFilmler_Click);
            // 
            // dtmTarih
            // 
            this.dtmTarih.AllowDrop = true;
            this.dtmTarih.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtmTarih.Location = new System.Drawing.Point(12, 11);
            this.dtmTarih.Name = "dtmTarih";
            this.dtmTarih.Size = new System.Drawing.Size(95, 20);
            this.dtmTarih.TabIndex = 15;
            this.dtmTarih.Value = new System.DateTime(2019, 5, 3, 0, 0, 0, 0);
            this.dtmTarih.ValueChanged += new System.EventHandler(this.dtmTarih_ValueChanged);
            // 
            // lseansID
            // 
            this.lseansID.AutoSize = true;
            this.lseansID.Location = new System.Drawing.Point(277, 362);
            this.lseansID.Name = "lseansID";
            this.lseansID.Size = new System.Drawing.Size(35, 13);
            this.lseansID.TabIndex = 16;
            this.lseansID.Text = "label2";
            // 
            // btnBilet
            // 
            this.btnBilet.Location = new System.Drawing.Point(110, 352);
            this.btnBilet.Name = "btnBilet";
            this.btnBilet.Size = new System.Drawing.Size(75, 23);
            this.btnBilet.TabIndex = 17;
            this.btnBilet.Text = "Bilet Yaz";
            this.btnBilet.UseVisualStyleBackColor = true;
            this.btnBilet.Click += new System.EventHandler(this.btnBilet_Click);
            // 
            // pSecim
            // 
            this.pSecim.Controls.Add(this.groupBox2);
            this.pSecim.Controls.Add(this.dtmTarih);
            this.pSecim.Location = new System.Drawing.Point(0, 1);
            this.pSecim.Name = "pSecim";
            this.pSecim.Size = new System.Drawing.Size(359, 345);
            this.pSecim.TabIndex = 18;
            // 
            // btnSalonSema
            // 
            this.btnSalonSema.Location = new System.Drawing.Point(20, 381);
            this.btnSalonSema.Name = "btnSalonSema";
            this.btnSalonSema.Size = new System.Drawing.Size(75, 23);
            this.btnSalonSema.TabIndex = 19;
            this.btnSalonSema.Text = "Salon Sema";
            this.btnSalonSema.UseVisualStyleBackColor = true;
            this.btnSalonSema.Click += new System.EventHandler(this.btnSalonSema_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 407);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 13);
            this.label1.TabIndex = 20;
            this.label1.Text = "Seçilen Koltuklar:";
            // 
            // tbSecilenler
            // 
            this.tbSecilenler.Location = new System.Drawing.Point(105, 407);
            this.tbSecilenler.Multiline = true;
            this.tbSecilenler.Name = "tbSecilenler";
            this.tbSecilenler.ReadOnly = true;
            this.tbSecilenler.Size = new System.Drawing.Size(244, 67);
            this.tbSecilenler.TabIndex = 21;
            // 
            // chart1
            // 
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(13, 530);
            this.chart1.Name = "chart1";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.chart1.Series.Add(series1);
            this.chart1.Size = new System.Drawing.Size(319, 246);
            this.chart1.TabIndex = 22;
            this.chart1.Text = "chart1";
            // 
            // sinemaDataSet
            // 
            this.sinemaDataSet.DataSetName = "sinemaDataSet";
            this.sinemaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // salonBindingSource
            // 
            this.salonBindingSource.DataMember = "Salon";
            this.salonBindingSource.DataSource = this.sinemaDataSet;
            // 
            // salonTableAdapter
            // 
            this.salonTableAdapter.ClearBeforeFill = true;
            // 
            // btnGarfik
            // 
            this.btnGarfik.Location = new System.Drawing.Point(142, 782);
            this.btnGarfik.Name = "btnGarfik";
            this.btnGarfik.Size = new System.Drawing.Size(75, 23);
            this.btnGarfik.TabIndex = 23;
            this.btnGarfik.Text = "Grafik";
            this.btnGarfik.UseVisualStyleBackColor = true;
            this.btnGarfik.Click += new System.EventHandler(this.btnGarfik_Click);
            // 
            // frmBilet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1298, 815);
            this.Controls.Add(this.btnGarfik);
            this.Controls.Add(this.chart1);
            this.Controls.Add(this.tbSecilenler);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSalonSema);
            this.Controls.Add(this.pSecim);
            this.Controls.Add(this.btnBilet);
            this.Controls.Add(this.lseansID);
            this.Controls.Add(this.btnFilmler);
            this.Controls.Add(this.gbSalon);
            this.Controls.Add(this.rtbKonum);
            this.Name = "frmBilet";
            this.Text = "Sinema Bilet İşlemleri";
            this.MaximumSizeChanged += new System.EventHandler(this.Form1_MaximumSizeChanged);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResizeEnd += new System.EventHandler(this.Form1_ResizeEnd);
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSeanslar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFilmler)).EndInit();
            this.pSecim.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sinemaDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.salonBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.RichTextBox rtbKonum;
        private System.Windows.Forms.ImageList imList;
        private System.Windows.Forms.GroupBox gbSalon;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnFilmler;
        private System.Windows.Forms.DataGridView dgvFilmler;
        private System.Windows.Forms.DateTimePicker dtmTarih;
        private System.Windows.Forms.DataGridViewTextBoxColumn FilmAdi;
        private System.Windows.Forms.DataGridViewTextBoxColumn SalonAdi;
        private System.Windows.Forms.DataGridViewTextBoxColumn VizyonID;
        private System.Windows.Forms.DataGridView dgvSeanslar;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Seans;
        private System.Windows.Forms.DataGridViewTextBoxColumn Koltuklar;
        private System.Windows.Forms.Label lseansID;
        private System.Windows.Forms.Button btnBilet;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.Panel pSecim;
        private System.Windows.Forms.Button btnSalonSema;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbSecilenler;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private sinemaDataSet sinemaDataSet;
        private System.Windows.Forms.BindingSource salonBindingSource;
        private sinemaDataSetTableAdapters.SalonTableAdapter salonTableAdapter;
        private System.Windows.Forms.Button btnGarfik;
    }
}

