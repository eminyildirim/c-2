﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Windows.Forms.DataVisualization.Charting;
namespace Sinema
{
    public partial class frmBilet : Form
    {
        public frmBilet()
        {
            InitializeComponent();
        }
        SqlBaglantisi bgl = new SqlBaglantisi();
        int xx;
        int yy;
        void FilmListele()
        {
            SqlCommand cmd = new SqlCommand("EXECUTE dbo.SeansFilmleri @Tarih", bgl.baglanti());
            cmd.Parameters.AddWithValue("@Tarih", dtmTarih.Value);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dgvFilmler.DataSource = dt;
        }
        void SeansListele()
        {
            while (gbSalon.Controls.Count > 0)
            {
                gbSalon.Controls.RemoveAt(gbSalon.Controls.Count - 1);
            }

            SqlCommand cmd = new SqlCommand("SELECT ID,Seans,Koltuklar FROM dbo.SeansListesi WHERE VizyonID=@VizyonID AND Tarih = @Tarih", bgl.baglanti());
            if (dgvFilmler.RowCount > 0)
            {
                cmd.Parameters.AddWithValue("@VizyonID", dgvFilmler.Rows[dgvFilmler.CurrentRow.Index].Cells[2].Value.ToString());
            }
            else
            { cmd.Parameters.AddWithValue("@VizyonID", -1); }
            //MessageBox.Show(dgvFilmler.CurrentRow.Index.ToString());
            cmd.Parameters.AddWithValue("@Tarih", dtmTarih.Value);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dgvSeanslar.DataSource = dt;

        }
        void Goster(int r)
        {
            while (gbSalon.Controls.Count > 0)
            {
                gbSalon.Controls.RemoveAt(gbSalon.Controls.Count - 1);
            }
            if (dgvSeanslar.RowCount > 0 && dgvFilmler.RowCount > 0)
            {
                lseansID.Text = dgvSeanslar.Rows[r].Cells[0].Value.ToString();
                RichTextBox rtbKonum = new RichTextBox();
                rtbKonum.Text = dgvSeanslar.Rows[r].Cells[2].Value.ToString();
                rtbKonum.AppendText("\n" + "".PadRight(rtbKonum.Lines[0].Length, '0'));
                while (gbSalon.Controls.Count > 0)
                {
                    gbSalon.Controls.RemoveAt(gbSalon.Controls.Count - 1);
                }
                gbSalon.Visible = true;
                SalonOlustur(gbSalon, rtbKonum);
                pSecim.Enabled = true;
                gbSalon.Text = "[ " + dgvFilmler.Rows[dgvFilmler.CurrentRow.Index].Cells[1].Value.ToString() + " ]";
            }
            else
            { gbSalon.Text = "[ Tanımlı Film Yok ]"; }
            tbSecilenler.Text = "";
            btnGarfik.PerformClick();
        }
        private void DataYap()
        {
            String x = "", y = "";
            rtbKonum.Text = "";
            foreach (var item in gbSalon.Controls[1].Controls)
            {
                if (item is Label)
                {
                    Label pb = new Label();
                    pb = (item as Label);
                    if (pb.Name.StartsWith("LS"))
                    {
                        if (y.Equals("") || y.Equals(pb.Name.Substring(2, pb.Name.IndexOf('_') - 1)))
                        {
                            y = pb.Name.Substring(2, pb.Name.IndexOf('_') - 1);
                            x = x + pb.Tag.ToString();
                        }
                        else
                        {
                            if (!string.IsNullOrWhiteSpace(rtbKonum.Text))
                            {
                                rtbKonum.AppendText("\r\n" + x);
                            }
                            else
                            {
                                rtbKonum.AppendText(x);
                            }
                            y = pb.Name.Substring(2, pb.Name.IndexOf('_') - 1);
                            x = pb.Tag.ToString();
                        }
                    }
                }
                if (item is PictureBox)
                {
                    PictureBox pb = new PictureBox();
                    pb = (item as PictureBox);
                    if (pb.Name.StartsWith("PB"))
                    {
                        if (y.Equals("") || y.Equals(pb.Name.Substring(2, pb.Name.IndexOf('_') - 1)))
                        {
                            y = pb.Name.Substring(2, pb.Name.IndexOf('_') - 1);
                            x = x + pb.Tag.ToString();
                        }
                        else
                        {
                            if (!string.IsNullOrWhiteSpace(rtbKonum.Text))
                            {
                                rtbKonum.AppendText("\r\n" + x);
                            }
                            else
                            {
                                rtbKonum.AppendText(x);
                            }
                            y = pb.Name.Substring(2, pb.Name.IndexOf('_') - 1);
                            x = pb.Tag.ToString();
                        }
                    }
                }
            }
            rtbKonum.ScrollToCaret();
        }
        private void btnBilet_Click(object sender, EventArgs e)
        {
            // MessageBox.Show(gbSalon.Controls[1].Name);
            DataYap();
            SqlCommand cmd = new SqlCommand("UPDATE dbo.SeansListesi SET Koltuklar=@Koltuklar WHERE ID=@ID", bgl.baglanti());
            cmd.Parameters.AddWithValue("@Koltuklar", rtbKonum.Text);
            cmd.Parameters.AddWithValue("@ID", lseansID.Text);
            cmd.ExecuteNonQuery();
            int r = dgvSeanslar.CurrentRow.Index;
            dgvSeanslar.Rows[r].Cells[2].Value=rtbKonum.Text.ToString();
            /* 
            int r = dgvSeanslar.CurrentRow.Index;
        //    MessageBox.Show(r.ToString());

            SeansListele();
            Goster(0);
            dgvSeanslar.CurrentCell = dgvSeanslar.Rows[r].Cells[1];
            dgvSeanslar.Rows[r].Selected = true;
            for (int i = 0; i < rtbKonum.Lines.Count(); i++)
            {
                MessageBox.Show(rtbKonum.Lines[i]);
            }
*/

        }
        private String Sifirdoldur(int uzunluk, int i)
        {
            String sonuc = new string('0', uzunluk) + i.ToString();
            sonuc = sonuc.Substring(sonuc.Length - uzunluk);
            return sonuc;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'sinemaDataSet.Salon' table. You can move, or remove it, as needed.
            this.salonTableAdapter.Fill(this.sinemaDataSet.Salon);
            //this.WindowState = FormWindowState.Maximized;
            this.Top = 0;
            this.Height = Screen.PrimaryScreen.Bounds.Height - 50;
            dtmTarih.Value = DateTime.Today;
            dtmTarih.MinDate = DateTime.Today;
            DateTime endDate = DateTime.Today;
            DateTime newDate = endDate.AddDays(28);
            dtmTarih.MaxDate = newDate;
            gbSalon.Height = this.Height - 50;
            FilmListele();
            SeansListele();
            Goster(0);
        }
        private void button1_Click(object sender, EventArgs e)
        {

        }
        private void SalonOlustur(Control Salon, RichTextBox rtbKonum)
        {
            pSecim.Enabled = false;
            //Salon.Visible = false;
            int w = 30, h = 45;

            int s = 0;
            int pw = rtbKonum.Lines[0].Length * (w + 1) + 80;
            int ph = rtbKonum.Lines.Count() * (h + 4) + 40 + 55;
            // Salon.Width = pw;
            // Salon.Height = 800;

            Panel pnl = new Panel();
            // pnl.AutoSize = true;
            pnl.AutoScroll = true;
            pnl.Top = 16;
            pnl.Left = 8;
            pnl.Width = Salon.Width - 8;
            pnl.Height = Salon.Height - 40;
            ph = (Salon.Height - 40) - (Salon.Height - 40) % (h + 4);
            pnl.Height = ph + 2;
            pnl.Name = "panelKoltuklar";

            Label sLabel = new Label();
            sLabel.BackColor = Color.SkyBlue;
            sLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            sLabel.Location = new System.Drawing.Point(0, 16 + pnl.Height + 2);
            sLabel.Name = "sLabel";
            sLabel.Size = new System.Drawing.Size((w + 1) * rtbKonum.Lines[0].Length, 24);
            sLabel.Text = "S A H N E  [ P E R D E ]";
            sLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            Salon.Controls.Add(sLabel);

            pnl.AutoScroll = true;
            // pnl.AutoSize = true;
            for (int i = 0; i < rtbKonum.Lines.Count(); i++)
            {
                int y = 1 + i * (h + 4);
                int ss = 0;
                string strvalue = "".PadRight(rtbKonum.Lines[i].Length, '0');

                for (int j = 0; j < rtbKonum.Lines[i].Length; j++)
                {
                    int x = (w + 1) * j;
                    if (rtbKonum.Lines[i].ToString()[j].Equals('1') || rtbKonum.Lines[i].ToString()[j].Equals('2'))
                    {
                        ss++;
                        Label l1 = new Label();

                        l1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
                        l1.ImageIndex = int.Parse(rtbKonum.Lines[i].ToString()[j].ToString());
                        l1.ImageList = this.imList;
                        l1.Location = new System.Drawing.Point(x, y);
                        l1.Name = "LS" + Sifirdoldur(5,i) + "_" + Sifirdoldur(5,j+1);
                        l1.Size = new System.Drawing.Size(30, 45);
                        l1.Text = ss.ToString();
                        l1.Tag = rtbKonum.Lines[i].ToString()[j].ToString();
                        l1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
                        l1.Click += new System.EventHandler(this.lkoltuk_Click);
                        l1.DoubleClick += new System.EventHandler(this.lkoltuk_DoubleClick);
                        pnl.Controls.Add(l1);
                        /*                              
                        System.Windows.Forms.PictureBox k1 = new System.Windows.Forms.PictureBox();
                        k1.Image = global::Sinema.Properties.Resources.koltukbos;
                        k1.Location = new System.Drawing.Point(x, y);
                        k1.Size = new System.Drawing.Size(w, h);
                        k1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
                        k1.TabIndex = 0;
                        k1.TabStop = false;
                        k1.Click += new System.EventHandler(this.koltuk_Click);
                        k1.Name = "k" + s.ToString() + "00" + (j + 1).ToString();
                        k1.Tag = ss.ToString();


                        System.Windows.Forms.Label l1 = new System.Windows.Forms.Label();
                        l1.AutoSize = true;
                        l1.BackColor = System.Drawing.SystemColors.ControlLightLight;
                       // l1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
                        l1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
                        l1.Location = new System.Drawing.Point(x+8, y+32);
                        l1.Click += new System.EventHandler(this.lkoltuk_Click);
                        l1.Name = "lsira" + s.ToString()+"_"+ss.ToString();
                        l1.Size = new System.Drawing.Size(14, 14);
                        l1.TabIndex = 2;   
                        l1.Text = ss.ToString();
                        l1.Tag = ss.ToString();
                        pSalon.Controls.Add(l1);
                        pSalon.Controls.Add(k1);
                        */

                    }
                    if (rtbKonum.Lines[i].ToString()[j].Equals('0'))
                    {
                        System.Windows.Forms.PictureBox k1 = new System.Windows.Forms.PictureBox();

                        k1.Image = global::Sinema.Properties.Resources.koltuksil;
                        k1.Location = new System.Drawing.Point(x, y);
                        k1.Size = new System.Drawing.Size(w, h);
                        k1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
                        k1.Name = "PB" + Sifirdoldur(5,i) + "_" + Sifirdoldur(5,(j + 1));
                        k1.Tag = 0;
                        pnl.Controls.Add(k1);
                        // pnl.AutoSize = true;
                        pnl.AutoScroll = true;
                    }
                }
                if (!rtbKonum.Lines[i].ToString().Equals(strvalue))
                {
                    s++;
                    Label l1 = new Label();
                    l1.AutoSize = true;
                    l1.BackColor = System.Drawing.SystemColors.ControlLightLight;
                    l1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
                    l1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
                    l1.Location = new System.Drawing.Point((w + 1) * rtbKonum.Lines[i].Length, y + 5);
                    l1.Name = "LH" + Sifirdoldur(5, i);
                    l1.Size = new System.Drawing.Size(14, 14);
                    char ch = 'A';
                    ch = (char)(s + 64);
                    l1.Text = ch.ToString(); ;
                    pnl.Controls.Add(l1);

                }
            }
           // pnl.Height = (rtbKonum.Lines.Count() + 1) * (h + 4);
           // sLabel.Top = (rtbKonum.Lines.Count() ) * (h + 4);
            Salon.Controls.Add(pnl);
            //Salon.Visible = true;

        }

        private void btnKoltuk_Click(object sender, EventArgs e)
        {

        }

        private void koltuk_Click(object sender, EventArgs e)
        {
            PictureBox pb = new PictureBox();
            pb = (sender as PictureBox);
            pb.Image = global::Sinema.Properties.Resources.koltukdolu;
            MessageBox.Show(pb.Tag.ToString());
        }
        private void lkoltuk_Click(object sender, EventArgs e)
        {
            Label l = new Label();
            l = (sender as Label);
            Label ls = new Label();
            String rbname = "LH" + l.Name.Substring(2, 5);
            Control[] matches = this.Controls.Find(rbname, true);
            ls = matches[0] as Label;
 
            if (l.ImageIndex != 2)
            {
                if (l.ImageIndex == 1)
                {
                    l.ImageIndex = 3;
                    l.ForeColor = Color.IndianRed;
                    if (tbSecilenler.Text.Equals(""))
                    { tbSecilenler.Text = ls.Text + l.Text; }
                    else tbSecilenler.Text = tbSecilenler.Text + "," + ls.Text + l.Text;
                }
                else
                {
                    l.ImageIndex = 1;
                    l.ForeColor = Color.Black;
                    tbSecilenler.Text= tbSecilenler.Text.Replace(ls.Text + l.Text+",", "");
                    tbSecilenler.Text = (tbSecilenler.Text+",").Replace(ls.Text + l.Text + ",", "");
                    tbSecilenler.Text= tbSecilenler.Text.Replace(",,", ",");
                    if (tbSecilenler.Text.Length > 0)
                    {
                        if (tbSecilenler.Text[tbSecilenler.Text.Length - 1] == ',')
                        {
                            tbSecilenler.Text = tbSecilenler.Text.Substring(0, tbSecilenler.Text.Length - 1);
                        }
                    }
                }
            }
      
       
        

            //MessageBox.Show(l.Tag.ToString());
        }
        private void lkoltuk_DoubleClick(object sender, EventArgs e)
        {
            Label l = new Label();
            l = (sender as Label);
            if (l.ImageIndex != 2)
            {
                l.ImageIndex = 2;
                l.Tag = 2;
                l.ForeColor = Color.Red;
            }
        }
        private void Form1_Paint(object sender, PaintEventArgs e)
        {/*
            Rectangle rectangle1 = new Rectangle(50, 50, 200, 100);
            Rectangle rectangle2 = new Rectangle(70, 20, 100, 200);

            e.Graphics.DrawRectangle(Pens.Black, rectangle1);
            e.Graphics.DrawRectangle(Pens.Red, rectangle2);
            /*

            if (rectangle1.IntersectsWith(rectangle2))
            {
                rectangle1.Intersect(rectangle2);
                if (!rectangle1.IsEmpty)
                {
                    e.Graphics.FillRectangle(Brushes.Green, rectangle1);
                }
            }
            */
        }


        private void pSalon_Paint(object sender, PaintEventArgs e)
        {/*
            Graphics g = gbSalon.CreateGraphics();
            Pen p = new Pen(Color.Black);

            if (listBox1.SelectedIndex == 0)
            {
                SolidBrush sb = new SolidBrush(Color.Red);
                g.DrawEllipse(p, xx - 50, yy - 50, 100, 100);
                g.FillEllipse(sb, xx - 50, yy - 50, 100, 100);

            }
            if (listBox1.SelectedIndex == 1)
            {
                SolidBrush sb = new SolidBrush(Color.Blue);
                g.DrawRectangle(p, xx - 50, yy - 50, 200, 200);
                g.FillRectangle(sb, xx - 50, yy - 50, 200, 200);
            }
            */
        }

        private void pSalon_MouseClick(object sender, MouseEventArgs e)
        {
            Point p = new Point(e.X, e.Y);
            xx = p.X;
            yy = p.Y;
            gbSalon.Invalidate();
        }

        private void rbGrupBox_CheckedChanged(object sender, EventArgs e)
        {
            gbSalon.Visible = false;
            gbSalon.Visible = true;
        }

        private void rbPanel_CheckedChanged(object sender, EventArgs e)
        {
            gbSalon.Visible = true;
            gbSalon.Visible = false;
        }

        private void PanelAddButton()
        {
            while (gbSalon.Controls.Count > 0)
            {
                gbSalon.Controls.RemoveAt(gbSalon.Controls.Count - 1);
            }
            int btnPos = 1;

            Panel pnl = new Panel();
            pnl.AutoScroll = true;
            pnl.Top = 15;
            pnl.Left = 2;
            pnl.Width = gbSalon.Width - 8;
            pnl.Height = gbSalon.Height - 18;

            for (int i = 0; i < 55; i++)
            {
                Button _btn = new Button();
                _btn.Text = "lbl" + i.ToString();
                _btn.Top = btnPos;
                btnPos += 23;
                pnl.Controls.Add(_btn);
            }
            gbSalon.Controls.Add(pnl);
        }

   
        private void Form1_ResizeEnd(object sender, EventArgs e)
        {
            gbSalon.Height = this.Height - 50;
        }

        private void Form1_MaximumSizeChanged(object sender, EventArgs e)
        {
            gbSalon.Height = this.Height - 50;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
        }

        private void button6_Click(object sender, EventArgs e)
        {
        }

        private void dgvSeanslar_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            Goster(e.RowIndex);
        }

        private void dtmTarih_ValueChanged(object sender, EventArgs e)
        {
            FilmListele();
            SeansListele();
            Goster(0);
        }

        private void dgvFilmler_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            SeansListele();
            Goster(0);
        }

        private void btnFilmler_Click(object sender, EventArgs e)
        {
            frmFilmGiris frm = new frmFilmGiris();
            frm.ShowDialog();
        }

        private void mcTarih_DateChanged(object sender, DateRangeEventArgs e)
        {
            MonthCalendar mcTarih = new MonthCalendar();
            dtmTarih.Value=mcTarih.SelectionStart;
        }

        private void btnSalonSema_Click(object sender, EventArgs e)
        {
            frmSalonSema frm = new frmSalonSema();
            frm.ShowDialog();
        }

        private void btnGarfik_Click(object sender, EventArgs e)
        {
            string[] basliklar = { "Bos", "Bos","Satılan" };

            int[] degerler = { 0, 0,0};
            this.chart1.Series.Clear();
            this.chart1.Titles.Clear();
            this.chart1.Titles.Add("Bos_Satılan Grafikleri");

          
            foreach (var item in gbSalon.Controls[1].Controls)
            {
                if (item is Label)
                {
                    Label pb = new Label();
                    pb = (item as Label);
                    if (pb.Name.StartsWith("LS"))
                    {
                        int i = int.Parse(pb.Tag.ToString());
                        degerler[i]++;
                    }
                }
              }
            string seriesname = "biletler";
            chart1.Series.Add(seriesname);
            //set the chart-type to "Pie"
            chart1.Series[seriesname].ChartType = SeriesChartType.Pie;

            //Add some datapoints so the series. in this case you can pass the values to this method
            chart1.Series[seriesname].Points.AddXY("Boş", degerler[1]);
            chart1.Series[seriesname].Points.AddXY("Satılan", degerler[2]);

            /*

            //Series nesnesi oluşturarak bölüm adlarını ve kontenjan bilgilerini ekledik.
          
            for (int i = 1; i < basliklar.Length; i++)

            {

                Series series = this.chart1.Series.Add(basliklar[i]);
                series.ChartType=SeriesChartType.Pie;

                series.Points.AddXY(degerler[i]);
            }
            */
        }
    }

    public class BaseForm : Form
    {
        protected void DrawBorder(Color c)
        {
            var g = CreateGraphics();
            var br = new SolidBrush(c);
            var p = new Pen(br, 2);
            var r = new Rectangle(0, 0, 50, this.Height - 40);
            g.DrawRectangle(p, r);
            p.Dispose();
            br.Dispose();
            g.Dispose();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            DrawBorder(this.BackColor);
            DrawBorder(Color.Red);
            base.OnPaint(e);
        }
    }
}
