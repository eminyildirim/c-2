﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
namespace Sinema
{
    class SqlBaglantisi
    {
        public SqlConnection baglanti()
        {
            SqlConnection baglan = new SqlConnection(@"Data Source=LAB02-12;Initial Catalog=Sinema;Integrated Security=True");
            baglan = new SqlConnection(@"Data Source=NBLENOVO;Initial Catalog=Sinema;Integrated Security=True");
            baglan = new SqlConnection(@"Data Source=LAB02-12;Initial Catalog=Sinema;Integrated Security=True");
            baglan.Open();
            return baglan;
        }

    }
}
