﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace form_kitaplar
{
    public partial class frmKitaplar : Form
    {
        public frmKitaplar()
        {
            InitializeComponent();
        }
        SqlConnection cn = new SqlConnection(@"Data Source=LAB02-12;Initial Catalog=Kitaplar;Integrated Security=True");

        private void frmKitaplar_Load(object sender, EventArgs e)
        {
            cn.Open();
            listele();
            cbturu.DataSource = ItemsDoldur("SELECT turad from dbo.turler order by turid",cn);
            cbturu.DisplayMember = "turad";
            cbyayinevi.DataSource = ItemsDoldur("SELECT yayinevi from dbo.yayinevi order by yayineviid", cn);
            cbyayinevi.DisplayMember = "yayinevi";
            dgwkitaplar.Rows[0].Selected = true;
            goster(dgwkitaplar.CurrentRow.Index);

        }
        public DataTable ItemsDoldur(String Sorgu, SqlConnection cn)
        {
            SqlCommand cmd = new SqlCommand(Sorgu, cn);         
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }

        private void btnliste_Click(object sender, EventArgs e)
        {
            listele();
        }
        void listele()
        {
            if (cn != null && cn.State == ConnectionState.Closed) { cn.Open(); }
               
           
            SqlCommand scmd = new SqlCommand("SELECT  [kitapad],[yazar],[sayfa],Fiyat,[yayinevi], dbo.turler.turad,dbo.kitap.turid,kitapid FROM  dbo.kitap INNER JOIN dbo.turler ON dbo.kitap.turid = dbo.turler.turid", cn);
            SqlDataAdapter sadp = new SqlDataAdapter(scmd);            
            DataTable dtkitap = new DataTable();
            sadp.Fill(dtkitap);
            dgwkitaplar.DataSource = dtkitap;
        }
        void goster(int rowIndex)        {
            
            DataGridViewRow row = dgwkitaplar.Rows[rowIndex];
            tbkitapadi.Text = row.Cells[0].Value.ToString();
            tbyazar.Text = row.Cells[1].Value.ToString();
            tbsayfa.Text = row.Cells[2].Value.ToString();
            tbfiyat.Text = row.Cells[3].Value.ToString();

            tbfiyat.Text = decimal.Parse(tbfiyat.Text).ToString("C");

            cbyayinevi.Text = row.Cells[4].Value.ToString();
            cbturu.SelectedIndex = int.Parse(row.Cells[6].Value.ToString()) - 1;
        }

        private void btnkayit_Click(object sender, EventArgs e)
        {
            if (cn != null && cn.State == ConnectionState.Closed) { cn.Open(); }

            String fiyattext = tbfiyat.Text.Replace(".", "").Replace(",", ",") + "";
            fiyattext = fiyattext.Substring(0, fiyattext.Length - 1);

            // String v = "'" + tbkitapadi.Text + "','" + tbyazar.Text + "'," + tbsayfa.Text + "," + fiyattext + ",'" + cbyayinevi.Text + "'," + (cbturu.SelectedIndex+1).ToString() + ")";

            SqlCommand scmd = new SqlCommand("INSERT INTO dbo.kitap (kitapad,yazar,sayfa,fiyat,yayinevi,turid) VALUES (@p1,@p2,@p3,@p4,@p5,@p6)", cn);
            /* 1 Yöntem
            scmd.Parameters.Add("@p1", SqlDbType.VarChar);
            scmd.Parameters.Add("@p2", SqlDbType.VarChar);
            scmd.Parameters.Add("@p3", SqlDbType.Int);
            scmd.Parameters.Add("@p4", SqlDbType.Money);
            scmd.Parameters.Add("@p5", SqlDbType.VarChar);
            scmd.Parameters.Add("@p6", SqlDbType.Int);

            scmd.Parameters["@p1"].Value = tbkitapadi.Text;
            scmd.Parameters["@p2"].Value = tbyazar.Text;
            scmd.Parameters["@p3"].Value = int.Parse(tbsayfa.Text);
            scmd.Parameters["@p4"].Value = Decimal.Parse(fiyattext);
            scmd.Parameters["@p5"].Value = cbyayinevi.Text;
            scmd.Parameters["@p6"].Value = cbturu.SelectedIndex + 1;
            */

            scmd.Parameters.AddWithValue("@p1", tbkitapadi.Text);
            scmd.Parameters.AddWithValue("@p2" , tbyazar.Text);
            scmd.Parameters.AddWithValue("@p3" , int.Parse(tbsayfa.Text));
            scmd.Parameters.AddWithValue("@p4" , Decimal.Parse(fiyattext));
            scmd.Parameters.AddWithValue("@p5" , cbyayinevi.Text);
            scmd.Parameters.AddWithValue("@p6", cbturu.SelectedIndex + 1);
            scmd.ExecuteNonQuery();
            listele();
            // MessageBox.Show(dgwkitaplar.RowCount.ToString());
            dgwkitaplar.Rows[dgwkitaplar.RowCount-1].Selected = true;
            goster(dgwkitaplar.RowCount-1);
            
        }

        private void dgwkitaplar_SelectionChanged(object sender, EventArgs e)
        {
            if (dgwkitaplar.CurrentRow.Index>-1)
            {
                goster(dgwkitaplar.CurrentRow.Index);
            }
        }

        private void btnsil_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Seçilen Kaydı Silmek istiyormusunuz?", "", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                if (cn != null && cn.State == ConnectionState.Closed) { cn.Open(); }
                int rowIndex = dgwkitaplar.CurrentRow.Index;
                DataGridViewRow row = dgwkitaplar.Rows[rowIndex];

                SqlCommand scmd = new SqlCommand("DELETE FROM dbo.kitap WHERE kitapid=" + row.Cells[7].Value.ToString(), cn);
                scmd.ExecuteNonQuery();
                listele();
            }

        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Kaydı Değiştirmek istiyormusunuz?", "", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                if (cn != null && cn.State == ConnectionState.Closed) { cn.Open(); }
                int rowIndex = dgwkitaplar.CurrentRow.Index;
                DataGridViewRow row = dgwkitaplar.Rows[rowIndex];
                String fiyattext = tbfiyat.Text.Replace(".", "").Replace(",", ".") + "";
                fiyattext = fiyattext.Substring(0, fiyattext.Length - 1);
                String sql = "UPDATE dbo.kitap SET kitapad='" + tbkitapadi.Text + "',yazar='" + tbyazar.Text + "',sayfa=" + tbsayfa.Text + ",fiyat=" + fiyattext + ",yayinevi='" + cbyayinevi.Text + "',turid=" + (cbturu.SelectedIndex + 1).ToString();
                sql = sql  +" WHERE kitapid=" + row.Cells[7].Value.ToString();
                // MessageBox.Show(sql);
                SqlCommand scmd = new SqlCommand(sql, cn);
                scmd.ExecuteNonQuery();
                listele();
                dgwkitaplar.Rows[rowIndex].Selected = true;
                goster(rowIndex);

            }
        }

        private void dgwkitaplar_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            goster(dgwkitaplar.CurrentRow.Index);
            tbkitapadi.Focus();
        }

        private void dgwkitaplar_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            goster(dgwkitaplar.CurrentRow.Index);
        }

        private void frmKitaplar_Resize(object sender, EventArgs e)
        {
            groupBox1.Height = this.Height - 120;
            dgwkitaplar.Height = groupBox1.Height - panel1.Height-40;
        }

        private void btnFontSec_Click(object sender, EventArgs e)
        {
            DialogResult result = fontsecim.ShowDialog();
            // See if user pressed ok.
            if (result == DialogResult.OK)
            {
                groupBox1.Font = fontsecim.Font;
            }
        }
    }
}
