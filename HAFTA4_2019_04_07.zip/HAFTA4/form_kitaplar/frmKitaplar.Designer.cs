﻿namespace form_kitaplar
{
    partial class frmKitaplar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tbkitapadi = new System.Windows.Forms.TextBox();
            this.tbyazar = new System.Windows.Forms.TextBox();
            this.tbsayfa = new System.Windows.Forms.TextBox();
            this.tbfiyat = new System.Windows.Forms.TextBox();
            this.cbyayinevi = new System.Windows.Forms.ComboBox();
            this.cbturu = new System.Windows.Forms.ComboBox();
            this.btnliste = new System.Windows.Forms.Button();
            this.btnkayit = new System.Windows.Forms.Button();
            this.btnsil = new System.Windows.Forms.Button();
            this.btnupdate = new System.Windows.Forms.Button();
            this.kitaplarDataSet = new form_kitaplar.KitaplarDataSet();
            this.kitapBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.kitapTableAdapter = new form_kitaplar.KitaplarDataSetTableAdapters.kitapTableAdapter();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dgwkitaplar = new System.Windows.Forms.DataGridView();
            this.kitapad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.yazar = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sayfa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fiyat = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.yayinevi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.turad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.turid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.kitapid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnFontSec = new System.Windows.Forms.Button();
            this.fontsecim = new System.Windows.Forms.FontDialog();
            ((System.ComponentModel.ISupportInitialize)(this.kitaplarDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kitapBindingSource)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgwkitaplar)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(53, 73);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Kitap Adı";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(53, 105);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Kitap Yazarı";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(53, 140);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Sayfa Sayısı";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(53, 175);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Fiyat";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(53, 206);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Yayın Evi";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(53, 237);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Türü";
            // 
            // tbkitapadi
            // 
            this.tbkitapadi.Location = new System.Drawing.Point(147, 73);
            this.tbkitapadi.Name = "tbkitapadi";
            this.tbkitapadi.Size = new System.Drawing.Size(309, 20);
            this.tbkitapadi.TabIndex = 6;
            // 
            // tbyazar
            // 
            this.tbyazar.Location = new System.Drawing.Point(147, 105);
            this.tbyazar.Name = "tbyazar";
            this.tbyazar.Size = new System.Drawing.Size(309, 20);
            this.tbyazar.TabIndex = 7;
            // 
            // tbsayfa
            // 
            this.tbsayfa.Location = new System.Drawing.Point(147, 132);
            this.tbsayfa.Name = "tbsayfa";
            this.tbsayfa.Size = new System.Drawing.Size(75, 20);
            this.tbsayfa.TabIndex = 8;
            this.tbsayfa.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbfiyat
            // 
            this.tbfiyat.Location = new System.Drawing.Point(147, 167);
            this.tbfiyat.Name = "tbfiyat";
            this.tbfiyat.Size = new System.Drawing.Size(75, 20);
            this.tbfiyat.TabIndex = 9;
            this.tbfiyat.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // cbyayinevi
            // 
            this.cbyayinevi.AllowDrop = true;
            this.cbyayinevi.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbyayinevi.FormattingEnabled = true;
            this.cbyayinevi.Location = new System.Drawing.Point(147, 206);
            this.cbyayinevi.Name = "cbyayinevi";
            this.cbyayinevi.Size = new System.Drawing.Size(121, 21);
            this.cbyayinevi.TabIndex = 10;
            // 
            // cbturu
            // 
            this.cbturu.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbturu.FormattingEnabled = true;
            this.cbturu.Location = new System.Drawing.Point(147, 237);
            this.cbturu.Name = "cbturu";
            this.cbturu.Size = new System.Drawing.Size(121, 21);
            this.cbturu.TabIndex = 11;
            // 
            // btnliste
            // 
            this.btnliste.Location = new System.Drawing.Point(56, 295);
            this.btnliste.Name = "btnliste";
            this.btnliste.Size = new System.Drawing.Size(75, 23);
            this.btnliste.TabIndex = 13;
            this.btnliste.Text = "Listele";
            this.btnliste.UseVisualStyleBackColor = true;
            this.btnliste.Click += new System.EventHandler(this.btnliste_Click);
            // 
            // btnkayit
            // 
            this.btnkayit.Location = new System.Drawing.Point(137, 295);
            this.btnkayit.Name = "btnkayit";
            this.btnkayit.Size = new System.Drawing.Size(75, 23);
            this.btnkayit.TabIndex = 14;
            this.btnkayit.Text = "Kaydet";
            this.btnkayit.UseVisualStyleBackColor = true;
            this.btnkayit.Click += new System.EventHandler(this.btnkayit_Click);
            // 
            // btnsil
            // 
            this.btnsil.Location = new System.Drawing.Point(299, 295);
            this.btnsil.Name = "btnsil";
            this.btnsil.Size = new System.Drawing.Size(75, 23);
            this.btnsil.TabIndex = 15;
            this.btnsil.Text = "Sil";
            this.btnsil.UseVisualStyleBackColor = true;
            this.btnsil.Click += new System.EventHandler(this.btnsil_Click);
            // 
            // btnupdate
            // 
            this.btnupdate.Location = new System.Drawing.Point(218, 295);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(75, 23);
            this.btnupdate.TabIndex = 16;
            this.btnupdate.Text = "Güncelle";
            this.btnupdate.UseVisualStyleBackColor = true;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // kitaplarDataSet
            // 
            this.kitaplarDataSet.DataSetName = "KitaplarDataSet";
            this.kitaplarDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // kitapBindingSource
            // 
            this.kitapBindingSource.DataMember = "kitap";
            this.kitapBindingSource.DataSource = this.kitaplarDataSet;
            // 
            // kitapTableAdapter
            // 
            this.kitapTableAdapter.ClearBeforeFill = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.panel1);
            this.groupBox1.Controls.Add(this.dgwkitaplar);
            this.groupBox1.Location = new System.Drawing.Point(462, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(661, 563);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "[ Kitap Listesi ]";
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(3, 510);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(655, 50);
            this.panel1.TabIndex = 14;
            // 
            // dgwkitaplar
            // 
            this.dgwkitaplar.AllowUserToAddRows = false;
            this.dgwkitaplar.AllowUserToDeleteRows = false;
            this.dgwkitaplar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgwkitaplar.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.kitapad,
            this.yazar,
            this.sayfa,
            this.fiyat,
            this.yayinevi,
            this.turad,
            this.turid,
            this.kitapid});
            this.dgwkitaplar.Dock = System.Windows.Forms.DockStyle.Top;
            this.dgwkitaplar.GridColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.dgwkitaplar.Location = new System.Drawing.Point(3, 16);
            this.dgwkitaplar.MultiSelect = false;
            this.dgwkitaplar.Name = "dgwkitaplar";
            this.dgwkitaplar.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgwkitaplar.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgwkitaplar.RowHeadersVisible = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgwkitaplar.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dgwkitaplar.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dgwkitaplar.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgwkitaplar.Size = new System.Drawing.Size(655, 488);
            this.dgwkitaplar.TabIndex = 13;
            this.dgwkitaplar.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgwkitaplar_CellClick);
            this.dgwkitaplar.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgwkitaplar_CellDoubleClick);
            // 
            // kitapad
            // 
            this.kitapad.DataPropertyName = "kitapad";
            this.kitapad.HeaderText = "Kitap Adı";
            this.kitapad.Name = "kitapad";
            this.kitapad.ReadOnly = true;
            this.kitapad.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.kitapad.Width = 150;
            // 
            // yazar
            // 
            this.yazar.DataPropertyName = "yazar";
            this.yazar.HeaderText = "Kitap yazarı";
            this.yazar.MaxInputLength = 50;
            this.yazar.Name = "yazar";
            this.yazar.ReadOnly = true;
            this.yazar.Width = 150;
            // 
            // sayfa
            // 
            this.sayfa.DataPropertyName = "sayfa";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle1.Format = "N0";
            dataGridViewCellStyle1.NullValue = null;
            this.sayfa.DefaultCellStyle = dataGridViewCellStyle1;
            this.sayfa.HeaderText = "Sayfa Sayısı";
            this.sayfa.MaxInputLength = 4;
            this.sayfa.Name = "sayfa";
            this.sayfa.ReadOnly = true;
            this.sayfa.Width = 80;
            // 
            // fiyat
            // 
            this.fiyat.DataPropertyName = "fiyat";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle2.Format = "C2";
            dataGridViewCellStyle2.NullValue = null;
            this.fiyat.DefaultCellStyle = dataGridViewCellStyle2;
            this.fiyat.HeaderText = "Fiyat";
            this.fiyat.Name = "fiyat";
            this.fiyat.ReadOnly = true;
            this.fiyat.Width = 50;
            // 
            // yayinevi
            // 
            this.yayinevi.DataPropertyName = "yayinevi";
            this.yayinevi.HeaderText = "Yayın Evi";
            this.yayinevi.MaxInputLength = 50;
            this.yayinevi.Name = "yayinevi";
            this.yayinevi.ReadOnly = true;
            // 
            // turad
            // 
            this.turad.DataPropertyName = "turad";
            this.turad.HeaderText = "Kitap Türü";
            this.turad.MaxInputLength = 50;
            this.turad.Name = "turad";
            this.turad.ReadOnly = true;
            // 
            // turid
            // 
            this.turid.DataPropertyName = "turid";
            this.turid.HeaderText = "Tür id";
            this.turid.Name = "turid";
            this.turid.ReadOnly = true;
            this.turid.Visible = false;
            this.turid.Width = 5;
            // 
            // kitapid
            // 
            this.kitapid.DataPropertyName = "kitapid";
            this.kitapid.HeaderText = "kitapid";
            this.kitapid.Name = "kitapid";
            this.kitapid.ReadOnly = true;
            this.kitapid.Visible = false;
            // 
            // btnFontSec
            // 
            this.btnFontSec.Location = new System.Drawing.Point(384, 295);
            this.btnFontSec.Name = "btnFontSec";
            this.btnFontSec.Size = new System.Drawing.Size(60, 23);
            this.btnFontSec.TabIndex = 18;
            this.btnFontSec.Text = "Font";
            this.btnFontSec.UseVisualStyleBackColor = true;
            this.btnFontSec.Click += new System.EventHandler(this.btnFontSec_Click);
            // 
            // frmKitaplar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1304, 616);
            this.Controls.Add(this.btnFontSec);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnupdate);
            this.Controls.Add(this.btnsil);
            this.Controls.Add(this.btnkayit);
            this.Controls.Add(this.btnliste);
            this.Controls.Add(this.cbturu);
            this.Controls.Add(this.cbyayinevi);
            this.Controls.Add(this.tbfiyat);
            this.Controls.Add(this.tbsayfa);
            this.Controls.Add(this.tbyazar);
            this.Controls.Add(this.tbkitapadi);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "frmKitaplar";
            this.Text = "Kitaplar";
            this.Load += new System.EventHandler(this.frmKitaplar_Load);
            this.Resize += new System.EventHandler(this.frmKitaplar_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.kitaplarDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kitapBindingSource)).EndInit();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgwkitaplar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbkitapadi;
        private System.Windows.Forms.TextBox tbyazar;
        private System.Windows.Forms.TextBox tbsayfa;
        private System.Windows.Forms.TextBox tbfiyat;
        private System.Windows.Forms.ComboBox cbyayinevi;
        private System.Windows.Forms.ComboBox cbturu;
        private System.Windows.Forms.Button btnliste;
        private System.Windows.Forms.Button btnkayit;
        private System.Windows.Forms.Button btnsil;
        private System.Windows.Forms.Button btnupdate;
        private KitaplarDataSet kitaplarDataSet;
        private System.Windows.Forms.BindingSource kitapBindingSource;
        private KitaplarDataSetTableAdapters.kitapTableAdapter kitapTableAdapter;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dgwkitaplar;
        private System.Windows.Forms.DataGridViewTextBoxColumn kitapad;
        private System.Windows.Forms.DataGridViewTextBoxColumn yazar;
        private System.Windows.Forms.DataGridViewTextBoxColumn sayfa;
        private System.Windows.Forms.DataGridViewTextBoxColumn fiyat;
        private System.Windows.Forms.DataGridViewTextBoxColumn yayinevi;
        private System.Windows.Forms.DataGridViewTextBoxColumn turad;
        private System.Windows.Forms.DataGridViewTextBoxColumn turid;
        private System.Windows.Forms.DataGridViewTextBoxColumn kitapid;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnFontSec;
        private System.Windows.Forms.FontDialog fontsecim;
    }
}

