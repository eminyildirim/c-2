﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MathFonksiyonlar
{
    public partial class Form1 : Form
    {
        public int sayigetir()
        {
            Random rnd = new Random();
            int sayi = rnd.Next(0, 29);
            return sayi;
        }
        public String harfgetir()
        {
            String harfler = "ABCDEFGHIJKLMNOPQRSTUWXYZ";
            Random rnd = new Random();
            int sayi = rnd.Next(0, harfler.Length - 1);

            return harfler[sayi].ToString();
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add(harfgetir());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Double sayi, sonuc = 0;
            Random rnd = new Random();
            sayi = rnd.Next(10, 129);
            sonuc = Math.Pow(sayi, 2);
            listBox1.Items.Add(sayi.ToString() + " karesi>" + sonuc.ToString());
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Double sayi, sonuc = 0;
            Random rnd = new Random();
            sayi = rnd.Next(1, 999);
            sonuc = Math.Pow(sayi, 0.5);
            listBox1.Items.Add(sayi.ToString() + " Kare Kökü > " + sonuc.ToString());
        }

        private void hScrollBar1_ValueChanged(object sender, EventArgs e)
        {
            listBox1.Items.Add(hScrollBar1.Value.ToString());
        }

        private void toolStripContainer1_TopToolStripPanel_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            String t = "";
            foreach (var item in tbgiris.Text)
            {
                t = item + t;
            }
            MessageBox.Show(tbgiris.Text + "\r\n" + t);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (tbgiris.Text.IndexOf(tbaranacak.Text) > -1)
            {
                MessageBox.Show(tbgiris.Text + " içinde " + tbaranacak.Text + " var");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (tbgiris.Text.StartsWith(tbaranacak.Text))
            {
                MessageBox.Show(tbgiris.Text.Trim().ToUpper() + " " + tbaranacak.Text + " ile başlıyor");

            }
            if (tbgiris.Text.Length > 0)
            {
                tbgiris.Text = tbgiris.Text.Remove(tbgiris.Text.Length - 1);
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            tbgiris.Text = tbgiris.Text.Replace(tbaranacak.Text, "DEĞİŞTİ");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < int.Parse(tbsayi.Text); i++)
            {
                TextBox tb = new TextBox();
                tb.Name = "mytb" + i.ToString();
                tb.Location = new System.Drawing.Point(564, i*20+ tbsayi.Top+30);
                this.Controls.Add(tb);
            }
        }
    }

}
