﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace webbrowser
{
    public partial class frmWebTest : Form
    {
        public frmWebTest()
        {
            InitializeComponent();
        }
        public string Adi { get; set; }
        public string Soyadi { get; set; }
        private void frmWebTest_Load(object sender, EventArgs e)
        {
            this.Text = "Web Browser Deneme (" + "Merhaba " + Adi + " " + Soyadi + ")";
            frmGIRIS frm = new frmGIRIS();
            frm.Close();
        }

        private void komediToolStripMenuItem_Click(object sender, EventArgs e)
        {
            webBrowser1.Navigate("https://www.youtube.com/watch?v=Gf36hf8Jfl8");
        }

        private void frmWebTest_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void hürriyetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            webBrowser1.Navigate("https://www.hurriyet.com.tr");
        }

        private void milliyetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            webBrowser1.Navigate("https://www.milliyet.com.tr");
        }

        private void sabahToolStripMenuItem_Click(object sender, EventArgs e)
        {
            webBrowser1.Navigate("http://www.sabah.com.tr");
        }

        private void benimSayfamToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // webBrowser1.DocumentText="<!DOCTYPE html><html><body><article><header><h1>C# WEBBROWSER DENEME</h1><h3>BAŞLIK 3 SEVİYE</h3><p>Some additional information here.</p></header><p>Lorem Ipsum dolor set amet....</p></article></body></html>";

            String kod = "<!DOCTYPE html>" +
            "<html>" +
            "<body>" +
            "<iframe src='https://www.milport.com.tr' width='100%' height='600px'>" +
            "  <p>Your browser does not support iframes.</p>" +
            "</iframe>" +
            "</body>" +
            "</html>";
            kod= kod.Replace((char)39,(char)34);
            webBrowser1.DocumentText = kod;
        }
        private void dramToolStripMenuItem_Click(object sender, EventArgs e)
        {
            webBrowser1.Navigate("https://www.youtube.com/watch?v=wPsDYhxyYe8");
        }

        private void cizgiFilmToolStripMenuItem_Click(object sender, EventArgs e)
        {
            webBrowser1.Navigate("https://youtu.be/EHu-WpiaNHw");
        }

        private void toolStripComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            String[] url = new String[] { "https://www.tcmb.gov.tr", "https://www.garanti.com.tr", "https://www.isbank.com.tr" , "https://www.isbank.com.tr" };
            webBrowser1.Navigate(url[toolStripComboBox1.SelectedIndex]);

            /*
            switch (toolStripComboBox1.SelectedIndex)
            {
                case 0:
                    {
                        webBrowser1.Navigate("https://www.tcmb.gov.tr");
                        break;
                    }
                case 1:
                    {
                        webBrowser1.Navigate("https://www.garanti.com.tr");
                        break;
                    }
                case 2:
                    {
                        webBrowser1.Navigate("https://www.isbank.com.tr");
                        break;
                    }
                case 3:
                    {
                        webBrowser1.Navigate("https://www.ykb.com.tr");
                        break;
                    }
                default:
                    break;
            }
            */
            
        }
    }
}
