﻿namespace webbrowser
{
    partial class frmWebTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.filmlerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.komediToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dramToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cizgiFilmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.gazatelerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hürriyetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.milliyetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sabahToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.benimSayfamToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripComboBox1 = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.filmlerToolStripMenuItem,
            this.gazatelerToolStripMenuItem,
            this.toolStripComboBox1,
            this.toolStripTextBox1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1119, 27);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // filmlerToolStripMenuItem
            // 
            this.filmlerToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.komediToolStripMenuItem,
            this.dramToolStripMenuItem,
            this.cizgiFilmToolStripMenuItem});
            this.filmlerToolStripMenuItem.Name = "filmlerToolStripMenuItem";
            this.filmlerToolStripMenuItem.Size = new System.Drawing.Size(55, 23);
            this.filmlerToolStripMenuItem.Text = "Filmler";
            // 
            // komediToolStripMenuItem
            // 
            this.komediToolStripMenuItem.Name = "komediToolStripMenuItem";
            this.komediToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.komediToolStripMenuItem.Text = "Komedi";
            this.komediToolStripMenuItem.Click += new System.EventHandler(this.komediToolStripMenuItem_Click);
            // 
            // dramToolStripMenuItem
            // 
            this.dramToolStripMenuItem.Name = "dramToolStripMenuItem";
            this.dramToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.dramToolStripMenuItem.Text = "Dram";
            this.dramToolStripMenuItem.Click += new System.EventHandler(this.dramToolStripMenuItem_Click);
            // 
            // cizgiFilmToolStripMenuItem
            // 
            this.cizgiFilmToolStripMenuItem.Name = "cizgiFilmToolStripMenuItem";
            this.cizgiFilmToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.cizgiFilmToolStripMenuItem.Text = "Cizgi Film";
            this.cizgiFilmToolStripMenuItem.Click += new System.EventHandler(this.cizgiFilmToolStripMenuItem_Click);
            // 
            // webBrowser1
            // 
            this.webBrowser1.Location = new System.Drawing.Point(12, 44);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.Size = new System.Drawing.Size(1029, 533);
            this.webBrowser1.TabIndex = 1;
            // 
            // gazatelerToolStripMenuItem
            // 
            this.gazatelerToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hürriyetToolStripMenuItem,
            this.milliyetToolStripMenuItem,
            this.sabahToolStripMenuItem,
            this.benimSayfamToolStripMenuItem});
            this.gazatelerToolStripMenuItem.Name = "gazatelerToolStripMenuItem";
            this.gazatelerToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.gazatelerToolStripMenuItem.Text = "Gazateler";
            // 
            // hürriyetToolStripMenuItem
            // 
            this.hürriyetToolStripMenuItem.Name = "hürriyetToolStripMenuItem";
            this.hürriyetToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.hürriyetToolStripMenuItem.Text = "Hürriyet";
            this.hürriyetToolStripMenuItem.Click += new System.EventHandler(this.hürriyetToolStripMenuItem_Click);
            // 
            // milliyetToolStripMenuItem
            // 
            this.milliyetToolStripMenuItem.Name = "milliyetToolStripMenuItem";
            this.milliyetToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.milliyetToolStripMenuItem.Text = "Milliyet";
            this.milliyetToolStripMenuItem.Click += new System.EventHandler(this.milliyetToolStripMenuItem_Click);
            // 
            // sabahToolStripMenuItem
            // 
            this.sabahToolStripMenuItem.Name = "sabahToolStripMenuItem";
            this.sabahToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.sabahToolStripMenuItem.Text = "Sabah";
            this.sabahToolStripMenuItem.Click += new System.EventHandler(this.sabahToolStripMenuItem_Click);
            // 
            // benimSayfamToolStripMenuItem
            // 
            this.benimSayfamToolStripMenuItem.Name = "benimSayfamToolStripMenuItem";
            this.benimSayfamToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.benimSayfamToolStripMenuItem.Text = "Benim Sayfam";
            this.benimSayfamToolStripMenuItem.Click += new System.EventHandler(this.benimSayfamToolStripMenuItem_Click);
            // 
            // toolStripComboBox1
            // 
            this.toolStripComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.toolStripComboBox1.Items.AddRange(new object[] {
            "Merkez Bankası",
            "Garanti",
            "İş Bankası",
            "Yapı Kredi"});
            this.toolStripComboBox1.Name = "toolStripComboBox1";
            this.toolStripComboBox1.Size = new System.Drawing.Size(121, 23);
            this.toolStripComboBox1.SelectedIndexChanged += new System.EventHandler(this.toolStripComboBox1_SelectedIndexChanged);
            // 
            // toolStripTextBox1
            // 
            this.toolStripTextBox1.Name = "toolStripTextBox1";
            this.toolStripTextBox1.Size = new System.Drawing.Size(100, 23);
            this.toolStripTextBox1.Text = "Menu TextBox Nedir";
            // 
            // frmWebTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1119, 638);
            this.Controls.Add(this.webBrowser1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmWebTest";
            this.Text = "Web Browser Deneme";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmWebTest_FormClosed);
            this.Load += new System.EventHandler(this.frmWebTest_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem filmlerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem komediToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dramToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cizgiFilmToolStripMenuItem;
        private System.Windows.Forms.WebBrowser webBrowser1;
        private System.Windows.Forms.ToolStripMenuItem gazatelerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hürriyetToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem milliyetToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sabahToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem benimSayfamToolStripMenuItem;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBox1;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox1;
    }
}