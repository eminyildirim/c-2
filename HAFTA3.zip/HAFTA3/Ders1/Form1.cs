﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ders1
{
    public partial class Form1 : Form
    {
        int sayac = 0;
        DateTime baszaman = DateTime.Now;
        public Form1()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (sayac<30)
            {
                pkirmizi.BackColor = Color.Red;
                psari.BackColor = Color.White;
                pyesil.BackColor = Color.White;
                label1.Text = sayac.ToString();
            }
            else
                         if (sayac < 60)
            {
                pkirmizi.BackColor = Color.White;
                psari.BackColor = Color.Yellow;
                pyesil.BackColor = Color.White;
            }
            else
                         if (sayac < 90)
            {
                pkirmizi.BackColor = Color.White;
                psari.BackColor = Color.White;
                pyesil.BackColor = Color.Green;
            }
            else
   
            {
                pkirmizi.BackColor = Color.White;
                psari.BackColor = Color.White;
                pyesil.BackColor = Color.White;
                timer1.Enabled = false;
                sayac = 0;
            }
            sayac++;
        }

        private void btnBasla_Click(object sender, EventArgs e)
        {
            pkirmizi.BackColor = Color.White;
            psari.BackColor = Color.White;
            pyesil.BackColor = Color.White;
            timer1.Enabled = true;
            DateTime baszaman = DateTime.Now;
            pkirmizi.BackColor = Color.Red;
        }
    }
}
