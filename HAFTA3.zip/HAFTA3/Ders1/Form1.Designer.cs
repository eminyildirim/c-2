﻿namespace Ders1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.pkirmizi = new System.Windows.Forms.Panel();
            this.psari = new System.Windows.Forms.Panel();
            this.pyesil = new System.Windows.Forms.Panel();
            this.btnBasla = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pkirmizi.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // pkirmizi
            // 
            this.pkirmizi.Controls.Add(this.label1);
            this.pkirmizi.Location = new System.Drawing.Point(298, 48);
            this.pkirmizi.Name = "pkirmizi";
            this.pkirmizi.Size = new System.Drawing.Size(77, 56);
            this.pkirmizi.TabIndex = 0;
            // 
            // psari
            // 
            this.psari.Location = new System.Drawing.Point(298, 110);
            this.psari.Name = "psari";
            this.psari.Size = new System.Drawing.Size(77, 56);
            this.psari.TabIndex = 1;
            // 
            // pyesil
            // 
            this.pyesil.Location = new System.Drawing.Point(298, 172);
            this.pyesil.Name = "pyesil";
            this.pyesil.Size = new System.Drawing.Size(77, 56);
            this.pyesil.TabIndex = 1;
            // 
            // btnBasla
            // 
            this.btnBasla.Location = new System.Drawing.Point(33, 48);
            this.btnBasla.Name = "btnBasla";
            this.btnBasla.Size = new System.Drawing.Size(75, 23);
            this.btnBasla.TabIndex = 2;
            this.btnBasla.Text = "Başla";
            this.btnBasla.UseVisualStyleBackColor = true;
            this.btnBasla.Click += new System.EventHandler(this.btnBasla_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "label1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(488, 410);
            this.Controls.Add(this.btnBasla);
            this.Controls.Add(this.pyesil);
            this.Controls.Add(this.psari);
            this.Controls.Add(this.pkirmizi);
            this.Name = "Form1";
            this.Text = "Form1";
            this.pkirmizi.ResumeLayout(false);
            this.pkirmizi.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Panel pkirmizi;
        private System.Windows.Forms.Panel psari;
        private System.Windows.Forms.Panel pyesil;
        private System.Windows.Forms.Button btnBasla;
        private System.Windows.Forms.Label label1;
    }
}

