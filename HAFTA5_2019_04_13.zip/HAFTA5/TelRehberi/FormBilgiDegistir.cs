﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TelRehberi
{
    public partial class FormBilgiDegistir : Form
    {
       
        public int ffID { get; set; }
        public string ffuser { get; set; }
        public string ffsifre { get; set; }

        public SqlConnection cn = new SqlConnection(@"Data Source=LAB02-12;Initial Catalog=Rehber;Integrated Security=True");
        public SqlCommand cmd;
        public SqlDataReader dr;
        public FormBilgiDegistir()
        {
   
            InitializeComponent();
        }

        private void msCikis_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void FormBilgiDegistir_Load(object sender, EventArgs e)
        {
            tbUsername.Text = ffuser;
            tbSifre.Text = ffsifre;
        }

        private void btnDegistir_Click(object sender, EventArgs e)
        {
            if (cn != null && cn.State == ConnectionState.Closed) { cn.Open(); }
    
            SqlCommand scmd = new SqlCommand("UPDATE dbo.users SET Kisi_ad = @P1,Kisi_sifre =@P2 WHERE Kisi_ID = @P3", cn);
            scmd.Parameters.AddWithValue("@p1", tbUsername.Text);
            scmd.Parameters.AddWithValue("@p2", tbSifre.Text);
            scmd.Parameters.AddWithValue("@p3", ffID);
      
            scmd.ExecuteNonQuery();
            msGirisSayfasi.PerformClick();
        }

        private void msGirisSayfasi_Click(object sender, EventArgs e)
        {
            FormGiris frm = new FormGiris();
            this.Hide();
            frm.Show();
            frm.msKul.Visible = true;
            frm.msReh.Visible = true;
        }
    }
}
