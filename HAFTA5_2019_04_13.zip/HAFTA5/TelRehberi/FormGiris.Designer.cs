﻿namespace TelRehberi
{
    partial class FormGiris
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pGiris = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.cbsifreunuttum = new System.Windows.Forms.CheckBox();
            this.btnGiris = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tbSifre = new System.Windows.Forms.TextBox();
            this.tbUsername = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.msKul = new System.Windows.Forms.ToolStripMenuItem();
            this.msBilgiDegistir = new System.Windows.Forms.ToolStripMenuItem();
            this.msKullaniciEkle = new System.Windows.Forms.ToolStripMenuItem();
            this.msKullaniciSil = new System.Windows.Forms.ToolStripMenuItem();
            this.msCikisYap = new System.Windows.Forms.ToolStripMenuItem();
            this.msReh = new System.Windows.Forms.ToolStripMenuItem();
            this.msCikis = new System.Windows.Forms.ToolStripMenuItem();
            this.pEkle = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tbsifreekle = new System.Windows.Forms.TextBox();
            this.tbuserekle = new System.Windows.Forms.TextBox();
            this.pSil = new System.Windows.Forms.Panel();
            this.dgwusers = new System.Windows.Forms.DataGridView();
            this.Kisi_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Kisi_ad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnKisiSil = new System.Windows.Forms.Button();
            this.lgiris = new System.Windows.Forms.Label();
            this.pGiris.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.pEkle.SuspendLayout();
            this.pSil.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgwusers)).BeginInit();
            this.SuspendLayout();
            // 
            // pGiris
            // 
            this.pGiris.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.pGiris.Controls.Add(this.label3);
            this.pGiris.Controls.Add(this.cbsifreunuttum);
            this.pGiris.Controls.Add(this.btnGiris);
            this.pGiris.Controls.Add(this.label2);
            this.pGiris.Controls.Add(this.label1);
            this.pGiris.Controls.Add(this.tbSifre);
            this.pGiris.Controls.Add(this.tbUsername);
            this.pGiris.Location = new System.Drawing.Point(12, 36);
            this.pGiris.Name = "pGiris";
            this.pGiris.Size = new System.Drawing.Size(344, 190);
            this.pGiris.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(70, 3);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(153, 24);
            this.label3.TabIndex = 8;
            this.label3.Text = "LOGIN EKRANI";
            // 
            // cbsifreunuttum
            // 
            this.cbsifreunuttum.AutoSize = true;
            this.cbsifreunuttum.Location = new System.Drawing.Point(196, 133);
            this.cbsifreunuttum.Name = "cbsifreunuttum";
            this.cbsifreunuttum.Size = new System.Drawing.Size(100, 17);
            this.cbsifreunuttum.TabIndex = 7;
            this.cbsifreunuttum.Text = "Şifremi Unuttum";
            this.cbsifreunuttum.UseVisualStyleBackColor = true;
            this.cbsifreunuttum.CheckedChanged += new System.EventHandler(this.cbsifreunuttum_CheckedChanged);
            // 
            // btnGiris
            // 
            this.btnGiris.Location = new System.Drawing.Point(196, 104);
            this.btnGiris.Name = "btnGiris";
            this.btnGiris.Size = new System.Drawing.Size(100, 23);
            this.btnGiris.TabIndex = 6;
            this.btnGiris.Text = "Giriş";
            this.btnGiris.UseVisualStyleBackColor = true;
            this.btnGiris.Click += new System.EventHandler(this.btnGiris_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(26, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Şifre:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Kullanıcı:";
            // 
            // tbSifre
            // 
            this.tbSifre.Location = new System.Drawing.Point(74, 78);
            this.tbSifre.Name = "tbSifre";
            this.tbSifre.PasswordChar = '*';
            this.tbSifre.Size = new System.Drawing.Size(232, 20);
            this.tbSifre.TabIndex = 3;
            this.tbSifre.Text = "1234";
            // 
            // tbUsername
            // 
            this.tbUsername.Location = new System.Drawing.Point(74, 40);
            this.tbUsername.Name = "tbUsername";
            this.tbUsername.Size = new System.Drawing.Size(232, 20);
            this.tbUsername.TabIndex = 2;
            this.tbUsername.Text = "emin";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.msKul,
            this.msReh,
            this.msCikis});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1179, 24);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // msKul
            // 
            this.msKul.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.msBilgiDegistir,
            this.msKullaniciEkle,
            this.msKullaniciSil,
            this.msCikisYap});
            this.msKul.Name = "msKul";
            this.msKul.Size = new System.Drawing.Size(111, 20);
            this.msKul.Text = "Kullanıcı İşlemleri";
            // 
            // msBilgiDegistir
            // 
            this.msBilgiDegistir.Name = "msBilgiDegistir";
            this.msBilgiDegistir.Size = new System.Drawing.Size(170, 22);
            this.msBilgiDegistir.Text = "Bilgilerimi Değiştir";
            this.msBilgiDegistir.Click += new System.EventHandler(this.msBilgiDegistir_Click);
            // 
            // msKullaniciEkle
            // 
            this.msKullaniciEkle.Name = "msKullaniciEkle";
            this.msKullaniciEkle.Size = new System.Drawing.Size(170, 22);
            this.msKullaniciEkle.Text = "Kullanıcı Ekle";
            this.msKullaniciEkle.Click += new System.EventHandler(this.msKullaniciEkle_Click);
            // 
            // msKullaniciSil
            // 
            this.msKullaniciSil.Name = "msKullaniciSil";
            this.msKullaniciSil.Size = new System.Drawing.Size(170, 22);
            this.msKullaniciSil.Text = "Kullanıcı Sil";
            this.msKullaniciSil.Click += new System.EventHandler(this.msKullaniciSil_Click);
            // 
            // msCikisYap
            // 
            this.msCikisYap.Name = "msCikisYap";
            this.msCikisYap.Size = new System.Drawing.Size(170, 22);
            this.msCikisYap.Text = "Çıkış Yap";
            this.msCikisYap.Click += new System.EventHandler(this.msCikisYap_Click);
            // 
            // msReh
            // 
            this.msReh.Name = "msReh";
            this.msReh.Size = new System.Drawing.Size(82, 20);
            this.msReh.Text = "Rehber Giriş";
            this.msReh.Click += new System.EventHandler(this.rehberGirişToolStripMenuItem_Click);
            // 
            // msCikis
            // 
            this.msCikis.Name = "msCikis";
            this.msCikis.Size = new System.Drawing.Size(44, 20);
            this.msCikis.Text = "Çıkış";
            this.msCikis.Click += new System.EventHandler(this.çıkışToolStripMenuItem_Click);
            // 
            // pEkle
            // 
            this.pEkle.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.pEkle.Controls.Add(this.label7);
            this.pEkle.Controls.Add(this.label6);
            this.pEkle.Controls.Add(this.textBox1);
            this.pEkle.Controls.Add(this.button1);
            this.pEkle.Controls.Add(this.label4);
            this.pEkle.Controls.Add(this.label5);
            this.pEkle.Controls.Add(this.tbsifreekle);
            this.pEkle.Controls.Add(this.tbuserekle);
            this.pEkle.Location = new System.Drawing.Point(362, 36);
            this.pEkle.Name = "pEkle";
            this.pEkle.Size = new System.Drawing.Size(343, 190);
            this.pEkle.TabIndex = 5;
            this.pEkle.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.Location = new System.Drawing.Point(28, 13);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(168, 24);
            this.label7.TabIndex = 9;
            this.label7.Text = "Kullanıcı EKleme";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 130);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "Yeni Şifre:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(74, 127);
            this.textBox1.Name = "textBox1";
            this.textBox1.PasswordChar = '*';
            this.textBox1.Size = new System.Drawing.Size(232, 20);
            this.textBox1.TabIndex = 7;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(206, 153);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "Kayıt";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(34, 100);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(31, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Şifre:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(16, 62);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Kullanıcı:";
            // 
            // tbsifreekle
            // 
            this.tbsifreekle.Location = new System.Drawing.Point(74, 97);
            this.tbsifreekle.Name = "tbsifreekle";
            this.tbsifreekle.PasswordChar = '*';
            this.tbsifreekle.Size = new System.Drawing.Size(232, 20);
            this.tbsifreekle.TabIndex = 3;
            // 
            // tbuserekle
            // 
            this.tbuserekle.Location = new System.Drawing.Point(71, 59);
            this.tbuserekle.Name = "tbuserekle";
            this.tbuserekle.Size = new System.Drawing.Size(232, 20);
            this.tbuserekle.TabIndex = 2;
            // 
            // pSil
            // 
            this.pSil.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.pSil.Controls.Add(this.dgwusers);
            this.pSil.Controls.Add(this.btnKisiSil);
            this.pSil.Location = new System.Drawing.Point(722, 39);
            this.pSil.Name = "pSil";
            this.pSil.Size = new System.Drawing.Size(337, 357);
            this.pSil.TabIndex = 10;
            this.pSil.Visible = false;
            // 
            // dgwusers
            // 
            this.dgwusers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgwusers.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Kisi_ID,
            this.Kisi_ad});
            this.dgwusers.Location = new System.Drawing.Point(3, 3);
            this.dgwusers.Name = "dgwusers";
            this.dgwusers.Size = new System.Drawing.Size(271, 351);
            this.dgwusers.TabIndex = 7;
            // 
            // Kisi_ID
            // 
            this.Kisi_ID.DataPropertyName = "Kisi_ID";
            this.Kisi_ID.HeaderText = "Kisi_ID";
            this.Kisi_ID.Name = "Kisi_ID";
            this.Kisi_ID.Visible = false;
            // 
            // Kisi_ad
            // 
            this.Kisi_ad.DataPropertyName = "Kisi_ad";
            this.Kisi_ad.HeaderText = "Kisi_ad";
            this.Kisi_ad.Name = "Kisi_ad";
            this.Kisi_ad.Width = 200;
            // 
            // btnKisiSil
            // 
            this.btnKisiSil.Location = new System.Drawing.Point(277, 19);
            this.btnKisiSil.Name = "btnKisiSil";
            this.btnKisiSil.Size = new System.Drawing.Size(57, 23);
            this.btnKisiSil.TabIndex = 6;
            this.btnKisiSil.Text = "Sil";
            this.btnKisiSil.UseVisualStyleBackColor = true;
            // 
            // lgiris
            // 
            this.lgiris.AutoSize = true;
            this.lgiris.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lgiris.Location = new System.Drawing.Point(12, 40);
            this.lgiris.Name = "lgiris";
            this.lgiris.Size = new System.Drawing.Size(88, 25);
            this.lgiris.TabIndex = 11;
            this.lgiris.Text = "LOGİN ";
            this.lgiris.Visible = false;
            // 
            // FormGiris
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.HotTrack;
            this.ClientSize = new System.Drawing.Size(1179, 539);
            this.Controls.Add(this.lgiris);
            this.Controls.Add(this.pSil);
            this.Controls.Add(this.pEkle);
            this.Controls.Add(this.pGiris);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FormGiris";
            this.Text = "Login Sayfa";
            this.Load += new System.EventHandler(this.FormGiris_Load);
            this.pGiris.ResumeLayout(false);
            this.pGiris.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.pEkle.ResumeLayout(false);
            this.pEkle.PerformLayout();
            this.pSil.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgwusers)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pGiris;
        private System.Windows.Forms.CheckBox cbsifreunuttum;
        private System.Windows.Forms.Button btnGiris;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbSifre;
        private System.Windows.Forms.TextBox tbUsername;
        private System.Windows.Forms.MenuStrip menuStrip1;
        public System.Windows.Forms.ToolStripMenuItem msKul;
        private System.Windows.Forms.ToolStripMenuItem msBilgiDegistir;
        private System.Windows.Forms.ToolStripMenuItem msCikisYap;
        private System.Windows.Forms.ToolStripMenuItem msKullaniciEkle;
        private System.Windows.Forms.ToolStripMenuItem msKullaniciSil;
        private System.Windows.Forms.Panel pEkle;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbsifreekle;
        private System.Windows.Forms.TextBox tbuserekle;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel pSil;
        private System.Windows.Forms.DataGridView dgwusers;
        private System.Windows.Forms.DataGridViewTextBoxColumn Kisi_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Kisi_ad;
        private System.Windows.Forms.Button btnKisiSil;
        public System.Windows.Forms.ToolStripMenuItem msReh;
        private System.Windows.Forms.ToolStripMenuItem msCikis;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lgiris;
    }
}

