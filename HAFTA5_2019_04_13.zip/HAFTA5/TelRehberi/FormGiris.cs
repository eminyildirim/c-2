﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TelRehberi
{
    public partial class FormGiris : Form
    {
        public Boolean admin = false;

        public FormGiris()
        {
            InitializeComponent();
        }
        public SqlConnection cn = new SqlConnection(@"Data Source=LAB02-12;Initial Catalog=Rehber;Integrated Security=True");
        public SqlCommand cmd;
        public SqlDataReader dr;
        private void msCikisYap_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void FormGiris_Load(object sender, EventArgs e)
        {
            msKul.Visible = admin;
            msReh.Visible = false;
            this.Width = 440;
            this.Height = 320;

        }

        private void btnGiris_Click(object sender, EventArgs e)
        {
            cn.Open();
          
            cmd = new SqlCommand("select * from dbo.users where Kisi_Ad='" + tbUsername.Text + "' AND Kisi_sifre='" + tbSifre.Text + "'");
            cmd.Connection = cn;
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                admin = dr.GetBoolean(3);
                msKul.Visible = admin;
                msReh.Visible = true;
                pGiris.Visible = false;
                btnGiris.Visible = false;
                cbsifreunuttum.Visible = false;
                lgiris.Text = "LOGIN SUCCESSFULL";
                lgiris.Visible = true;

            }
            else
            {
                MessageBox.Show("Bilgileriniz Hatalı","Uyarı",MessageBoxButtons.OK,MessageBoxIcon.Warning);
            }
            cn.Close();
        }

        private void cbsifreunuttum_CheckedChanged(object sender, EventArgs e)
        {
            cn.Open();
            
            cmd = new SqlCommand("select * from dbo.users where Kisi_Ad='" + tbUsername.Text + "'");
            cmd.Connection = cn;
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
               MessageBox.Show(dr.GetString(2));
                // form ile yapılacak
            }
            else
            {
                MessageBox.Show("Kayıtlı Değilsiniz");
            }
            cn.Close();
        }

        private void msBilgiDegistir_Click(object sender, EventArgs e)
        {
            cn.Open();
            int ID;
            cmd = new SqlCommand("select * from dbo.users where Kisi_Ad='" + tbUsername.Text + "'");
            cmd.Connection = cn;
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                ID = dr.GetInt32(0);
                FormBilgiDegistir frm = new FormBilgiDegistir();
                frm.ffID = ID;
                frm.ffuser = tbUsername.Text;
                frm.ffsifre = tbSifre.Text;
                this.Hide();
                frm.Show();
            }
        }

        private void msKullaniciEkle_Click(object sender, EventArgs e)
        {
            pGiris.Visible = false;
            pSil.Visible = false;
            pEkle.Left = pGiris.Left;
            pEkle.Visible = true;
            this.Height = 320;
        }

        private void msKullaniciSil_Click(object sender, EventArgs e)
        {
            pGiris.Visible = false;
            pEkle.Visible = false;
            pSil.Left = pGiris.Left;

            if (cn != null && cn.State == ConnectionState.Closed) { cn.Open(); }


            cmd = new SqlCommand("SELECT * FROM  dbo.users",cn);
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adp.Fill(dt);
            dgwusers.DataSource = dt;

            pSil.Visible = true;
            this.Height = 500;
        }

        private void çıkışToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void rehberGirişToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormRehberGiris frm = new FormRehberGiris();

            this.Hide();
            frm.Show();
        }
    }
}
