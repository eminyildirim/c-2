﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace TelRehberi
{
    public partial class FormRehberGiris : Form
    {
        public FormRehberGiris()
        {
            InitializeComponent();
        }
        SqlConnection cn = new SqlConnection(@"Data Source=LAB02-12;Initial Catalog=Rehber;Integrated Security=True");
        SqlCommand cmd;
      
        private void FormRehberGiris_Load(object sender, EventArgs e)
        {
            listele();
            goster(0);
        }
        void listele()
        {
            if (cn != null && cn.State == ConnectionState.Closed) { cn.Open(); }


            cmd = new SqlCommand("SELECT * FROM  dbo.TelRehber", cn);
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataTable dtrehber = new DataTable();
            adp.Fill(dtrehber);
            dgwRehber.DataSource = dtrehber;
        }
        void goster(int rowIndex)
        {

            DataGridViewRow row = dgwRehber.Rows[rowIndex];
            tbAd.Text = row.Cells[1].Value.ToString();
            tbSoyad.Text = row.Cells[2].Value.ToString();
            tbTel.Text = row.Cells[3].Value.ToString();
            tbEmail.Text = row.Cells[4].Value.ToString();
            tbAdres.Text = row.Cells[5].Value.ToString();
        }
        private void btnCikis_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnKayit_Click(object sender, EventArgs e)
        {
            if (cn != null && cn.State == ConnectionState.Closed) { cn.Open(); }

            SqlCommand scmd = new SqlCommand("INSERT INTO dbo.TelRehber (TRAd,TRSoyad,TRTel,TREmail,TRAdres) VALUES (@p1,@p2,@p3,@p4,@p5)", cn);


            scmd.Parameters.AddWithValue("@p1", tbAd.Text);
            scmd.Parameters.AddWithValue("@p2", tbSoyad.Text);
            scmd.Parameters.AddWithValue("@p3", tbTel.Text);
            scmd.Parameters.AddWithValue("@p4", tbEmail.Text);
            scmd.Parameters.AddWithValue("@p5", tbAdres.Text);
        
            scmd.ExecuteNonQuery();
            cn.Close();
            listele();
            dgwRehber.Rows[dgwRehber.RowCount - 1].Selected = true;
           // MessageBox.Show(dgwRehber.RowCount.ToString());
            goster(dgwRehber.RowCount - 1);
        }

        private void dgwRehber_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            goster(e.RowIndex);
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            if (cn != null && cn.State == ConnectionState.Closed) { cn.Open(); }
            int rowIndex = dgwRehber.CurrentRow.Index;
            DataGridViewRow row = dgwRehber.Rows[rowIndex];
            SqlCommand scmd = new SqlCommand("DELETE FROM dbo.TelRehber WHERE TRRef = "+ row.Cells[0].Value.ToString(), cn);
            
            scmd.ExecuteNonQuery();
            listele();
            goster(0);
        }

        private void btnDuzelt_Click(object sender, EventArgs e)
        {
            if (cn != null && cn.State == ConnectionState.Closed) { cn.Open(); }
            int rowIndex = dgwRehber.CurrentRow.Index;
            DataGridViewRow row = dgwRehber.Rows[rowIndex];
            SqlCommand scmd = new SqlCommand("UPDATE dbo.TelRehber SET [TRAd] = @P1,[TRSoyad] = @P2,[TRTel] = @P3,[TREmail] = @P4,[TRAdres] =@P5 WHERE TRRef = " + row.Cells[0].Value.ToString(), cn);
            scmd.Parameters.AddWithValue("@p1", tbAd.Text);
            scmd.Parameters.AddWithValue("@p2", tbSoyad.Text);
            scmd.Parameters.AddWithValue("@p3", tbTel.Text);
            scmd.Parameters.AddWithValue("@p4", tbEmail.Text);
            scmd.Parameters.AddWithValue("@p5", tbAdres.Text);
            scmd.ExecuteNonQuery();
            listele();
            //MessageBox.Show(rowIndex.ToString());
            dgwRehber.Rows[rowIndex].Selected = false;
            goster(rowIndex);
            dgwRehber.Rows[rowIndex].Selected = true;
        }
    }
}
