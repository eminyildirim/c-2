﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hatirlama
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnKayit_Click(object sender, EventArgs e)
        {
            cbTest.Items.Add(textBox1.Text);
            cbTest.SelectedIndex = cbTest.Items.Count - 1;            
            lbtest.Items.Add(textBox1.Text);
            lbtest.SelectedIndex = lbtest.Items.Count - 1;
            label1.Text = textBox1.Text;
            label2.Text = textBox2.Text;
            label3.Text = textBox3.Text;
            label4.Text = textBox4.Text;
            groupBox1.Visible = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            groupBox1.Visible = false;
        }

        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        {
            textBox4.Text = comboBox1.Text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            linkLabel1.Text = "Sitemize girmek için burayı tıklayın.rn" +
                       "Mail göndermek için burayı tıklayın.rn" +
                       "Hesap makinesini çalıştırmak için burayı tıklayın.rn" +
                       "Harddiskin içeriğini görmek için burayı tıklayın.";

            linkLabel1.Links.Add(21, 6, "http://www.afguven.com");
            linkLabel1.Links.Add(60, 6, "mailto:afguven33@hotmail.com");
            linkLabel1.Links.Add(113, 6, "calc.exe");
            linkLabel1.Links.Add(165, 6, "c:");
            //Linkleri mavi göster
            linkLabel1.LinkColor = Color.Blue;
            //Gezilmiş linkleri kırmızı göster
            linkLabel1.VisitedLinkColor = Color.Red;
            //Aktif linkleri kahverengi göster
            linkLabel1.ActiveLinkColor = Color.Brown;
            //Linklerin altını fare üzerine geldiğinde çiz
            linkLabel1.LinkBehavior = LinkBehavior.HoverUnderline;
        }
        private void linkLabel1_LinkClicked(object sender,
       System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
        {
            //Tıklanan linki ziyaret edilmiş renkle göster
            linkLabel1.Links[linkLabel1.Links.IndexOf(e.Link)].Visited = true;
            //Linki çalıştır
            System.Diagnostics.Process.Start(e.Link.LinkData.ToString());
        }
    }
}
