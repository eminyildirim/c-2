﻿namespace Ornek_Yolcu
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.cbnereye = new System.Windows.Forms.ComboBox();
            this.cbnereden = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.tarih = new System.Windows.Forms.MaskedTextBox();
            this.saat = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.tel = new System.Windows.Forms.MaskedTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tcno = new System.Windows.Forms.MaskedTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tbadsoyad = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label8 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.gbKoltuklar = new System.Windows.Forms.GroupBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.ımageList1 = new System.Windows.Forms.ImageList(this.components);
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.cb1 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.button3 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.gbKoltuklar.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // cbnereye
            // 
            this.cbnereye.FormattingEnabled = true;
            this.cbnereye.Items.AddRange(new object[] {
            "ELAZIĞ",
            "KEMALİYE",
            "MALATYA",
            "HEKİMHAN",
            "ARAPGİR",
            "MARAŞ",
            "GAZİANTEP"});
            this.cbnereye.Location = new System.Drawing.Point(102, 50);
            this.cbnereye.Name = "cbnereye";
            this.cbnereye.Size = new System.Drawing.Size(156, 21);
            this.cbnereye.TabIndex = 0;
            this.cbnereye.SelectedIndexChanged += new System.EventHandler(this.cbnereye_SelectedIndexChanged);
            this.cbnereye.Leave += new System.EventHandler(this.cbnereye_Leave);
            // 
            // cbnereden
            // 
            this.cbnereden.FormattingEnabled = true;
            this.cbnereden.Items.AddRange(new object[] {
            "ELAZIĞ",
            "KEMALİYE",
            "MALATYA",
            "HEKİMHAN",
            "ARAPGİR",
            "MARAŞ",
            "GAZİANTEP"});
            this.cbnereden.Location = new System.Drawing.Point(102, 23);
            this.cbnereden.Name = "cbnereden";
            this.cbnereden.Size = new System.Drawing.Size(156, 21);
            this.cbnereden.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Nereden";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(26, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Nereye";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.AllowDrop = true;
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(102, 89);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(121, 20);
            this.dateTimePicker1.TabIndex = 6;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            this.dateTimePicker1.Enter += new System.EventHandler(this.dateTimePicker1_Enter);
            this.dateTimePicker1.Leave += new System.EventHandler(this.dateTimePicker1_Leave);
            this.dateTimePicker1.Validated += new System.EventHandler(this.dateTimePicker1_Validated);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(26, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Tarih";
            // 
            // tarih
            // 
            this.tarih.Location = new System.Drawing.Point(102, 88);
            this.tarih.Mask = "00/00/0000";
            this.tarih.Name = "tarih";
            this.tarih.Size = new System.Drawing.Size(108, 20);
            this.tarih.TabIndex = 8;
            this.tarih.ValidatingType = typeof(System.DateTime);
            this.tarih.Enter += new System.EventHandler(this.maskedTextBox1_Enter);
            // 
            // saat
            // 
            this.saat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.saat.FormattingEnabled = true;
            this.saat.Items.AddRange(new object[] {
            "08:00",
            "09:00",
            "10:30",
            "12:00",
            "15:00",
            "19:00",
            "22:30"});
            this.saat.Location = new System.Drawing.Point(102, 115);
            this.saat.Name = "saat";
            this.saat.Size = new System.Drawing.Size(121, 21);
            this.saat.TabIndex = 10;
            this.saat.Enter += new System.EventHandler(this.saat_Enter);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(29, 122);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(27, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "saat";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.tel);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.tcno);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.tbadsoyad);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Location = new System.Drawing.Point(29, 160);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(353, 183);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Yolcu Bilgileri";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(221, 74);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "BİLET KES";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tel
            // 
            this.tel.Location = new System.Drawing.Point(81, 74);
            this.tel.Mask = "(999) 000-0000";
            this.tel.Name = "tel";
            this.tel.Size = new System.Drawing.Size(100, 20);
            this.tel.TabIndex = 5;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(20, 74);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(18, 13);
            this.label7.TabIndex = 4;
            this.label7.Text = "tel";
            // 
            // tcno
            // 
            this.tcno.Location = new System.Drawing.Point(81, 43);
            this.tcno.Mask = "00000000000";
            this.tcno.Name = "tcno";
            this.tcno.Size = new System.Drawing.Size(148, 20);
            this.tcno.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(20, 43);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(28, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "tcno";
            // 
            // tbadsoyad
            // 
            this.tbadsoyad.Location = new System.Drawing.Point(81, 16);
            this.tbadsoyad.Name = "tbadsoyad";
            this.tbadsoyad.Size = new System.Drawing.Size(227, 20);
            this.tbadsoyad.TabIndex = 1;
            this.tbadsoyad.Enter += new System.EventHandler(this.tbadsoyad_Enter);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(17, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Adı Soyadı";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(407, 23);
            this.listBox1.Name = "listBox1";
            this.listBox1.ScrollAlwaysVisible = true;
            this.listBox1.Size = new System.Drawing.Size(688, 264);
            this.listBox1.TabIndex = 13;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(20, 468);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "label8";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(285, 48);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 15;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // gbKoltuklar
            // 
            this.gbKoltuklar.Controls.Add(this.checkBox8);
            this.gbKoltuklar.Controls.Add(this.checkBox9);
            this.gbKoltuklar.Controls.Add(this.checkBox10);
            this.gbKoltuklar.Controls.Add(this.checkBox11);
            this.gbKoltuklar.Controls.Add(this.checkBox4);
            this.gbKoltuklar.Controls.Add(this.checkBox5);
            this.gbKoltuklar.Controls.Add(this.checkBox6);
            this.gbKoltuklar.Controls.Add(this.checkBox7);
            this.gbKoltuklar.Controls.Add(this.checkBox2);
            this.gbKoltuklar.Controls.Add(this.checkBox3);
            this.gbKoltuklar.Controls.Add(this.checkBox1);
            this.gbKoltuklar.Controls.Add(this.cb1);
            this.gbKoltuklar.Location = new System.Drawing.Point(430, 324);
            this.gbKoltuklar.Name = "gbKoltuklar";
            this.gbKoltuklar.Size = new System.Drawing.Size(646, 192);
            this.gbKoltuklar.TabIndex = 16;
            this.gbKoltuklar.TabStop = false;
            this.gbKoltuklar.Text = "Koltuklar";
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.checkBox4.ImageIndex = 0;
            this.checkBox4.ImageList = this.ımageList1;
            this.checkBox4.Location = new System.Drawing.Point(230, 56);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(65, 32);
            this.checkBox4.TabIndex = 7;
            this.checkBox4.Text = "         08";
            this.checkBox4.UseVisualStyleBackColor = true;
            this.checkBox4.CheckedChanged += new System.EventHandler(this.cb1_CheckedChanged);
            // 
            // ımageList1
            // 
            this.ımageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList1.ImageStream")));
            this.ımageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList1.Images.SetKeyName(0, "bos.jpg");
            this.ımageList1.Images.SetKeyName(1, "rezerv.jpg");
            this.ımageList1.Images.SetKeyName(2, "dolu.jpg");
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.checkBox5.ImageIndex = 0;
            this.checkBox5.ImageList = this.ımageList1;
            this.checkBox5.Location = new System.Drawing.Point(230, 18);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(65, 32);
            this.checkBox5.TabIndex = 6;
            this.checkBox5.Text = "         07";
            this.checkBox5.UseVisualStyleBackColor = true;
            this.checkBox5.CheckedChanged += new System.EventHandler(this.cb1_CheckedChanged);
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.checkBox6.ImageIndex = 0;
            this.checkBox6.ImageList = this.ımageList1;
            this.checkBox6.Location = new System.Drawing.Point(159, 56);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(65, 32);
            this.checkBox6.TabIndex = 5;
            this.checkBox6.Text = "         06";
            this.checkBox6.UseVisualStyleBackColor = true;
            this.checkBox6.CheckedChanged += new System.EventHandler(this.cb1_CheckedChanged);
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.checkBox7.ImageIndex = 0;
            this.checkBox7.ImageList = this.ımageList1;
            this.checkBox7.Location = new System.Drawing.Point(159, 18);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(65, 32);
            this.checkBox7.TabIndex = 4;
            this.checkBox7.Text = "         05";
            this.checkBox7.UseVisualStyleBackColor = true;
            this.checkBox7.CheckedChanged += new System.EventHandler(this.cb1_CheckedChanged);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.checkBox2.ImageIndex = 0;
            this.checkBox2.ImageList = this.ımageList1;
            this.checkBox2.Location = new System.Drawing.Point(88, 56);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(65, 32);
            this.checkBox2.TabIndex = 3;
            this.checkBox2.Text = "         04";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.cb1_CheckedChanged);
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.checkBox3.ImageIndex = 0;
            this.checkBox3.ImageList = this.ımageList1;
            this.checkBox3.Location = new System.Drawing.Point(88, 18);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(65, 32);
            this.checkBox3.TabIndex = 2;
            this.checkBox3.Text = "         03";
            this.checkBox3.UseVisualStyleBackColor = true;
            this.checkBox3.CheckedChanged += new System.EventHandler(this.cb1_CheckedChanged);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.checkBox1.ImageIndex = 0;
            this.checkBox1.ImageList = this.ımageList1;
            this.checkBox1.Location = new System.Drawing.Point(17, 56);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(65, 32);
            this.checkBox1.TabIndex = 1;
            this.checkBox1.Text = "         02";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.cb1_CheckedChanged);
            // 
            // cb1
            // 
            this.cb1.AutoSize = true;
            this.cb1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cb1.ImageIndex = 0;
            this.cb1.ImageList = this.ımageList1;
            this.cb1.Location = new System.Drawing.Point(17, 18);
            this.cb1.Name = "cb1";
            this.cb1.Size = new System.Drawing.Size(65, 32);
            this.cb1.TabIndex = 0;
            this.cb1.Text = "         01";
            this.cb1.UseVisualStyleBackColor = true;
            this.cb1.CheckedChanged += new System.EventHandler(this.cb1_CheckedChanged);
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.checkBox8.ImageIndex = 0;
            this.checkBox8.ImageList = this.ımageList1;
            this.checkBox8.Location = new System.Drawing.Point(230, 125);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(65, 32);
            this.checkBox8.TabIndex = 11;
            this.checkBox8.Text = "         24";
            this.checkBox8.UseVisualStyleBackColor = true;
            this.checkBox8.CheckedChanged += new System.EventHandler(this.cb1_CheckedChanged);
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.checkBox9.ImageIndex = 0;
            this.checkBox9.ImageList = this.ımageList1;
            this.checkBox9.Location = new System.Drawing.Point(159, 125);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(65, 32);
            this.checkBox9.TabIndex = 10;
            this.checkBox9.Text = "         23";
            this.checkBox9.UseVisualStyleBackColor = true;
            this.checkBox9.CheckedChanged += new System.EventHandler(this.cb1_CheckedChanged);
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.checkBox10.ImageIndex = 0;
            this.checkBox10.ImageList = this.ımageList1;
            this.checkBox10.Location = new System.Drawing.Point(88, 125);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(65, 32);
            this.checkBox10.TabIndex = 9;
            this.checkBox10.Text = "         22";
            this.checkBox10.UseVisualStyleBackColor = true;
            this.checkBox10.CheckedChanged += new System.EventHandler(this.cb1_CheckedChanged);
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.checkBox11.ImageIndex = 0;
            this.checkBox11.ImageList = this.ımageList1;
            this.checkBox11.Location = new System.Drawing.Point(17, 125);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(65, 32);
            this.checkBox11.TabIndex = 8;
            this.checkBox11.Text = "         21";
            this.checkBox11.UseVisualStyleBackColor = true;
            this.checkBox11.CheckedChanged += new System.EventHandler(this.cb1_CheckedChanged);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(261, 388);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 17;
            this.button3.Text = "button3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1134, 573);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.gbKoltuklar);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.saat);
            this.Controls.Add(this.tarih);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbnereden);
            this.Controls.Add(this.cbnereye);
            this.Name = "Form1";
            this.Text = "Bilet Kesme";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.gbKoltuklar.ResumeLayout(false);
            this.gbKoltuklar.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ComboBox cbnereye;
        private System.Windows.Forms.ComboBox cbnereden;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.MaskedTextBox tarih;
        private System.Windows.Forms.ComboBox saat;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.MaskedTextBox tel;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.MaskedTextBox tcno;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbadsoyad;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox gbKoltuklar;
        private System.Windows.Forms.CheckBox cb1;
        private System.Windows.Forms.ImageList ımageList1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.Button button3;
    }
}

