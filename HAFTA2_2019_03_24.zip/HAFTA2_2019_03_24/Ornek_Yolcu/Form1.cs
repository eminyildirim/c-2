﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ornek_Yolcu
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.Text = "Bilet Kesme (" + DateTime.Now.ToString() + ")";
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label8.Text = DateTime.Now.ToString();
           this.Text = "Bilet Kesme ("+DateTime.Now.ToString()+")";

        }

        private void Form1_Load(object sender, EventArgs e)            
        {
            // this.Text = "Bilet Kesme (" + DateTime.Now.ToString() + ")";
            dateTimePicker1.Visible = false;
            cbnereden.SelectedIndex = 0;
            cbnereye.SelectedIndex = 1;
            saat.SelectedIndex = 0;
            tarih.Text = DateTime.Now.ToShortDateString();
            dateTimePicker1.Value = DateTime.Now.Date;
        }

        private void maskedTextBox1_Enter(object sender, EventArgs e)
        {   tarih.Visible = false;
            dateTimePicker1.Visible = true;
            dateTimePicker1.Show();
           // dateTimePicker1.Focus();



        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            if (dateTimePicker1.Value < DateTime.Now.Date)
            {
                MessageBox.Show("Uygun tarih Girin");
                dateTimePicker1.Focus();
                return;
            }                

            tarih.Text = dateTimePicker1.Value.ToString();
            dateTimePicker1.Visible = false;
            tarih.Visible = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CheckBox cb = new CheckBox();
            String koltuklar = "Koltuklar:";
  

            if (tbadsoyad.Text!="")
            {
                foreach (var item in gbKoltuklar.Controls)
                {
                    cb = item as CheckBox;
                    if (cb.Checked)
                    {
                        koltuklar = koltuklar + " " + cb.Text.Trim();
                        cb.Enabled = false;
                    }
                }
                listBox1.Items.Add(tbadsoyad.Text + " " + tarih.Text + " Tarihi için Saat:" + saat.Text + " " + cbnereden.Text + " " + cbnereye.Text + " Bileti Aldı (" + DateTime.Now.ToString() + ")"+" "+koltuklar);
            }
            else
            {
                MessageBox.Show("Eksik Bilgi");
            }
            
        }

        private void cbnereye_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(cbnereden.SelectedIndex==cbnereye.SelectedIndex)
            {
                MessageBox.Show("Gideceği Yeri Doğru Seçin");
                cbnereye.Focus();
            }
        }

        private void cbnereye_Leave(object sender, EventArgs e)
        {
            if (cbnereden.SelectedIndex == cbnereye.SelectedIndex)
            {
                MessageBox.Show("Gideceği Yeri Doğru Seçin");
                cbnereye.Focus();
            }
        }

        private void dateTimePicker1_Leave(object sender, EventArgs e)
        {
            tarih.Text = dateTimePicker1.Value.ToString();
            dateTimePicker1.Visible = false;
            tarih.Visible = true;
        }

        private void dateTimePicker1_Validated(object sender, EventArgs e)
        {
            tarih.Text = dateTimePicker1.Value.ToString();
            dateTimePicker1.Visible = false;
            tarih.Visible = true;
        }

        private void saat_Enter(object sender, EventArgs e)
        {

        }

        private void tbadsoyad_Enter(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_Enter(object sender, EventArgs e)
        {     

        }

        private void button2_Click(object sender, EventArgs e)
        {
            cbnereye.Items.Clear();
            for (int i = 0; i < cbnereden.Items.Count; i++)
            { if (i!=cbnereden.SelectedIndex)
                { cbnereye.Items.Add(cbnereden.Items[i]); }
            }
        }

        private void cb1_CheckedChanged(object sender, EventArgs e)
        { CheckBox cb = new CheckBox();
            cb = sender as CheckBox;
            cb.ImageIndex = 0;
            if (cb.Checked) { cb.ImageIndex = 2; }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            CheckBox cb = new CheckBox();
            String koltuklar = "";
            foreach (var item in gbKoltuklar.Controls)
            {
                cb = item as CheckBox;
                if (cb.Checked) { koltuklar = koltuklar + " Koltuk:" + cb.Text.Trim(); }
            }
            MessageBox.Show(koltuklar);
        }
    }
}
