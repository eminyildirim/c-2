﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ornek_textboxCesit
{
    public partial class Form1 : Form
    {
        private const int sleepTimeMiliseconds = 5000;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WebBrowser wb = new WebBrowser(); wb.Navigate("about:blank");
            string url = @"https:\\www.tcmb.gov.tr";
            wb.Navigate(url);
            while (wb.ReadyState != WebBrowserReadyState.Complete)
            {
                System.Threading.Thread.Sleep(sleepTimeMiliseconds);
                Application.DoEvents();
            }

            wb.Document.ExecCommand("SelectAll", false, null);
            wb.Document.ExecCommand("Copy", false, null);
            richTextBox1.Paste();


        }
    }
}
