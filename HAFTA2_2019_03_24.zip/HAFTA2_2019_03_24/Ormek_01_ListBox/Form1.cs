﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ormek_01_ListBox
{
    public partial class Form1 : Form
    {
        Boolean eklendi = true;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            lbListe.Items.Add(tbAd.Text+" "+tbSoyad.Text+" "+cbcins.Text + " " + cbsec.Text);
            eklendi = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cbsec.SelectedIndex = 0;
            timer1.Enabled = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            zaman.Text = DateTime.Now.ToString();
            trackBar1.Value = DateTime.Now.Second;

            label6.Left = 67 + trackBar1.Value * 10 - trackBar1.Value / 3;
            label6.Text = trackBar1.Value.ToString();

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
           
            lbListe.Items.Add(DateTime.Now.ToString());

            lbzaman.Items.Clear();
            lbzaman.Items.Add("Yıl :" + DateTime.Now.Year.ToString());
            lbzaman.Items.Add("Ay  :" + DateTime.Now.Month.ToString());
            lbzaman.Items.Add("Gün :" + DateTime.Now.Day.ToString());
            lbzaman.Items.Add("Saat:" + DateTime.Now.Hour.ToString());
            lbzaman.Items.Add("Dak :" + DateTime.Now.Minute.ToString());
            lbzaman.Items.Add("San: " + DateTime.Now.Second.ToString());
           
            String[] s = DateTime.Now.GetDateTimeFormats();
            int i = 0;
            foreach (var item in s)
            {
                lbzaman.Items.Add(i.ToString()+" "+item);
                i++;
            }
     
        }

        private void tbAd_KeyPress(object sender, KeyPressEventArgs e)
        {
 

        }

        private void tbSoyad_KeyDown(object sender, KeyEventArgs e)
        {
            if (eklendi)
            {
                eklendi = false;
                tbAd.Clear();
                tbSoyad.Clear();
            }
        }

        private void tbAd_KeyDown(object sender, KeyEventArgs e)
        {
            if (eklendi)
            {
                eklendi = false;
                tbAd.Clear();
                tbSoyad.Clear();
            }
        }

        private void vScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
           label5.Text="Old:"+ e.OldValue.ToString()+ " New:" + e.NewValue.ToString();
            trackBar1.Value = e.NewValue;
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {

        }

        private void trackBar1_ValueChanged(object sender, EventArgs e)
        {
            //trackBar1.Value = DateTime.Now.Second;

            label6.Left =  67 + trackBar1.Value * 10 - trackBar1.Value / 3;
            label6.Text = trackBar1.Value.ToString();
        }

        private void tbAd_Enter(object sender, EventArgs e)
        {
            if (eklendi)
            {
                eklendi = false;
                tbAd.Clear();
                tbSoyad.Clear();
            }
        }
    }
}
