﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Sinema
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlBaglantisi bgl = new SqlBaglantisi();
        private void btnKoltuk_Click(object sender, EventArgs e)
        {
            for (int i = 2; i < 10; i++)
            {
                System.Windows.Forms.PictureBox k01002 = new System.Windows.Forms.PictureBox();

                k01002.Image = global::Sinema.Properties.Resources.koltuk;
                k01002.Location = new System.Drawing.Point(19 + 35 * i, 17);
                k01002.Size = new System.Drawing.Size(35, 47);
                k01002.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
                k01002.TabIndex = 0;
                k01002.TabStop = false;
                k01002.Click += new System.EventHandler(this.koltuk_Click);
                k01002.Name = "k0100" + i.ToString();
                pSalon.Controls.Add(k01002);
            }

        }

        private void koltuk_Click(object sender, EventArgs e)
        {
            PictureBox pb = new PictureBox();
            pb = (sender as PictureBox);
            MessageBox.Show(pb.Name.ToString());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("Select * from dbo.Salon", bgl.baglanti());

            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {

                rtbKonum.Text = dr.GetString(dr.GetOrdinal("KoltukKonumu"));

            }
            bgl.baglanti().Close();
            int s = 0;
            for (int i = 0; i < rtbKonum.Lines.Count(); i++)
            {
                //MessageBox.Show(rtbKonum.Lines[i].ToString());
                //MessageBox.Show(rtbKonum.Lines[i].ToString()[0].ToString());
                int y = 1 + i * 32;

                string strvalue = "".PadRight(rtbKonum.Lines[i].Length, '0');
                //MessageBox.Show(strvalue.Length.ToString() + " " + rtbKonum.Lines[i].Length.ToString());
                if (!rtbKonum.Lines[i].ToString().Equals(strvalue))
                {
                    s++;
                    // MessageBox.Show(strvalue.Length.ToString() + " " + rtbKonum.Lines[i].Length.ToString());
                }
                for (int j = 0; j < rtbKonum.Lines[i].Length; j++)
                {
                    int x = 21 * j;
                    if (rtbKonum.Lines[i].ToString()[j].Equals('1'))
                    {
                        System.Windows.Forms.PictureBox k1 = new System.Windows.Forms.PictureBox();

                        k1.Image = global::Sinema.Properties.Resources.koltuk;
                        k1.Location = new System.Drawing.Point(x, y);
                        k1.Size = new System.Drawing.Size(20, 30);
                        k1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
                        k1.TabIndex = 0;
                        k1.TabStop = false;
                        k1.Click += new System.EventHandler(this.koltuk_Click);
                        k1.Name = "k" + s.ToString() + "00" + (j+1).ToString();
                        pSalon.Controls.Add(k1);
                    }
                }
            }
        }
    }
}
