﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Sinema
{
    public partial class frmSalon : Form
    {
        internal System.Windows.Forms.Panel pSalon;
        internal System.Windows.Forms.Button btnSalonTasarla;
        int toplamkoltuk = 0;
        String basname = "";
        String bitname = "";
        int basx = 0;
        int basy = 0;
        int bitx = 0;
        int bity = 0;
        public frmSalon()
        {
            InitializeComponent();
        }
        SqlBaglantisi bgl = new SqlBaglantisi();
        private void koltuk_Click(object sender, EventArgs e)
        {
            PictureBox pb = new PictureBox();
            pb = (sender as PictureBox);
            if (pb.Tag.ToString() == "1")
            {
                pb.Image = global::Sinema.Properties.Resources.koltuksil;
                pb.Tag = 0;
                KoltukSayisi(-1);
            }
            else
            {
                pb.Image = global::Sinema.Properties.Resources.koltuk;
                pb.Tag = 1;
                KoltukSayisi(1);
            }

            // MessageBox.Show(pb.Name.ToString());
        }
        private String Sifirdoldur(int uzunluk, int i)
        {
            String sonuc = new string('0', uzunluk) + i.ToString();
            sonuc = sonuc.Substring(sonuc.Length - uzunluk);
            return sonuc;
        }
        private void KoltukSayisi(int a)
        {
            toplamkoltuk = toplamkoltuk + a;
            lkoltuksayisi.Text = "Toplam Kotuk Sayısı:" + toplamkoltuk.ToString();
        }

        private void DataYap()
        {
            String x = "", y = "";
            rtKonum.Text = "";
            foreach (var item in pSalon.Controls)
            {
                if (item is PictureBox)
                {
                    PictureBox pb = new PictureBox();
                    pb = (item as PictureBox);
                    if (y.Equals("") || y.Equals(pb.Name.Substring(2, pb.Name.IndexOf('_') - 1)))
                    {
                        y = pb.Name.Substring(2, pb.Name.IndexOf('_') - 1);
                        x = x + pb.Tag.ToString();
                    }
                    else
                    {
                        if (!string.IsNullOrWhiteSpace(rtKonum.Text))
                        {
                            rtKonum.AppendText("\r\n" + x);
                        }
                        else
                        {
                            rtKonum.AppendText(x);
                        }
                        y = pb.Name.Substring(2, pb.Name.IndexOf('_') - 1);
                        x = pb.Tag.ToString();
                    }

                }
            }
            rtKonum.ScrollToCaret();
        }

        private void btnSalonTasarla_Click(object sender, EventArgs e)
        {
            SalonTasarla();
        }
        private void SalonTasarla()
        {
            toplamkoltuk = 0;
            int h1 = 0;
            int h2 = 10;
            while (pSalon.Controls.Count > 0)
            {
                pSalon.Controls.RemoveAt(pSalon.Controls.Count - 1);
            }

            int bas = 0;
            int sahneBoyu = 400;
            int genislik = 500;
            int boyu = 800;
            /*
            arka = int.Parse(mtbArka.Text);
            sahneBoyu = int.Parse(mtbSahneBoyu.Text);
            yuk = int.Parse(mtbDerinlik.Text);
            int koltukGen = int.Parse(koltukGenislik.Text);
            int koltukBoy = int.Parse(koltukBoyu.Text);
            int koltukAra = int.Parse(koltukAralik.Text);
            */
            genislik = int.Parse(mtbArka.Text);
            sahneBoyu = 0;
            boyu = int.Parse(mtbDerinlik.Text);
            int koltukGen = 60;
            int koltukBoy = 70;
            int koltukAra = 20;
            int.TryParse(mtbkoltukGen.Text, out koltukGen);
            int.TryParse(mtbkoltukBoy.Text, out koltukBoy);
            int.TryParse(mtbkoltukAra.Text, out koltukAra);
            genislik = genislik / 2;
            sahneBoyu = sahneBoyu / 2;
            boyu = boyu / 2;
            koltukGen = koltukGen / 2;
            koltukBoy = koltukBoy / 2;
            koltukAra = koltukAra / 2;


            int fark = (genislik - sahneBoyu) / 2;

            int s1 = genislik / koltukGen;
            int s2 = boyu / (koltukBoy + koltukAra);
            for (int j = 0; j < s2; j++)
            {
                int sira = bas + (koltukBoy + koltukAra) * j;
                for (int i = 0; i < s1; i++)
                {
                    fark = 0;
                    boyu = koltukBoy;
                    genislik = koltukGen - 2;


                    PictureBox k1 = new PictureBox();

                    k1.Image = global::Sinema.Properties.Resources.koltuk;
                    k1.Location = new System.Drawing.Point(bas + i * koltukGen, sira);
                    k1.Size = new System.Drawing.Size(koltukGen, koltukBoy);
                    k1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
                    k1.TabIndex = 0;
                    k1.Tag = 1;
                    k1.TabStop = false;
                    k1.Click += new System.EventHandler(this.koltuk_Click);

                    k1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseDown);
                    k1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseUp);
                    //  k1.Name = "pb" +  j.ToString() + "_" + (i + 1).ToString();
                    k1.Name = "pb" + Sifirdoldur(5, j) + "_" + Sifirdoldur(5, i + 1);
                    KoltukSayisi(1);
                    pSalon.Controls.Add(k1);

                    /*
                    
                    System.Windows.Forms.Label l2 = new System.Windows.Forms.Label();
                    l2.AutoSize = true;
                    l2.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
                    l2.Location = new System.Drawing.Point(k1.Left+10, k1.Top + 2);

                    l2.RightToLeft = System.Windows.Forms.RightToLeft.No;
                    l2.Size = new System.Drawing.Size(15, 11);
                    l2.TabIndex = 0;
                    l2.Text = int.Parse(k1.Name.Substring(k1.Name.IndexOf('_') + 1)).ToString();
                    l2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
                    l2.Name = "l" + k1.Name;
                    pSalon.Controls.Add(l2);
                    */



                }
                System.Windows.Forms.Label l1 = new System.Windows.Forms.Label();
                l1.AutoSize = true;
                l1.BackColor = System.Drawing.SystemColors.ControlLightLight;
                l1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
                l1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
                l1.Location = new System.Drawing.Point(bas + s1 * koltukGen, sira);
                l1.Name = "lharf" + j.ToString();
                l1.Size = new System.Drawing.Size(14, 14);
                l1.TabIndex = 2;
                char ch = 'A';
                ch = (char)(j + 65);
                l1.Text = ch.ToString();
                if (j > 25)
                {
                    if (h2 > 8)
                    {
                        h1++;
                        h2 = -1;
                    }
                    h2++;
                    ch = (char)(h1 + 64);
                    l1.Text = ch.ToString() + h2.ToString();
                }

                pSalon.Controls.Add(l1);
            }
        }

        private void ScrollablePanel_ResizeEnd(object sender, EventArgs e)
        {
            pSalon.Width = this.Width - 323;
            //  lSahne.Left = (pSahne.Width - 200) / 2;
            pSahne.Top = this.Height - 80;
            pSalon.Height = this.Height - 100;
            pSahne.Left = pSalon.Left;
            pSahne.Width = pSalon.Width;

        }

        private void ScrollablePanel_Load(object sender, EventArgs e)
        {
            this.Left = 0;
            this.Top = 0;
            this.Width = Screen.PrimaryScreen.Bounds.Width;
            this.Height = Screen.PrimaryScreen.Bounds.Height - 50;
            pSahne.Top = this.Height - 80;
            pSalon.Height = this.Height - 100;
            pSahne.Left = pSalon.Left;
            pSahne.Width = pSalon.Width;

        }

        private void button2_Click(object sender, EventArgs e)
        {
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {

            if (e.Button == MouseButtons.Right)
            {
                if (basname.Equals("")) { basname = (sender as PictureBox).Name; }

            }
            else
            {
                bitname = "";
                basname = "";
            }


        }

        private void ScrollablePanel_MouseDown(object sender, MouseEventArgs e)
        {
            basx = e.X;
            basy = e.Y;
        }

        private void ScrollablePanel_MouseUp(object sender, MouseEventArgs e)
        {
            bitx = e.X;
            bity = e.Y;
            //MessageBox.Show(basx.ToString() + "," + bity.ToString());
        }

        private void pSalon_MouseDown(object sender, MouseEventArgs e)
        {
            basx = e.X;
            basy = e.Y;
        }

        private void pSalon_MouseUp(object sender, MouseEventArgs e)
        {
            bitx = e.X;
            bity = e.Y;
            //MessageBox.Show(basx.ToString() + "," + bity.ToString());
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                bitname = (sender as PictureBox).Name;
                if (!basname.Equals(bitname))
                {

                    if (String.Compare(bitname, basname) < 0)
                    {
                        String b = bitname;
                        bitname = basname;
                        basname = b;
                    }

                    // label2.Text = basname;
                    // label3.Text = bitname;
                    //  MessageBox.Show(basname + " " + bitname);
                    String y1 = basname.Substring(2, basname.IndexOf('_') - 2);
                    String y2 = bitname.Substring(2, bitname.IndexOf('_') - 2);
                    String x1 = basname.Substring(basname.IndexOf('_') + 1);
                    String x2 = bitname.Substring(bitname.IndexOf('_') + 1);

                    if (String.Compare(x2, x1) < 0)
                    {
                        String b = x2;
                        x2 = x1;
                        x1 = b;
                    }

                    PictureBox pbas = new PictureBox();
                    Control[] matches1 = pSalon.Controls.Find(basname, true);
                    pbas = matches1[0] as PictureBox;

                    for (int i = int.Parse(y1); i <= int.Parse(y2); i++)
                    {
                        for (int j = int.Parse(x1); j <= int.Parse(x2); j++)
                        {
                            //String pbtext = "pb" + i.ToString() + "_" + (j).ToString();
                            String pbtext = "pb" + Sifirdoldur(5, i) + "_" + Sifirdoldur(5, j);
                            PictureBox pb = new PictureBox();
                            Control[] matches = pSalon.Controls.Find(pbtext, true);
                            pb = matches[0] as PictureBox;
                            pb.Image = pbas.Image;
                            pb.Tag = pbas.Tag;
                        }
                    }
                    bitname = "";
                    basname = "";

                }

            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            // MessageBox.Show(pSalon.Controls.Count.ToString());
            int sira = 0;
            foreach (var item in pSalon.Controls)
            {
                if (item is PictureBox)
                {
                    PictureBox pb = new PictureBox();
                    pb = (item as PictureBox);

                    // pblist.Add(pb.Name);             


                    System.Windows.Forms.Label l2 = new System.Windows.Forms.Label();
                    l2.AutoSize = true;
                    l2.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
                    l2.Location = new System.Drawing.Point(pb.Left + 10, pb.Top + 33);

                    l2.RightToLeft = System.Windows.Forms.RightToLeft.No;
                    l2.Size = new System.Drawing.Size(15, 11);
                    l2.TabIndex = 0;
                    l2.Text = int.Parse(pb.Name.Substring(pb.Name.IndexOf('_') + 1)).ToString(); ;
                    l2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
                    l2.Name = "l" + pb.Name;
                    pSalon.Controls.Add(l2);

                    // this.Controls.Add(l1);
                    //   rtKonum.AppendText("\r\n" + l2.Name+" "+l2.Top.ToString()+" "+l2.Left.ToString());
                }
            }
            this.pSalon.ResumeLayout(false);
            this.pSalon.PerformLayout();
            this.pSahne.ResumeLayout(false);
            this.pSahne.PerformLayout();
        }


        private void btnKayit_Click(object sender, EventArgs e)
        {
            tbSalonAdi.Text = tbSalonAdi.Text.Trim().TrimEnd().TrimStart();
            DataYap();
            if (!tbSalonAdi.Text.Equals("") && toplamkoltuk > 0 && rtKonum.Lines.Count() > 2)
            {
                DataYap();
                SqlCommand cmd = new SqlCommand("INSERT INTO dbo.Salon (SalonAdi,KoltukSayisi,KoltukKonumu,SalonTemizleme,AcilisSaati,KapanisSaati) VALUES (@SalonAdi,@KoltukSayisi,@KoltukKonumu,@SalonTemizleme,@AcilisSaati,@KapanisSaati)", bgl.baglanti());
                cmd.Parameters.AddWithValue("@SalonAdi", tbSalonAdi.Text);
                cmd.Parameters.AddWithValue("@KoltukSayisi", toplamkoltuk);
                cmd.Parameters.AddWithValue("@KoltukKonumu", rtKonum.Text);
                cmd.Parameters.AddWithValue("@SalonTemizleme", mtbSalonTemizleme.Text);
                cmd.Parameters.AddWithValue("@AcilisSaati", mtbAcilis.Text);
                cmd.Parameters.AddWithValue("@KapanisSaati", mtbKapanis.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Salon Kayıt Edildi");
                this.Close();
            }
            else
            {
                MessageBox.Show("Salon Yapılandırması hatalı");
            }
        }


    }
}
