﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Sinema
{
    public partial class frmFilmGiris : Form
    {
        public frmFilmGiris()
        {
            InitializeComponent();
        }
        SqlBaglantisi bgl = new SqlBaglantisi();
        private void frmFilmGiris_Load(object sender, EventArgs e)
        {
            Listele();           
            ListeleSalon();
            Goster(0,0);
            gbVizyonda.Top = gbVizyon.Top;
            gbVizyonda.Left = gbVizyon.Left;
            gbVizyonda.Width = gbFilm.Width - 40;
            gbVizyon.Width= gbFilm.Width - 40;
            btnKayit.Visible = false;
        }
        void Listele()
        {
            SqlCommand cmd = new SqlCommand("Select * from dbo.View_Film order by Sayi,FilmID DESC", bgl.baglanti());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dgwFilmListesi.DataSource = dt;
        }
        void ListeleSalon()
        {
            SqlCommand cmd = new SqlCommand("Select * from dbo.View_SalonBosTarih ORDER BY BosTarih", bgl.baglanti());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dgwSalon.DataSource = dt;
            //MessageBox.Show(dgwFilmListesi.CurrentRow.Cells[0].ToString() + " " + dgwSalon.CurrentRow.Cells[0].ToString());
            //ListeleSeans(int.Parse(dgwFilmListesi.CurrentRow.Cells[0].Value.ToString()), int.Parse(dgwSalon.CurrentRow.Cells[0].Value.ToString()));
        }
        void ListeleSeans(int FilmID,int SalonID)
        {
            SqlCommand cmd = new SqlCommand("EXECUTE dbo.SeansSaatleri @FilmID,@SalonID", bgl.baglanti());
            cmd.Parameters.AddWithValue("@FilmID", FilmID);
            cmd.Parameters.AddWithValue("@SalonID", SalonID);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dgvSeanslar.DataSource = dt;
            dgvSeanslarVizyon.DataSource = dt;
        }
        void Goster(int r,int s)
        {
          
            tbFilmAdi.Text = dgwFilmListesi.Rows[r].Cells[1].Value.ToString();
            mtbFilmSure.Text = dgwFilmListesi.Rows[r].Cells[2].Value.ToString();
            tbVizyon.Text=dgwFilmListesi.Rows[r].Cells[3].Value.ToString();

            if (dgwFilmListesi.Rows[r].Cells[3].Value.ToString().Equals("0"))
            {
                gbVizyon.Visible = true;
                gbVizyonda.Visible = false;
                ListeleSeans(int.Parse(dgwFilmListesi.Rows[r].Cells[0].Value.ToString()), int.Parse(dgwSalon.Rows[s].Cells[0].Value.ToString()));
            }
            else
            {
                gbVizyon.Visible = false;
                gbVizyonda.Visible = true;
                gbVizyonda.Text="[ "+ dgwFilmListesi.Rows[r].Cells[8].Value.ToString() + " ]";
                mcVizyon.MinDate = DateTime.Today;
                mcVizyon.MaxDate = DateTime.Parse(dgwFilmListesi.Rows[r].Cells[5].Value.ToString());
                nudHaftayayin.Value = int.Parse(dgwFilmListesi.Rows[r].Cells[6].Value.ToString());
                ListeleSeans(int.Parse(dgwFilmListesi.Rows[r].Cells[0].Value.ToString()), int.Parse(dgwFilmListesi.Rows[r].Cells[7].Value.ToString()));
            }

        }
        private void dgwFilmListesi_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            Goster(e.RowIndex,0);
        }

        private void dgwSalon_CellClick(object sender, DataGridViewCellEventArgs e)
        {
           
            dtpSalonBos.MinDate = DateTime.Parse(dgwSalon.Rows[e.RowIndex].Cells[3].Value.ToString());
            dtpSalonBos.Value=DateTime.Parse(dgwSalon.Rows[e.RowIndex].Cells[3].Value.ToString());
            dtpSalonBos.MinDate = dtpSalonBos.Value;            
            ListeleSeans(int.Parse(dgwFilmListesi.CurrentRow.Cells[0].Value.ToString()),int.Parse(dgwSalon.Rows[e.RowIndex].Cells[0].Value.ToString()));
        }

        private void btnYeni_Click(object sender, EventArgs e)
        {
            tbFilmAdi.Text = "";
            mtbFilmSure.Text = "0";
            tbFilmAdi.Enabled = true;
            mtbFilmSure.Enabled = true;
            btnKayit.Visible = true;
            tbFilmAdi.Focus();
        }

        private void btnKayit_Click(object sender, EventArgs e)
        {
            tbFilmAdi.Text = tbFilmAdi.Text.Trim().TrimEnd().TrimStart();
            if (!tbFilmAdi.Text.Equals("")&&int.Parse(mtbFilmSure.Text)>0)
            {
                SqlCommand cmd = new SqlCommand("INSERT INTO dbo.Film (FilmAdi,FilmSure) VALUES (@FilmAdi,@FilmSure)", bgl.baglanti());
                cmd.Parameters.AddWithValue("@FilmAdi", tbFilmAdi.Text);
                cmd.Parameters.AddWithValue("@FilmSure", int.Parse(mtbFilmSure.Text));   
                cmd.ExecuteNonQuery();
                Listele();
                ListeleSalon();
                Goster(0, 0);
                tbFilmAdi.Enabled = false;
                mtbFilmSure.Enabled = false;
                btnKayit.Visible = false;
                MessageBox.Show("Film Kayıt Edildi");
         
            }
            else
            {
                MessageBox.Show("Film Bilgileri hatalı");
            }
        }

        private void btnVizyon_Click(object sender, EventArgs e)
        {
            String msg = "Film: " + dgwFilmListesi.CurrentRow.Cells[1].Value.ToString();
            msg =  msg+ "\nSalon:"+dgwSalon.CurrentRow.Cells[1].Value.ToString();
            msg = msg + "\nTarih:" + dtpSalonBos.Text;
            msg = msg + "\nHafta:" + nudHafta.Value.ToString();

            var result=MessageBox.Show(msg,"Vizyonda İşlemi Yapılsın mı?",MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {

                SqlCommand cmd = new SqlCommand("INSERT INTO dbo.Vizyon (FilmID,SalonID,FilmVizyonTarihi,FilmVizyonHafta) VALUES (@FilmID,@SalonID,@FilmVizyonTarihi,@FilmVizyonHafta)", bgl.baglanti());
                cmd.Parameters.AddWithValue("@FilmID", dgwFilmListesi.CurrentRow.Cells[0].Value.ToString());
                cmd.Parameters.AddWithValue("@SalonID", dgwSalon.CurrentRow.Cells[0].Value.ToString());
                cmd.Parameters.AddWithValue("@FilmVizyonTarihi", dtpSalonBos.Value);
                cmd.Parameters.AddWithValue("@FilmVizyonHafta", nudHafta.Value);
                cmd.ExecuteNonQuery();
                Listele();
                ListeleSalon();
                Goster(0, 0);
                MessageBox.Show("Vizyon Alma İşlemi Yapıldı");

            }
        }
    }
}
