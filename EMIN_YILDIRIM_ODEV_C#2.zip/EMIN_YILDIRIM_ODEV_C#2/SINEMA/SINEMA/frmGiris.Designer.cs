﻿namespace Sinema
{
    partial class frmGiris
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmGiris));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.imList = new System.Windows.Forms.ImageList(this.components);
            this.ımageList1 = new System.Windows.Forms.ImageList(this.components);
            this.btnBilet = new System.Windows.Forms.Button();
            this.btnFilm = new System.Windows.Forms.Button();
            this.btnSalon = new System.Windows.Forms.Button();
            this.btnCikis = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.Info;
            this.groupBox1.Controls.Add(this.btnCikis);
            this.groupBox1.Controls.Add(this.btnBilet);
            this.groupBox1.Controls.Add(this.btnFilm);
            this.groupBox1.Controls.Add(this.btnSalon);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(300, 315);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // imList
            // 
            this.imList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imList.ImageStream")));
            this.imList.TransparentColor = System.Drawing.Color.Transparent;
            this.imList.Images.SetKeyName(0, "koltuksil.png");
            this.imList.Images.SetKeyName(1, "koltukbos.png");
            this.imList.Images.SetKeyName(2, "koltukdolu.png");
            this.imList.Images.SetKeyName(3, "koltuksec.png");
            this.imList.Images.SetKeyName(4, "film.PNG");
            this.imList.Images.SetKeyName(5, "bilet.PNG");
            // 
            // ımageList1
            // 
            this.ımageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList1.ImageStream")));
            this.ımageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList1.Images.SetKeyName(0, "bilet.PNG");
            // 
            // btnBilet
            // 
            this.btnBilet.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnBilet.FlatAppearance.BorderSize = 3;
            this.btnBilet.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnBilet.Image = global::Sinema.Properties.Resources.bilet;
            this.btnBilet.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBilet.Location = new System.Drawing.Point(20, 168);
            this.btnBilet.Name = "btnBilet";
            this.btnBilet.Size = new System.Drawing.Size(260, 48);
            this.btnBilet.TabIndex = 2;
            this.btnBilet.Text = "Bilet İşlemleri";
            this.btnBilet.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBilet.UseVisualStyleBackColor = true;
            this.btnBilet.Click += new System.EventHandler(this.btnBilet_Click);
            // 
            // btnFilm
            // 
            this.btnFilm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnFilm.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnFilm.ImageIndex = 4;
            this.btnFilm.ImageList = this.imList;
            this.btnFilm.Location = new System.Drawing.Point(20, 96);
            this.btnFilm.Name = "btnFilm";
            this.btnFilm.Size = new System.Drawing.Size(260, 48);
            this.btnFilm.TabIndex = 1;
            this.btnFilm.Text = "Film İşlemleri";
            this.btnFilm.UseVisualStyleBackColor = true;
            this.btnFilm.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnSalon
            // 
            this.btnSalon.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnSalon.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSalon.ImageIndex = 1;
            this.btnSalon.ImageList = this.imList;
            this.btnSalon.Location = new System.Drawing.Point(20, 30);
            this.btnSalon.Name = "btnSalon";
            this.btnSalon.Size = new System.Drawing.Size(260, 48);
            this.btnSalon.TabIndex = 0;
            this.btnSalon.Text = "Salon Yapılandır";
            this.btnSalon.UseVisualStyleBackColor = true;
            this.btnSalon.Click += new System.EventHandler(this.btnSalon_Click);
            // 
            // btnCikis
            // 
            this.btnCikis.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnCikis.FlatAppearance.BorderSize = 3;
            this.btnCikis.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnCikis.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnCikis.Location = new System.Drawing.Point(20, 235);
            this.btnCikis.Name = "btnCikis";
            this.btnCikis.Size = new System.Drawing.Size(260, 44);
            this.btnCikis.TabIndex = 3;
            this.btnCikis.Text = "ÇIKIŞ";
            this.btnCikis.UseVisualStyleBackColor = true;
            this.btnCikis.Click += new System.EventHandler(this.btnCikis_Click);
            // 
            // frmGiris
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(300, 315);
            this.Controls.Add(this.groupBox1);
            this.Name = "frmGiris";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "İSMEK SİNEMA SALONLARI";
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnSalon;
        private System.Windows.Forms.Button btnFilm;
        private System.Windows.Forms.ImageList imList;
        private System.Windows.Forms.Button btnBilet;
        private System.Windows.Forms.ImageList ımageList1;
        private System.Windows.Forms.Button btnCikis;
    }
}