﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sinema
{
    public partial class frmGiris : Form
    {
        public frmGiris()
        {
            InitializeComponent();
        }

        private void btnSalon_Click(object sender, EventArgs e)
        {
            frmSalon frm = new frmSalon();
            frm.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmFilmGiris frm = new frmFilmGiris();
            frm.ShowDialog();
        }

        private void btnBilet_Click(object sender, EventArgs e)
        {
            frmBilet frm = new frmBilet();
            frm.ShowDialog();
        }

        private void btnCikis_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
