﻿namespace _02_Formdemo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tbsayi = new System.Windows.Forms.TextBox();
            this.btnarti = new System.Windows.Forms.Button();
            this.btneksi = new System.Windows.Forms.Button();
            this.tbperiod = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.ımageList1 = new System.Windows.Forms.ImageList(this.components);
            this.SuspendLayout();
            // 
            // tbsayi
            // 
            this.tbsayi.Location = new System.Drawing.Point(147, 36);
            this.tbsayi.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tbsayi.Name = "tbsayi";
            this.tbsayi.ReadOnly = true;
            this.tbsayi.Size = new System.Drawing.Size(82, 22);
            this.tbsayi.TabIndex = 0;
            this.tbsayi.Text = "0";
            this.tbsayi.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnarti
            // 
            this.btnarti.Font = new System.Drawing.Font("Wingdings 2", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(2)));
            this.btnarti.Location = new System.Drawing.Point(237, 36);
            this.btnarti.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnarti.Name = "btnarti";
            this.btnarti.Size = new System.Drawing.Size(33, 28);
            this.btnarti.TabIndex = 1;
            this.btnarti.Text = "Ì";
            this.btnarti.UseVisualStyleBackColor = true;
            this.btnarti.Click += new System.EventHandler(this.btnarti_Click);
            // 
            // btneksi
            // 
            this.btneksi.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btneksi.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btneksi.ImageIndex = 0;
            this.btneksi.ImageList = this.ımageList1;
            this.btneksi.Location = new System.Drawing.Point(58, 35);
            this.btneksi.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btneksi.Name = "btneksi";
            this.btneksi.Size = new System.Drawing.Size(61, 23);
            this.btneksi.TabIndex = 2;
            this.btneksi.Text = "-";
            this.btneksi.UseVisualStyleBackColor = true;
            this.btneksi.Click += new System.EventHandler(this.btneksi_Click);
            // 
            // tbperiod
            // 
            this.tbperiod.Location = new System.Drawing.Point(147, 77);
            this.tbperiod.Name = "tbperiod";
            this.tbperiod.Size = new System.Drawing.Size(82, 22);
            this.tbperiod.TabIndex = 3;
            this.tbperiod.Text = "1";
            this.tbperiod.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.tbperiod.TextChanged += new System.EventHandler(this.tbperiod_TextChanged);
            // 
            // button1
            // 
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.ImageList = this.ımageList1;
            this.button1.Location = new System.Drawing.Point(424, 122);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(168, 47);
            this.button1.TabIndex = 4;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // ımageList1
            // 
            this.ımageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ımageList1.ImageStream")));
            this.ımageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.ımageList1.Images.SetKeyName(0, "eksi.PNG");
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(947, 610);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tbperiod);
            this.Controls.Add(this.btneksi);
            this.Controls.Add(this.btnarti);
            this.Controls.Add(this.tbsayi);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbsayi;
        private System.Windows.Forms.Button btnarti;
        private System.Windows.Forms.Button btneksi;
        private System.Windows.Forms.TextBox tbperiod;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ImageList ımageList1;
    }
}

