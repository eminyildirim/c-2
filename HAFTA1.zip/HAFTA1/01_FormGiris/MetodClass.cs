﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01_FormGiris
{
    public class MetodClass
    {
        public static bool adsoyadCheck(String a)
        {
            bool kontrol = true;
            if (a.Length < 3)
            {
                kontrol = false;
            }
            else
            {
                for (int i = 0; i < a.Length; i++)
                {
                    if (!char.IsLetter(a[i]) && !char.IsWhiteSpace(a[i])) { kontrol = false; break; }
                }
            }
            return kontrol;
        }
        public static String adsoyadCheck(String a,String b)
        {
            String kontrol = "";
            if (a.Length < 3)
            {
                kontrol = "2 Harfden Küçük olamaz";
            }
            else
            {
                for (int i = 0; i < a.Length; i++)
                {
                    if (!char.IsLetter(a[i]) && !char.IsWhiteSpace(a[i])) { kontrol = "Sadece Harf yazın!"; break; }
                }
            }
            return kontrol;
        }
    }
}
