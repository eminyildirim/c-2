﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _01_FormGiris
{
    public partial class frmGiris : Form
    {
        public frmGiris()
        {
            InitializeComponent();
        }
        private bool adsoyadKontrol(String a)
        {
            bool kontrol = true;
            if (a.Length < 3)
            {
                kontrol = false;
            }
            else
            {
                for (int i = 0; i < a.Length; i++)
                {
                    if(!char.IsLetter(a[i])&&!char.IsWhiteSpace(a[i])) { kontrol = false; break; }
                }
            }
            return kontrol;
        }
        private void btnGoster_Click(object sender, EventArgs e)
        {
            String adsoyad = tbAdi.Text.Substring(0, 1).ToUpper() + tbAdi.Text.Substring(1) + " " + tbSoyadi.Text.ToUpper();
            MessageBox.Show(adsoyad);
            DialogResult dialogResult = MessageBox.Show((tbAdi.Text + " " + tbSoyadi.Text).ToUpper(), "", MessageBoxButtons.YesNo);

        }

        private void btnTemizle_Click(object sender, EventArgs e)
        {
            tbAdi.Text = "";
            tbSoyadi.Text = "";
            btnGoster.Enabled = false;
        }

        private void btnRenk_Click(object sender, EventArgs e)
        {
            DialogResult result = renkdialog.ShowDialog();
            // See if user pressed ok.
            if (result == DialogResult.OK)
            {
                // Set form background to the selected color.
                radioButton1.Checked = false;
                radioButton2.Checked = false;
                radioButton3.Checked = false;
                radioButton4.Checked = false;
                this.BackColor = renkdialog.Color;

            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            this.BackColor = Color.Blue;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            this.BackColor = Color.Yellow;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            this.BackColor = Color.Green;
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            this.BackColor = Color.Red;
        }

        private void btnFontsec_Click(object sender, EventArgs e)
        {
            DialogResult result = fontsecim.ShowDialog();
            // See if user pressed ok.
            if (result == DialogResult.OK)
            {
                this.Font = fontsecim.Font;
            }
        }

        private void btnTemizle_MouseHover(object sender, EventArgs e)
        {
            btnTemizle.BackColor = Color.Red;
        }

        private void btnTemizle_MouseLeave(object sender, EventArgs e)
        {
            btnTemizle.BackColor = DefaultBackColor;
        }

        private void btnListeEkle_Click(object sender, EventArgs e)
        {
            // btnTextKontrol_Click( sender,  e); buda olur
            btnTextKontrol.PerformClick();
            
            MessageBox.Show(sender.ToString()+" "+e.ToString());
            
            if (label3.Equals("")) {
                String adsoyad = tbAdi.Text.Substring(0, 1).ToUpper() + tbAdi.Text.Substring(1) + " " + tbSoyadi.Text.ToUpper();
                lbAdSoyad.Items.Add(adsoyad);
            }

        }

        private void lbAdSoyad_DoubleClick(object sender, EventArgs e)
        {

            MessageBox.Show(lbAdSoyad.SelectedIndex.ToString() +" "+lbAdSoyad.SelectedItem.ToString());
        }

        private void btnTextKontrol_Click(object sender, EventArgs e)
        {
            String sonuc = MetodClass.adsoyadCheck(tbAdi.Text, "");
            if(!sonuc.Equals(""))
            {
                label3.Text = "adı: "+sonuc;
            }
            else
            {
                sonuc = MetodClass.adsoyadCheck(tbSoyadi.Text, "");
                if (!sonuc.Equals(""))
                {
                    label3.Text = "soyadı:"+sonuc;
                }
                else
                {
                    btnGoster.Enabled = true;
                    String adsoyad = tbAdi.Text.Substring(0, 1).ToUpper() + tbAdi.Text.Substring(1) + " " + tbSoyadi.Text.ToUpper();
                    lbAdSoyad.Items.Add(adsoyad);

                }
            }
            /*
       // MetodClass.adsoyadCheck
            if (!adsoyadKontrol(tbAdi.Text))
            {
                label3.Text = "Adı Hatalı";
                // MessageBox.Show("Hatalı Ad");
            }
            else
            {
                if (!adsoyadKontrol(tbSoyadi.Text))
                {
                    label3.Text = "Soyadı Hatalı";
                    //MessageBox.Show("Hatalı Soyad");
                }
                else
                {
                    String adsoyad = tbAdi.Text.Substring(0, 1).ToUpper() + tbAdi.Text.Substring(1) + " " + tbSoyadi.Text.ToUpper();
                    lbAdSoyad.Items.Add(adsoyad);
                }
            }
            */
       
        }

        private void tbAdi_TextChanged(object sender, EventArgs e)
        {
            label3.Text = "";
            btnGoster.Enabled = false;
        }

        private void tbSoyadi_TextChanged(object sender, EventArgs e)
        {
            label3.Text = "";
            btnGoster.Enabled = false;
        }

        private void frmGiris_Activated(object sender, EventArgs e)
        {
            label3.Text = "";
           // btnGoster.Enabled = false;
        }

        private void frmGiris_Load(object sender, EventArgs e)
        {
            btnGoster.Enabled = false;
        }
    }
}
