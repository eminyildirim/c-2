﻿namespace _02_ListBoxDeneme
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.resim = new System.Windows.Forms.PictureBox();
            this.resimsec = new System.Windows.Forms.OpenFileDialog();
            this.tbad = new System.Windows.Forms.TextBox();
            this.tbsifre = new System.Windows.Forms.TextBox();
            this.btnbak = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.imlist = new System.Windows.Forms.ImageList(this.components);
            this.btnresim = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.resim)).BeginInit();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.AllowDrop = true;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(441, 39);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(157, 381);
            this.listBox1.TabIndex = 0;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            this.listBox1.DoubleClick += new System.EventHandler(this.listBox1_DoubleClick);
            // 
            // listBox2
            // 
            this.listBox2.BackColor = System.Drawing.SystemColors.Window;
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Location = new System.Drawing.Point(619, 39);
            this.listBox2.Name = "listBox2";
            this.listBox2.ScrollAlwaysVisible = true;
            this.listBox2.Size = new System.Drawing.Size(140, 381);
            this.listBox2.TabIndex = 1;
            this.listBox2.DragLeave += new System.EventHandler(this.listBox2_DragLeave);
            this.listBox2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox2_MouseDown);
            this.listBox2.MouseLeave += new System.EventHandler(this.listBox2_MouseLeave);
            this.listBox2.MouseHover += new System.EventHandler(this.listBox2_MouseHover);
            // 
            // resim
            // 
            this.resim.BackColor = System.Drawing.SystemColors.ControlDark;
            this.resim.ErrorImage = null;
            this.resim.Image = global::_02_ListBoxDeneme.Properties.Resources.resim;
            this.resim.Location = new System.Drawing.Point(43, 12);
            this.resim.Name = "resim";
            this.resim.Padding = new System.Windows.Forms.Padding(10);
            this.resim.Size = new System.Drawing.Size(181, 177);
            this.resim.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resim.TabIndex = 2;
            this.resim.TabStop = false;
            this.resim.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // tbad
            // 
            this.tbad.Location = new System.Drawing.Point(80, 217);
            this.tbad.Name = "tbad";
            this.tbad.Size = new System.Drawing.Size(181, 20);
            this.tbad.TabIndex = 3;
            // 
            // tbsifre
            // 
            this.tbsifre.Location = new System.Drawing.Point(80, 243);
            this.tbsifre.Name = "tbsifre";
            this.tbsifre.PasswordChar = '*';
            this.tbsifre.Size = new System.Drawing.Size(100, 20);
            this.tbsifre.TabIndex = 4;
            // 
            // btnbak
            // 
            this.btnbak.Location = new System.Drawing.Point(186, 243);
            this.btnbak.Name = "btnbak";
            this.btnbak.Size = new System.Drawing.Size(75, 23);
            this.btnbak.TabIndex = 5;
            this.btnbak.Text = "Kontrol";
            this.btnbak.UseVisualStyleBackColor = true;
            this.btnbak.Click += new System.EventHandler(this.btnbak_Click);
            this.btnbak.MouseLeave += new System.EventHandler(this.btnbak_MouseLeave);
            this.btnbak.MouseHover += new System.EventHandler(this.btnbak_MouseHover);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 220);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Kullanıcı:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 246);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "password";
            // 
            // imlist
            // 
            this.imlist.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imlist.ImageStream")));
            this.imlist.TransparentColor = System.Drawing.Color.Transparent;
            this.imlist.Images.SetKeyName(0, "0.png");
            this.imlist.Images.SetKeyName(1, "1.PNG");
            this.imlist.Images.SetKeyName(2, "2.PNG");
            this.imlist.Images.SetKeyName(3, "3.PNG");
            this.imlist.Images.SetKeyName(4, "4.PNG");
            this.imlist.Images.SetKeyName(5, "11.PNG");
            this.imlist.Images.SetKeyName(6, "yok.PNG");
            // 
            // btnresim
            // 
            this.btnresim.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnresim.ImageIndex = 0;
            this.btnresim.ImageList = this.imlist;
            this.btnresim.Location = new System.Drawing.Point(186, 272);
            this.btnresim.Name = "btnresim";
            this.btnresim.Size = new System.Drawing.Size(120, 50);
            this.btnresim.TabIndex = 8;
            this.btnresim.Text = "Resimli Button";
            this.btnresim.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnresim.UseVisualStyleBackColor = true;
            this.btnresim.Click += new System.EventHandler(this.btnresim_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(813, 562);
            this.Controls.Add(this.btnresim);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnbak);
            this.Controls.Add(this.tbsifre);
            this.Controls.Add(this.tbad);
            this.Controls.Add(this.resim);
            this.Controls.Add(this.listBox2);
            this.Controls.Add(this.listBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.resim)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.PictureBox resim;
        private System.Windows.Forms.OpenFileDialog resimsec;
        private System.Windows.Forms.TextBox tbad;
        private System.Windows.Forms.TextBox tbsifre;
        private System.Windows.Forms.Button btnbak;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ImageList imlist;
        private System.Windows.Forms.Button btnresim;
    }
}

