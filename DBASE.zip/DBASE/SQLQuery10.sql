USE [C2KURS]
GO

SELECT [id]
      ,[adsoyad],[burs]
      ,Convert(money,[burs]*1.051+100 ) As ZamliBurs,Convert(char(10),GETDATE(),104) AS [G�n�n Tarihi],Convert(char(10),GETDATE(),108) AS [Saat],
	  str(id,2)+'-'+adsoyad as [noadsoyad],
	  convert(char(5),id) as nochar
  FROM [dbo].[burs]
  WHERE NOT (adsoyad LIKE '%YIL%' or Burs <=500)
GO


