﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace DERS4_ARRAY
{
    public partial class Form1 : Form
    {
        ArrayList liste = new ArrayList();
        SortedList sliste = new SortedList();
        Hashtable hliste = new Hashtable();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            foreach (var item in liste)
            {
                listBox1.Items.Add(item);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            liste.Add(textBox1.Text);
            listBox1.Items.Add(textBox1.Text);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            liste.Add(1);
            liste.Add(11);
            liste.Add("aaaa");
            liste.Add('B');

            sliste.Add(6, "ANKARA");
            sliste.Add(1, "ADANA");
            sliste.Add(17, "ÇANAKKALE");
            sliste.Add(10, "BALIKKESİR");
            sliste.Add(11, "BİLECİK");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            foreach (var item in sliste.Keys)
            {
                listBox1.Items.Add(item.ToString());
           
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Queue lQueue = new Queue();
            lQueue.Enqueue("BİR");
            lQueue.Enqueue("İKİ");
            lQueue.Enqueue("ÜÇ");
            lQueue.Enqueue("DÖRT");
            while (lQueue.Count>0)
            {
                listBox1.Items.Add(lQueue.Dequeue());
            }
 
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Stack lstack = new Stack();
            lstack.Push("BİR");
            lstack.Push("İKİ");
            lstack.Push("ÜÇ");
            lstack.Push("DÖRT");
            while (lstack.Count > 0)
            {
                listBox1.Items.Add(lstack.Pop());
            }
        }
    }
}
