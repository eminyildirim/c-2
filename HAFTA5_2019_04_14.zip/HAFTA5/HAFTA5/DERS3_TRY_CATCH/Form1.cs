﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DERS3_TRY_CATCH
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int sayi1, sayi2;
            Double sayi;
            try
            {
                sayi1 = Convert.ToInt32(textBox1.Text);
                sayi2 = Convert.ToInt32(textBox2.Text);
                label1.Text = (sayi1 + sayi2).ToString();
                sayi = sayi1;
            }
            catch (FormatException)            {
                
                MessageBox.Show("Hatalı Bilgili");
            }
            catch (OverflowException)
            {      
                MessageBox.Show("Sayı değeri çok büyük");
            }
            catch (InvalidCastException)
            {         
                MessageBox.Show("InvalidCastException");
            }
            finally
            {
             // Hata olsun olmasın Çalışır
            }

        }
    }
}
