﻿namespace NotSistemi
{
    partial class FormOgretmen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tcOgretmen = new System.Windows.Forms.TabControl();
            this.tpOgrenci = new System.Windows.Forms.TabPage();
            this.tpMesaj = new System.Windows.Forms.TabPage();
            this.tpDuyuru = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tcOgretmen.SuspendLayout();
            this.tpMesaj.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tcOgretmen
            // 
            this.tcOgretmen.Controls.Add(this.tpOgrenci);
            this.tcOgretmen.Controls.Add(this.tpMesaj);
            this.tcOgretmen.Controls.Add(this.tpDuyuru);
            this.tcOgretmen.Location = new System.Drawing.Point(12, 13);
            this.tcOgretmen.Name = "tcOgretmen";
            this.tcOgretmen.SelectedIndex = 0;
            this.tcOgretmen.Size = new System.Drawing.Size(1011, 591);
            this.tcOgretmen.TabIndex = 0;
            // 
            // tpOgrenci
            // 
            this.tpOgrenci.BackColor = System.Drawing.Color.SkyBlue;
            this.tpOgrenci.Location = new System.Drawing.Point(4, 22);
            this.tpOgrenci.Name = "tpOgrenci";
            this.tpOgrenci.Padding = new System.Windows.Forms.Padding(3);
            this.tpOgrenci.Size = new System.Drawing.Size(1003, 565);
            this.tpOgrenci.TabIndex = 0;
            this.tpOgrenci.Text = "Öğrenciler";
            // 
            // tpMesaj
            // 
            this.tpMesaj.BackColor = System.Drawing.Color.AntiqueWhite;
            this.tpMesaj.Controls.Add(this.panel1);
            this.tpMesaj.Location = new System.Drawing.Point(4, 22);
            this.tpMesaj.Name = "tpMesaj";
            this.tpMesaj.Padding = new System.Windows.Forms.Padding(3);
            this.tpMesaj.Size = new System.Drawing.Size(1003, 565);
            this.tpMesaj.TabIndex = 1;
            this.tpMesaj.Text = "Mesajlar";
            // 
            // tpDuyuru
            // 
            this.tpDuyuru.BackColor = System.Drawing.Color.PaleTurquoise;
            this.tpDuyuru.Location = new System.Drawing.Point(4, 22);
            this.tpDuyuru.Name = "tpDuyuru";
            this.tpDuyuru.Padding = new System.Windows.Forms.Padding(3);
            this.tpDuyuru.Size = new System.Drawing.Size(1003, 565);
            this.tpDuyuru.TabIndex = 2;
            this.tpDuyuru.Text = "Duyurular";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(260, 53);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(351, 305);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Location = new System.Drawing.Point(61, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(283, 295);
            this.panel2.TabIndex = 0;
            // 
            // FormOgretmen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1105, 616);
            this.Controls.Add(this.tcOgretmen);
            this.Name = "FormOgretmen";
            this.Text = "FormOgretmen";
            this.Load += new System.EventHandler(this.FormOgretmen_Load);
            this.tcOgretmen.ResumeLayout(false);
            this.tpMesaj.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tcOgretmen;
        private System.Windows.Forms.TabPage tpOgrenci;
        private System.Windows.Forms.TabPage tpMesaj;
        private System.Windows.Forms.TabPage tpDuyuru;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
    }
}