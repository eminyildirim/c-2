﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Sql;
using System.Data.SqlClient;

namespace NotSistemi
{
    class DataClass
    {
        public SqlConnection cn = new SqlConnection(@"Data Source=LAB02-12;Initial Catalog=Rehber;Integrated Security=True");
        public SqlCommand cmd;
        public SqlDataReader dr;

        public int ID { get; set; }
        public string user { get; set; }
        public string username { get; set; }
    }
}
