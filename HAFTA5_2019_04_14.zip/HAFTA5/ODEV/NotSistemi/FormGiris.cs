﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NotSistemi
{
    public partial class frmGiris : Form
    {
        public frmGiris()
        {
            InitializeComponent();
        }

        private void frmGiris_Load(object sender, EventArgs e)
        {
            cbKim.SelectedIndex = 0;
        }

        private void cbKim_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.Text= cbKim.Text + " Girişi";
            //labelNo.Text = cbKim.Text + " No:";
        }

        private void btnGiris_Click(object sender, EventArgs e)
        {
            FormOgretmen frm = new FormOgretmen();
            this.Hide();
            frm.Show();
        }
    }
}
