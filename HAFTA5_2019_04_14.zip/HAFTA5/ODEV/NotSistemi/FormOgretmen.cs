﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NotSistemi
{
    public partial class FormOgretmen : Form
    {
        public FormOgretmen()
        {
            InitializeComponent();
        }

        private void FormOgretmen_Load(object sender, EventArgs e)
        {
            tcOgretmen.TabPages[1].Text = "DENEME";
            //tcOgretmen.TabPages[1].Hide();
            tcOgretmen.TabPages.Remove(tcOgretmen.TabPages[1]);
           // tcOgretmen.TabPages.RemoveAt(1);
            tcOgretmen.TabPages.Add("tpMesaj");
        }
    }
}
