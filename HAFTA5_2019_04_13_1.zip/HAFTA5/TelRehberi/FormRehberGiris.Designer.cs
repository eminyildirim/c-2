﻿namespace TelRehberi
{
    partial class FormRehberGiris
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tbAd = new System.Windows.Forms.TextBox();
            this.tbSoyad = new System.Windows.Forms.TextBox();
            this.tbTel = new System.Windows.Forms.TextBox();
            this.tbEmail = new System.Windows.Forms.TextBox();
            this.tbAdres = new System.Windows.Forms.TextBox();
            this.btnKayit = new System.Windows.Forms.Button();
            this.dgwRehber = new System.Windows.Forms.DataGridView();
            this.TRRef = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TRAd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TRSoyad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TRTel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TREmail = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TRAdres = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnDuzelt = new System.Windows.Forms.Button();
            this.btnSil = new System.Windows.Forms.Button();
            this.btnCikis = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgwRehber)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnKayit);
            this.panel1.Controls.Add(this.tbAdres);
            this.panel1.Controls.Add(this.tbEmail);
            this.panel1.Controls.Add(this.tbTel);
            this.panel1.Controls.Add(this.tbSoyad);
            this.panel1.Controls.Add(this.tbAd);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(335, 491);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(15, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ad";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(15, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Soyadı:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(15, 82);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Tel";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(15, 117);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Email";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(15, 151);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "Adres";
            // 
            // tbAd
            // 
            this.tbAd.Location = new System.Drawing.Point(98, 19);
            this.tbAd.Name = "tbAd";
            this.tbAd.Size = new System.Drawing.Size(200, 20);
            this.tbAd.TabIndex = 5;
            // 
            // tbSoyad
            // 
            this.tbSoyad.Location = new System.Drawing.Point(98, 49);
            this.tbSoyad.Name = "tbSoyad";
            this.tbSoyad.Size = new System.Drawing.Size(200, 20);
            this.tbSoyad.TabIndex = 6;
            // 
            // tbTel
            // 
            this.tbTel.Location = new System.Drawing.Point(98, 77);
            this.tbTel.Name = "tbTel";
            this.tbTel.Size = new System.Drawing.Size(141, 20);
            this.tbTel.TabIndex = 7;
            // 
            // tbEmail
            // 
            this.tbEmail.Location = new System.Drawing.Point(98, 112);
            this.tbEmail.Name = "tbEmail";
            this.tbEmail.Size = new System.Drawing.Size(234, 20);
            this.tbEmail.TabIndex = 8;
            // 
            // tbAdres
            // 
            this.tbAdres.Location = new System.Drawing.Point(98, 151);
            this.tbAdres.Multiline = true;
            this.tbAdres.Name = "tbAdres";
            this.tbAdres.Size = new System.Drawing.Size(234, 135);
            this.tbAdres.TabIndex = 9;
            // 
            // btnKayit
            // 
            this.btnKayit.Location = new System.Drawing.Point(243, 293);
            this.btnKayit.Name = "btnKayit";
            this.btnKayit.Size = new System.Drawing.Size(75, 23);
            this.btnKayit.TabIndex = 10;
            this.btnKayit.Text = "Kayıt EKle";
            this.btnKayit.UseVisualStyleBackColor = true;
            this.btnKayit.Click += new System.EventHandler(this.btnKayit_Click);
            // 
            // dgwRehber
            // 
            this.dgwRehber.AllowUserToAddRows = false;
            this.dgwRehber.AllowUserToDeleteRows = false;
            this.dgwRehber.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgwRehber.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.TRRef,
            this.TRAd,
            this.TRSoyad,
            this.TRTel,
            this.TREmail,
            this.TRAdres});
            this.dgwRehber.Location = new System.Drawing.Point(374, 13);
            this.dgwRehber.MultiSelect = false;
            this.dgwRehber.Name = "dgwRehber";
            this.dgwRehber.ReadOnly = true;
            this.dgwRehber.RowHeadersVisible = false;
            this.dgwRehber.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgwRehber.Size = new System.Drawing.Size(772, 490);
            this.dgwRehber.TabIndex = 1;
            this.dgwRehber.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgwRehber_CellClick);
            // 
            // TRRef
            // 
            this.TRRef.DataPropertyName = "TRRef";
            this.TRRef.HeaderText = "Ref";
            this.TRRef.Name = "TRRef";
            this.TRRef.Visible = false;
            // 
            // TRAd
            // 
            this.TRAd.DataPropertyName = "TRAd";
            this.TRAd.HeaderText = "Adı";
            this.TRAd.Name = "TRAd";
            this.TRAd.Width = 150;
            // 
            // TRSoyad
            // 
            this.TRSoyad.DataPropertyName = "TRSoyad";
            this.TRSoyad.HeaderText = "Soyadı";
            this.TRSoyad.Name = "TRSoyad";
            this.TRSoyad.Width = 150;
            // 
            // TRTel
            // 
            this.TRTel.DataPropertyName = "TRTel";
            this.TRTel.HeaderText = "Telefon No";
            this.TRTel.Name = "TRTel";
            // 
            // TREmail
            // 
            this.TREmail.DataPropertyName = "TREmail";
            this.TREmail.HeaderText = "Mail Adresi";
            this.TREmail.Name = "TREmail";
            this.TREmail.Width = 150;
            // 
            // TRAdres
            // 
            this.TRAdres.DataPropertyName = "TRAdres";
            this.TRAdres.HeaderText = "Adresi";
            this.TRAdres.Name = "TRAdres";
            this.TRAdres.Width = 150;
            // 
            // btnDuzelt
            // 
            this.btnDuzelt.Location = new System.Drawing.Point(1153, 23);
            this.btnDuzelt.Name = "btnDuzelt";
            this.btnDuzelt.Size = new System.Drawing.Size(75, 23);
            this.btnDuzelt.TabIndex = 2;
            this.btnDuzelt.Text = "Düzeltme";
            this.btnDuzelt.UseVisualStyleBackColor = true;
            this.btnDuzelt.Click += new System.EventHandler(this.btnDuzelt_Click);
            // 
            // btnSil
            // 
            this.btnSil.Location = new System.Drawing.Point(1153, 53);
            this.btnSil.Name = "btnSil";
            this.btnSil.Size = new System.Drawing.Size(75, 23);
            this.btnSil.TabIndex = 3;
            this.btnSil.Text = "Sil";
            this.btnSil.UseVisualStyleBackColor = true;
            this.btnSil.Click += new System.EventHandler(this.btnSil_Click);
            // 
            // btnCikis
            // 
            this.btnCikis.Location = new System.Drawing.Point(1153, 89);
            this.btnCikis.Name = "btnCikis";
            this.btnCikis.Size = new System.Drawing.Size(75, 23);
            this.btnCikis.TabIndex = 4;
            this.btnCikis.Text = "Çıkış";
            this.btnCikis.UseVisualStyleBackColor = true;
            this.btnCikis.Click += new System.EventHandler(this.btnCikis_Click);
            // 
            // FormRehberGiris
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1247, 602);
            this.Controls.Add(this.btnCikis);
            this.Controls.Add(this.btnSil);
            this.Controls.Add(this.btnDuzelt);
            this.Controls.Add(this.dgwRehber);
            this.Controls.Add(this.panel1);
            this.Name = "FormRehberGiris";
            this.Text = "FormRehberGiris";
            this.Load += new System.EventHandler(this.FormRehberGiris_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgwRehber)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnKayit;
        private System.Windows.Forms.TextBox tbAdres;
        private System.Windows.Forms.TextBox tbEmail;
        private System.Windows.Forms.TextBox tbTel;
        private System.Windows.Forms.TextBox tbSoyad;
        private System.Windows.Forms.TextBox tbAd;
        private System.Windows.Forms.DataGridView dgwRehber;
        private System.Windows.Forms.DataGridViewTextBoxColumn TRRef;
        private System.Windows.Forms.DataGridViewTextBoxColumn TRAd;
        private System.Windows.Forms.DataGridViewTextBoxColumn TRSoyad;
        private System.Windows.Forms.DataGridViewTextBoxColumn TRTel;
        private System.Windows.Forms.DataGridViewTextBoxColumn TREmail;
        private System.Windows.Forms.DataGridViewTextBoxColumn TRAdres;
        private System.Windows.Forms.Button btnDuzelt;
        private System.Windows.Forms.Button btnSil;
        private System.Windows.Forms.Button btnCikis;
    }
}