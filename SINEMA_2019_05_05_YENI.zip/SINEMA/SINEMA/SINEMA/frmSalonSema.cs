﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sinema
{
    public partial class frmSalonSema : Form
    {
        public frmSalonSema()
        {
            InitializeComponent();
        }
        private void SalonDuvar(int En,int Boy,Panel p)
        {
            System.Drawing.SolidBrush myBrush = new System.Drawing.SolidBrush(System.Drawing.Color.Red);
            System.Drawing.Graphics formGraphics;
            formGraphics = p.CreateGraphics();
            // formGraphics.FillRectangle(myBrush, new Rectangle(0, 0, 200, 300));
            Rectangle rectangle1 = new Rectangle(0, 0, En, Boy);
            Pen blackPen = new Pen(Color.Black, 3);
            formGraphics.DrawRectangle(blackPen, rectangle1);
            myBrush.Dispose();
            formGraphics.Dispose();
        }
        private void Ucgen(Panel p, Point[] points, SolidBrush sb)
        {
            
            Graphics g = p.CreateGraphics();        
            g.FillPolygon(sb, points);
  
        }
        private void btnCiz_Click(object sender, EventArgs e)
        {
            int En, Boy;
            En = int.Parse(mtbArka.Text);
            Boy = int.Parse(mtbSahneBoyu.Text);
            //SalonDuvar(En, Boy,pSalon);
    
        }
        private void koltuk_Click(object sender, EventArgs e)
        {
            PictureBox pb = new PictureBox();
            pb = (sender as PictureBox);
            if (pb.Tag.ToString()=="1")
            {
                pb.Image = global::Sinema.Properties.Resources.koltuksil;
                pb.Tag = 0;
            }
            else
            {
                pb.Image = global::Sinema.Properties.Resources.koltuk;
                pb.Tag = 1;
            }
           
            MessageBox.Show(pb.Name.ToString());
        }
        private void frmSalonSema_Load(object sender, EventArgs e)
        {

            VScrollBar myVScrollBar = new VScrollBar();
            HScrollBar myHScrollBar = new HScrollBar();
            myVScrollBar.Height = pSalon.Height+2000;
            myVScrollBar.Left = pSalon.Width - myVScrollBar.Width;
            myVScrollBar.Top = 0;
            myVScrollBar.Enabled = true;
            pSalon.Controls.Add(myVScrollBar);
            pSalon.Controls.Add(myHScrollBar);
            pSalon.HorizontalScroll.Visible = true;
            pSalon.VerticalScroll.Visible = true;
        }

        private void frmSalonSema_Paint(object sender, PaintEventArgs e)
        {
            /*
            System.Drawing.SolidBrush myBrush = new System.Drawing.SolidBrush(System.Drawing.Color.Red);
            System.Drawing.Graphics formGraphics;
            formGraphics = pSalon.CreateGraphics();
            formGraphics.DrawRectangle(Pens.Red, new Rectangle(0, 0, 200, 1300));
            myBrush.Dispose();
            formGraphics.Dispose();
          */
            /*
              int En, Boy;
              En = int.Parse(mtbEn.Text);
              Boy = int.Parse(mtbBoy.Text);
              SalonDuvar(En, Boy, pSalon);
              */

            // Create a rectangle.
            Rectangle rectangle1 = new Rectangle(30, 40, 50, 100);

            // Convert it to a RectangleF.
            RectangleF convertedRectangle = rectangle1;

            // Create a new RectangleF.
            RectangleF rectangle2 = new RectangleF(new PointF(30.0F, 40.0F),
                new SizeF(50.0F, 100.0F));

            // Create a custom, partially transparent brush.
            SolidBrush redBrush = new SolidBrush(Color.FromArgb(40, Color.Red));

            // Compare the converted rectangle with the new one.  If they 
            // are equal draw and fill the rectangles on the form.
            if (convertedRectangle == rectangle2)
            {
                e.Graphics.FillRectangle(redBrush, rectangle2);
            }

            // Dispose of the custom brush.
            redBrush.Dispose();
        }

        private void btnUcgen_Click(object sender, EventArgs e)
        {
            Point[] points = { new Point(pSalon.Width/2,0), new Point(0, pSalon.Height/2), new Point(pSalon.Width, pSalon.Height / 2) };
            Ucgen(pSalon, points, new SolidBrush(Color.Red));
        }

        private void btnDortgen_Click(object sender, EventArgs e)
        {
            int ustboy, altboy, yukseklik;
            ustboy = 600;
            altboy = 500;
            yukseklik = 800;
          //  Point[] points = { new Point(pSalon.Width / 4, 0), new Point(3*pSalon.Width / 4, 0), new Point(pSalon.Width / 4,pSalon.Height-100), new Point(3*pSalon.Width/4, pSalon.Height-100) };
            Point[] points = { new Point(40, yukseklik), new Point((pSalon.Width-ustboy)/2, 5), new Point(ustboy, 5), new Point(pSalon.Width / 4-10, pSalon.Height -100) };
            Ucgen(pSalon, points, new SolidBrush(Color.Red));
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int ustboy, altboy, yukseklik;
            ustboy = 700;
            altboy = 500;
            yukseklik = 300;
            this.Height = 1;
            this.Height = 800;
            int n1x, n1y;
            n1x = int.Parse(koltukGenislik.Text);
            n1y = int.Parse(koltukAralik.Text);
            n1x = (pSalon.Width - ustboy) / 2;
            koltukGenislik.Text = n1x.ToString();
            n1y = 0;
            koltukAralik.Text = n1y.ToString();
            int n2x, n2y;
            n2x = int.Parse(koltukBoyu.Text);
            n2y = int.Parse(k2y.Text);
            n2y = yukseklik;
            koltukBoyu.Text = n2x.ToString();
            k2y.Text = n2y.ToString();
            int n3x, n3y;
            n3x = int.Parse(k3x.Text);
            n3y = int.Parse(k3y.Text);
            int n4x, n4y;
            n4x = n1x + ustboy;
            k4x.Text = n4x.ToString();
            n4y = int.Parse(k4y.Text);

            //  Point[] points = { new Point(pSalon.Width / 4, 0), new Point(3*pSalon.Width / 4, 0), new Point(pSalon.Width / 4,pSalon.Height-100), new Point(3*pSalon.Width/4, pSalon.Height-100) };
            Point[] points = { new Point(n2x, n2y), new Point(n1x, n1y), new Point(n3x,n3y), new Point(n4x,n4y) };
            Ucgen(pSalon, points, new SolidBrush(Color.Red));
        }

        private void button2_Click(object sender, EventArgs e)
        {
            /*
            while (pSalon.Controls.Count > 0)
            {
                pSalon.Controls.RemoveAt(pSalon.Controls.Count - 1);
            }
            */
            int bas = 0;
            int sahneBoyu = 400;
            int arka = 500;
            int yuk = 800;
  
            arka = int.Parse(mtbArka.Text);
            sahneBoyu = int.Parse(mtbSahneBoyu.Text);
            yuk = int.Parse(mtbDerinlik.Text);
            int koltukGen = int.Parse(koltukGenislik.Text);
            int koltukBoy = int.Parse(koltukBoyu.Text);
            int koltukAra = int.Parse(koltukAralik.Text);

            int fark = (arka - sahneBoyu) /2;
            Point[] points = { new Point(bas, bas), new Point(fark+bas, yuk+bas), new Point(arka - fark+bas, yuk+bas), new Point(arka + bas, bas) };
           // Ucgen(pSalon, points, new SolidBrush(Color.LightGreen));
            int s1 = arka / koltukGen;
            int s2 = yuk / (koltukBoy + koltukAra);
            for (int j = 0; j < s2; j++)
            {
                int sira = bas +(koltukBoy + koltukAra) *j;
                for (int i = 0; i < s1; i++)
                {
                    fark = 0;
                    yuk = koltukBoy;
                    arka = koltukGen-2;                
                    Point[] points1 = { new Point(bas + i * koltukGen, sira), new Point(bas + i * koltukGen, yuk+sira), new Point(arka + i * koltukGen, yuk+sira), new Point(arka + i * koltukGen, sira) };
                   // Ucgen(pSalon, points1, new SolidBrush(Color.Red));


                    System.Windows.Forms.PictureBox k1 = new System.Windows.Forms.PictureBox();

                    k1.Image = global::Sinema.Properties.Resources.koltuk;
                    k1.Location = new System.Drawing.Point(bas + i * koltukGen, sira);
                    k1.Size = new System.Drawing.Size(koltukGen, koltukBoy);
                    k1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
                    k1.TabIndex = 0;
                    k1.Tag = 1;
                    k1.TabStop = false;
                    k1.Click += new System.EventHandler(this.koltuk_Click);
                    k1.Name = "k" + j.ToString() + "00" + (i + 1).ToString();
                    pSalon.Controls.Add(k1);
                }
            }

     
        }

        private void button3_Click(object sender, EventArgs e)
        {
            while (pSalon.Controls.Count > 0)
            {
                pSalon.Controls.RemoveAt(pSalon.Controls.Count - 1);
            }
        }
    }
}
