﻿namespace Sinema
{
    partial class frmSalonSema
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mtbArka = new System.Windows.Forms.MaskedTextBox();
            this.mtbSahneBoyu = new System.Windows.Forms.MaskedTextBox();
            this.btnCiz = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pSalon = new System.Windows.Forms.Panel();
            this.btnUcgen = new System.Windows.Forms.Button();
            this.btnDortgen = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.koltukGenislik = new System.Windows.Forms.MaskedTextBox();
            this.koltukAralik = new System.Windows.Forms.MaskedTextBox();
            this.k2y = new System.Windows.Forms.MaskedTextBox();
            this.koltukBoyu = new System.Windows.Forms.MaskedTextBox();
            this.k3y = new System.Windows.Forms.MaskedTextBox();
            this.k3x = new System.Windows.Forms.MaskedTextBox();
            this.k4y = new System.Windows.Forms.MaskedTextBox();
            this.k4x = new System.Windows.Forms.MaskedTextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.mtbDerinlik = new System.Windows.Forms.MaskedTextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // mtbArka
            // 
            this.mtbArka.Location = new System.Drawing.Point(90, 6);
            this.mtbArka.Mask = "0000";
            this.mtbArka.Name = "mtbArka";
            this.mtbArka.Size = new System.Drawing.Size(47, 20);
            this.mtbArka.TabIndex = 0;
            this.mtbArka.Text = "1200";
            // 
            // mtbSahneBoyu
            // 
            this.mtbSahneBoyu.Location = new System.Drawing.Point(90, 32);
            this.mtbSahneBoyu.Mask = "0000";
            this.mtbSahneBoyu.Name = "mtbSahneBoyu";
            this.mtbSahneBoyu.Size = new System.Drawing.Size(47, 20);
            this.mtbSahneBoyu.TabIndex = 1;
            this.mtbSahneBoyu.Text = "0800";
            // 
            // btnCiz
            // 
            this.btnCiz.Location = new System.Drawing.Point(54, 546);
            this.btnCiz.Name = "btnCiz";
            this.btnCiz.Size = new System.Drawing.Size(47, 23);
            this.btnCiz.TabIndex = 2;
            this.btnCiz.Text = "Göster";
            this.btnCiz.UseVisualStyleBackColor = true;
            this.btnCiz.Click += new System.EventHandler(this.btnCiz_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Arka Duvar";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Sahne Duvarı";
            // 
            // pSalon
            // 
            this.pSalon.AccessibleRole = System.Windows.Forms.AccessibleRole.ScrollBar;
            this.pSalon.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pSalon.AutoScroll = true;
            this.pSalon.AutoSize = true;
            this.pSalon.BackColor = System.Drawing.SystemColors.Info;
            this.pSalon.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pSalon.Location = new System.Drawing.Point(156, 6);
            this.pSalon.Name = "pSalon";
            this.pSalon.Size = new System.Drawing.Size(1096, 754);
            this.pSalon.TabIndex = 5;
            // 
            // btnUcgen
            // 
            this.btnUcgen.Location = new System.Drawing.Point(37, 452);
            this.btnUcgen.Name = "btnUcgen";
            this.btnUcgen.Size = new System.Drawing.Size(47, 23);
            this.btnUcgen.TabIndex = 6;
            this.btnUcgen.Text = "Üçgen";
            this.btnUcgen.UseVisualStyleBackColor = true;
            this.btnUcgen.Click += new System.EventHandler(this.btnUcgen_Click);
            // 
            // btnDortgen
            // 
            this.btnDortgen.Location = new System.Drawing.Point(37, 495);
            this.btnDortgen.Name = "btnDortgen";
            this.btnDortgen.Size = new System.Drawing.Size(47, 23);
            this.btnDortgen.TabIndex = 7;
            this.btnDortgen.Text = "Dörtgen";
            this.btnDortgen.UseVisualStyleBackColor = true;
            this.btnDortgen.Click += new System.EventHandler(this.btnDortgen_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(26, 400);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 8;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // koltukGenislik
            // 
            this.koltukGenislik.Location = new System.Drawing.Point(90, 84);
            this.koltukGenislik.Mask = "0000";
            this.koltukGenislik.Name = "koltukGenislik";
            this.koltukGenislik.Size = new System.Drawing.Size(38, 20);
            this.koltukGenislik.TabIndex = 9;
            this.koltukGenislik.Text = "60";
            // 
            // koltukAralik
            // 
            this.koltukAralik.Location = new System.Drawing.Point(90, 136);
            this.koltukAralik.Mask = "0000";
            this.koltukAralik.Name = "koltukAralik";
            this.koltukAralik.Size = new System.Drawing.Size(38, 20);
            this.koltukAralik.TabIndex = 10;
            this.koltukAralik.Text = "30";
            // 
            // k2y
            // 
            this.k2y.Location = new System.Drawing.Point(103, 183);
            this.k2y.Mask = "0000";
            this.k2y.Name = "k2y";
            this.k2y.Size = new System.Drawing.Size(38, 20);
            this.k2y.TabIndex = 12;
            this.k2y.Text = "50";
            // 
            // koltukBoyu
            // 
            this.koltukBoyu.Location = new System.Drawing.Point(90, 110);
            this.koltukBoyu.Mask = "0000";
            this.koltukBoyu.Name = "koltukBoyu";
            this.koltukBoyu.Size = new System.Drawing.Size(38, 20);
            this.koltukBoyu.TabIndex = 11;
            this.koltukBoyu.Text = "70";
            // 
            // k3y
            // 
            this.k3y.Location = new System.Drawing.Point(26, 253);
            this.k3y.Mask = "0000";
            this.k3y.Name = "k3y";
            this.k3y.Size = new System.Drawing.Size(38, 20);
            this.k3y.TabIndex = 14;
            this.k3y.Text = "50";
            // 
            // k3x
            // 
            this.k3x.Location = new System.Drawing.Point(26, 227);
            this.k3x.Mask = "0000";
            this.k3x.Name = "k3x";
            this.k3x.Size = new System.Drawing.Size(38, 20);
            this.k3x.TabIndex = 13;
            this.k3x.Text = "50";
            // 
            // k4y
            // 
            this.k4y.Location = new System.Drawing.Point(103, 253);
            this.k4y.Mask = "0000";
            this.k4y.Name = "k4y";
            this.k4y.Size = new System.Drawing.Size(38, 20);
            this.k4y.TabIndex = 16;
            this.k4y.Text = "50";
            // 
            // k4x
            // 
            this.k4x.Location = new System.Drawing.Point(103, 227);
            this.k4x.Mask = "0000";
            this.k4x.Name = "k4x";
            this.k4x.Size = new System.Drawing.Size(38, 20);
            this.k4x.TabIndex = 15;
            this.k4x.Text = "50";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(26, 296);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(102, 23);
            this.button2.TabIndex = 17;
            this.button2.Text = "Koltuk Yerleştir";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 61);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 13);
            this.label3.TabIndex = 18;
            this.label3.Text = "Derinlik";
            // 
            // mtbDerinlik
            // 
            this.mtbDerinlik.Location = new System.Drawing.Point(90, 58);
            this.mtbDerinlik.Mask = "0000";
            this.mtbDerinlik.Name = "mtbDerinlik";
            this.mtbDerinlik.Size = new System.Drawing.Size(47, 20);
            this.mtbDerinlik.TabIndex = 19;
            this.mtbDerinlik.Text = "0800";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(26, 338);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(102, 23);
            this.button3.TabIndex = 20;
            this.button3.Text = "Koltukları Sil";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // frmSalonSema
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1264, 761);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.mtbDerinlik);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.k4y);
            this.Controls.Add(this.k4x);
            this.Controls.Add(this.k3y);
            this.Controls.Add(this.k3x);
            this.Controls.Add(this.k2y);
            this.Controls.Add(this.koltukBoyu);
            this.Controls.Add(this.koltukAralik);
            this.Controls.Add(this.koltukGenislik);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnDortgen);
            this.Controls.Add(this.btnUcgen);
            this.Controls.Add(this.pSalon);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnCiz);
            this.Controls.Add(this.mtbSahneBoyu);
            this.Controls.Add(this.mtbArka);
            this.Name = "frmSalonSema";
            this.Text = "frmSalonSema";
            this.Load += new System.EventHandler(this.frmSalonSema_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.frmSalonSema_Paint);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MaskedTextBox mtbArka;
        private System.Windows.Forms.MaskedTextBox mtbSahneBoyu;
        private System.Windows.Forms.Button btnCiz;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel pSalon;
        private System.Windows.Forms.Button btnUcgen;
        private System.Windows.Forms.Button btnDortgen;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.MaskedTextBox koltukGenislik;
        private System.Windows.Forms.MaskedTextBox koltukAralik;
        private System.Windows.Forms.MaskedTextBox k2y;
        private System.Windows.Forms.MaskedTextBox koltukBoyu;
        private System.Windows.Forms.MaskedTextBox k3y;
        private System.Windows.Forms.MaskedTextBox k3x;
        private System.Windows.Forms.MaskedTextBox k4y;
        private System.Windows.Forms.MaskedTextBox k4x;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.MaskedTextBox mtbDerinlik;
        private System.Windows.Forms.Button button3;
    }
}