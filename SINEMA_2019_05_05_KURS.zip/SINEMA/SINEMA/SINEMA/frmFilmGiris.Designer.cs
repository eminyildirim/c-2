﻿namespace Sinema
{
    partial class frmFilmGiris
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dgwFilmListesi = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbFilmAdi = new System.Windows.Forms.TextBox();
            this.mtbFilmSure = new System.Windows.Forms.MaskedTextBox();
            this.dgwSalon = new System.Windows.Forms.DataGridView();
            this.gbVizyon = new System.Windows.Forms.GroupBox();
            this.dtpSalonBos = new System.Windows.Forms.DateTimePicker();
            this.SalonID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SalonAdi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.KoltukSayisi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BosTarih = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label3 = new System.Windows.Forms.Label();
            this.nudHafta = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.dgvSeanslar = new System.Windows.Forms.DataGridView();
            this.Seanslar = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gbVizyonda = new System.Windows.Forms.GroupBox();
            this.dgvSeanslarVizyon = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label5 = new System.Windows.Forms.Label();
            this.nudHaftayayin = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.tbVizyon = new System.Windows.Forms.TextBox();
            this.mcVizyon = new System.Windows.Forms.MonthCalendar();
            this.FilmID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FilmAdi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FilmSure = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Sayi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FilmVizyonTarihi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FilmVizyonSon = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FilmVizyonHafta = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VizyonID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SalonAdi1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gbFilm = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgwFilmListesi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgwSalon)).BeginInit();
            this.gbVizyon.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudHafta)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSeanslar)).BeginInit();
            this.gbVizyonda.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSeanslarVizyon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudHaftayayin)).BeginInit();
            this.gbFilm.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgwFilmListesi
            // 
            this.dgwFilmListesi.AllowUserToAddRows = false;
            this.dgwFilmListesi.AllowUserToDeleteRows = false;
            this.dgwFilmListesi.BackgroundColor = System.Drawing.SystemColors.Info;
            this.dgwFilmListesi.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgwFilmListesi.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.FilmID,
            this.FilmAdi,
            this.FilmSure,
            this.Sayi,
            this.FilmVizyonTarihi,
            this.FilmVizyonSon,
            this.FilmVizyonHafta,
            this.VizyonID,
            this.SalonAdi1});
            this.dgwFilmListesi.Location = new System.Drawing.Point(13, 12);
            this.dgwFilmListesi.MultiSelect = false;
            this.dgwFilmListesi.Name = "dgwFilmListesi";
            this.dgwFilmListesi.ReadOnly = true;
            this.dgwFilmListesi.RowHeadersVisible = false;
            this.dgwFilmListesi.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgwFilmListesi.Size = new System.Drawing.Size(297, 500);
            this.dgwFilmListesi.TabIndex = 0;
            this.dgwFilmListesi.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgwFilmListesi_CellClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Film Adı:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Film Süre:";
            // 
            // tbFilmAdi
            // 
            this.tbFilmAdi.Enabled = false;
            this.tbFilmAdi.Location = new System.Drawing.Point(76, 18);
            this.tbFilmAdi.Name = "tbFilmAdi";
            this.tbFilmAdi.Size = new System.Drawing.Size(256, 20);
            this.tbFilmAdi.TabIndex = 3;
            // 
            // mtbFilmSure
            // 
            this.mtbFilmSure.Enabled = false;
            this.mtbFilmSure.Location = new System.Drawing.Point(76, 44);
            this.mtbFilmSure.Mask = "999";
            this.mtbFilmSure.Name = "mtbFilmSure";
            this.mtbFilmSure.Size = new System.Drawing.Size(38, 20);
            this.mtbFilmSure.TabIndex = 4;
            // 
            // dgwSalon
            // 
            this.dgwSalon.AllowUserToAddRows = false;
            this.dgwSalon.AllowUserToDeleteRows = false;
            this.dgwSalon.BackgroundColor = System.Drawing.SystemColors.Info;
            this.dgwSalon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgwSalon.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SalonID,
            this.SalonAdi,
            this.KoltukSayisi,
            this.BosTarih});
            this.dgwSalon.Location = new System.Drawing.Point(6, 19);
            this.dgwSalon.Name = "dgwSalon";
            this.dgwSalon.ReadOnly = true;
            this.dgwSalon.RowHeadersVisible = false;
            this.dgwSalon.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgwSalon.Size = new System.Drawing.Size(361, 399);
            this.dgwSalon.TabIndex = 5;
            this.dgwSalon.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgwSalon_CellClick);
            // 
            // gbVizyon
            // 
            this.gbVizyon.Controls.Add(this.dgvSeanslar);
            this.gbVizyon.Controls.Add(this.label4);
            this.gbVizyon.Controls.Add(this.nudHafta);
            this.gbVizyon.Controls.Add(this.label3);
            this.gbVizyon.Controls.Add(this.dtpSalonBos);
            this.gbVizyon.Controls.Add(this.dgwSalon);
            this.gbVizyon.Location = new System.Drawing.Point(12, 70);
            this.gbVizyon.Name = "gbVizyon";
            this.gbVizyon.Size = new System.Drawing.Size(553, 424);
            this.gbVizyon.TabIndex = 6;
            this.gbVizyon.TabStop = false;
            this.gbVizyon.Text = "[ Vizyon İşlemleri ]";
            // 
            // dtpSalonBos
            // 
            this.dtpSalonBos.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpSalonBos.Location = new System.Drawing.Point(385, 42);
            this.dtpSalonBos.Name = "dtpSalonBos";
            this.dtpSalonBos.Size = new System.Drawing.Size(75, 20);
            this.dtpSalonBos.TabIndex = 6;
            this.dtpSalonBos.Value = new System.DateTime(2019, 5, 5, 0, 0, 0, 0);
            // 
            // SalonID
            // 
            this.SalonID.DataPropertyName = "SalonID";
            this.SalonID.HeaderText = "ID";
            this.SalonID.Name = "SalonID";
            this.SalonID.ReadOnly = true;
            this.SalonID.Visible = false;
            // 
            // SalonAdi
            // 
            this.SalonAdi.DataPropertyName = "SalonAdi";
            this.SalonAdi.HeaderText = "Salon Adı";
            this.SalonAdi.Name = "SalonAdi";
            this.SalonAdi.ReadOnly = true;
            this.SalonAdi.Width = 200;
            // 
            // KoltukSayisi
            // 
            this.KoltukSayisi.DataPropertyName = "KoltukSayisi";
            this.KoltukSayisi.HeaderText = "Koltuk Sayısı";
            this.KoltukSayisi.Name = "KoltukSayisi";
            this.KoltukSayisi.ReadOnly = true;
            this.KoltukSayisi.Width = 50;
            // 
            // BosTarih
            // 
            this.BosTarih.DataPropertyName = "BosTarih";
            dataGridViewCellStyle13.Format = "dd.MM.yyyy";
            dataGridViewCellStyle13.NullValue = null;
            this.BosTarih.DefaultCellStyle = dataGridViewCellStyle13;
            this.BosTarih.HeaderText = "Boş Tarih";
            this.BosTarih.Name = "BosTarih";
            this.BosTarih.ReadOnly = true;
            this.BosTarih.Width = 80;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(385, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Vizyon Tarihi";
            // 
            // nudHafta
            // 
            this.nudHafta.AllowDrop = true;
            this.nudHafta.AutoSize = true;
            this.nudHafta.Location = new System.Drawing.Point(387, 71);
            this.nudHafta.Maximum = new decimal(new int[] {
            52,
            0,
            0,
            0});
            this.nudHafta.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudHafta.Name = "nudHafta";
            this.nudHafta.Size = new System.Drawing.Size(45, 20);
            this.nudHafta.TabIndex = 8;
            this.nudHafta.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nudHafta.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(436, 74);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(33, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Hafta";
            // 
            // dgvSeanslar
            // 
            this.dgvSeanslar.AllowUserToAddRows = false;
            this.dgvSeanslar.AllowUserToDeleteRows = false;
            this.dgvSeanslar.AllowUserToResizeRows = false;
            this.dgvSeanslar.BackgroundColor = System.Drawing.SystemColors.Info;
            this.dgvSeanslar.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvSeanslar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvSeanslar.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Seanslar});
            this.dgvSeanslar.EnableHeadersVisualStyles = false;
            this.dgvSeanslar.Location = new System.Drawing.Point(475, 19);
            this.dgvSeanslar.MultiSelect = false;
            this.dgvSeanslar.Name = "dgvSeanslar";
            this.dgvSeanslar.ReadOnly = true;
            this.dgvSeanslar.RowHeadersVisible = false;
            this.dgvSeanslar.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvSeanslar.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgvSeanslar.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSeanslar.Size = new System.Drawing.Size(65, 399);
            this.dgvSeanslar.TabIndex = 10;
            // 
            // Seanslar
            // 
            this.Seanslar.DataPropertyName = "Seanslar";
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Seanslar.DefaultCellStyle = dataGridViewCellStyle14;
            this.Seanslar.HeaderText = "Seanslar";
            this.Seanslar.Name = "Seanslar";
            this.Seanslar.ReadOnly = true;
            this.Seanslar.Width = 60;
            // 
            // gbVizyonda
            // 
            this.gbVizyonda.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.gbVizyonda.Controls.Add(this.mcVizyon);
            this.gbVizyonda.Controls.Add(this.dgvSeanslarVizyon);
            this.gbVizyonda.Controls.Add(this.label5);
            this.gbVizyonda.Controls.Add(this.nudHaftayayin);
            this.gbVizyonda.Controls.Add(this.label6);
            this.gbVizyonda.Controls.Add(this.dateTimePicker1);
            this.gbVizyonda.Location = new System.Drawing.Point(590, 70);
            this.gbVizyonda.Name = "gbVizyonda";
            this.gbVizyonda.Size = new System.Drawing.Size(687, 418);
            this.gbVizyonda.TabIndex = 7;
            this.gbVizyonda.TabStop = false;
            this.gbVizyonda.Text = "[ Vizyonda ]";
            // 
            // dgvSeanslarVizyon
            // 
            this.dgvSeanslarVizyon.AllowUserToAddRows = false;
            this.dgvSeanslarVizyon.AllowUserToDeleteRows = false;
            this.dgvSeanslarVizyon.AllowUserToResizeRows = false;
            this.dgvSeanslarVizyon.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvSeanslarVizyon.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvSeanslarVizyon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvSeanslarVizyon.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1});
            this.dgvSeanslarVizyon.EnableHeadersVisualStyles = false;
            this.dgvSeanslarVizyon.Location = new System.Drawing.Point(528, 19);
            this.dgvSeanslarVizyon.MultiSelect = false;
            this.dgvSeanslarVizyon.Name = "dgvSeanslarVizyon";
            this.dgvSeanslarVizyon.ReadOnly = true;
            this.dgvSeanslarVizyon.RowHeadersVisible = false;
            this.dgvSeanslarVizyon.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvSeanslarVizyon.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgvSeanslarVizyon.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSeanslarVizyon.Size = new System.Drawing.Size(63, 251);
            this.dgvSeanslarVizyon.TabIndex = 10;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Seanslar";
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle15;
            this.dataGridViewTextBoxColumn1.HeaderText = "Seanslar";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 60;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(274, 26);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(33, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Hafta";
            // 
            // nudHaftayayin
            // 
            this.nudHaftayayin.AllowDrop = true;
            this.nudHaftayayin.AutoSize = true;
            this.nudHaftayayin.Enabled = false;
            this.nudHaftayayin.Location = new System.Drawing.Point(225, 23);
            this.nudHaftayayin.Maximum = new decimal(new int[] {
            52,
            0,
            0,
            0});
            this.nudHaftayayin.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudHaftayayin.Name = "nudHaftayayin";
            this.nudHaftayayin.Size = new System.Drawing.Size(45, 20);
            this.nudHaftayayin.TabIndex = 8;
            this.nudHaftayayin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nudHaftayayin.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 25);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(109, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "Vizyon başlama Tarihi";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Enabled = false;
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(127, 23);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(75, 20);
            this.dateTimePicker1.TabIndex = 6;
            this.dateTimePicker1.Value = new System.DateTime(2019, 5, 5, 0, 0, 0, 0);
            // 
            // tbVizyon
            // 
            this.tbVizyon.Location = new System.Drawing.Point(144, 43);
            this.tbVizyon.Name = "tbVizyon";
            this.tbVizyon.Size = new System.Drawing.Size(100, 20);
            this.tbVizyon.TabIndex = 8;
            // 
            // mcVizyon
            // 
            this.mcVizyon.CalendarDimensions = new System.Drawing.Size(2, 1);
            this.mcVizyon.Location = new System.Drawing.Point(12, 55);
            this.mcVizyon.MaxDate = new System.DateTime(2019, 5, 30, 0, 0, 0, 0);
            this.mcVizyon.MinDate = new System.DateTime(2019, 5, 5, 0, 0, 0, 0);
            this.mcVizyon.Name = "mcVizyon";
            this.mcVizyon.TabIndex = 11;
            // 
            // FilmID
            // 
            this.FilmID.DataPropertyName = "FilmID";
            this.FilmID.HeaderText = "FilmID";
            this.FilmID.Name = "FilmID";
            this.FilmID.ReadOnly = true;
            this.FilmID.Visible = false;
            // 
            // FilmAdi
            // 
            this.FilmAdi.DataPropertyName = "FilmAdi";
            this.FilmAdi.HeaderText = "Film Adı";
            this.FilmAdi.Name = "FilmAdi";
            this.FilmAdi.ReadOnly = true;
            this.FilmAdi.Width = 200;
            // 
            // FilmSure
            // 
            this.FilmSure.DataPropertyName = "FilmSure";
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle16.Format = "N0";
            dataGridViewCellStyle16.NullValue = null;
            this.FilmSure.DefaultCellStyle = dataGridViewCellStyle16;
            this.FilmSure.HeaderText = "Film Süresi (dk)";
            this.FilmSure.Name = "FilmSure";
            this.FilmSure.ReadOnly = true;
            this.FilmSure.Width = 50;
            // 
            // Sayi
            // 
            this.Sayi.DataPropertyName = "Sayi";
            this.Sayi.HeaderText = "Sayi";
            this.Sayi.Name = "Sayi";
            this.Sayi.ReadOnly = true;
            this.Sayi.Visible = false;
            // 
            // FilmVizyonTarihi
            // 
            this.FilmVizyonTarihi.DataPropertyName = "FilmVizyonTarihi";
            this.FilmVizyonTarihi.HeaderText = "FilmVizyonTarihi";
            this.FilmVizyonTarihi.Name = "FilmVizyonTarihi";
            this.FilmVizyonTarihi.ReadOnly = true;
            this.FilmVizyonTarihi.Visible = false;
            // 
            // FilmVizyonSon
            // 
            this.FilmVizyonSon.DataPropertyName = "FilmVizyonSon";
            this.FilmVizyonSon.HeaderText = "FilmVizyonSon";
            this.FilmVizyonSon.Name = "FilmVizyonSon";
            this.FilmVizyonSon.ReadOnly = true;
            this.FilmVizyonSon.Visible = false;
            // 
            // FilmVizyonHafta
            // 
            this.FilmVizyonHafta.DataPropertyName = "FilmVizyonHafta";
            this.FilmVizyonHafta.HeaderText = "FilmVizyonHafta";
            this.FilmVizyonHafta.Name = "FilmVizyonHafta";
            this.FilmVizyonHafta.ReadOnly = true;
            this.FilmVizyonHafta.Visible = false;
            // 
            // VizyonID
            // 
            this.VizyonID.DataPropertyName = "VizyonID";
            this.VizyonID.HeaderText = "VizyonID";
            this.VizyonID.Name = "VizyonID";
            this.VizyonID.ReadOnly = true;
            this.VizyonID.Visible = false;
            // 
            // SalonAdi1
            // 
            this.SalonAdi1.DataPropertyName = "SalonAdi";
            this.SalonAdi1.HeaderText = "SalonAdi";
            this.SalonAdi1.Name = "SalonAdi1";
            this.SalonAdi1.ReadOnly = true;
            this.SalonAdi1.Visible = false;
            // 
            // gbFilm
            // 
            this.gbFilm.Controls.Add(this.tbVizyon);
            this.gbFilm.Controls.Add(this.gbVizyonda);
            this.gbFilm.Controls.Add(this.label1);
            this.gbFilm.Controls.Add(this.gbVizyon);
            this.gbFilm.Controls.Add(this.label2);
            this.gbFilm.Controls.Add(this.tbFilmAdi);
            this.gbFilm.Controls.Add(this.mtbFilmSure);
            this.gbFilm.Location = new System.Drawing.Point(330, 12);
            this.gbFilm.Name = "gbFilm";
            this.gbFilm.Size = new System.Drawing.Size(706, 500);
            this.gbFilm.TabIndex = 9;
            this.gbFilm.TabStop = false;
            // 
            // frmFilmGiris
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1054, 527);
            this.Controls.Add(this.gbFilm);
            this.Controls.Add(this.dgwFilmListesi);
            this.Name = "frmFilmGiris";
            this.Text = "Film Girişi ve Vizyon İşlemleri";
            this.Load += new System.EventHandler(this.frmFilmGiris_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgwFilmListesi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgwSalon)).EndInit();
            this.gbVizyon.ResumeLayout(false);
            this.gbVizyon.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudHafta)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSeanslar)).EndInit();
            this.gbVizyonda.ResumeLayout(false);
            this.gbVizyonda.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSeanslarVizyon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudHaftayayin)).EndInit();
            this.gbFilm.ResumeLayout(false);
            this.gbFilm.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgwFilmListesi;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbFilmAdi;
        private System.Windows.Forms.MaskedTextBox mtbFilmSure;
        private System.Windows.Forms.DataGridView dgwSalon;
        private System.Windows.Forms.GroupBox gbVizyon;
        private System.Windows.Forms.DateTimePicker dtpSalonBos;
        private System.Windows.Forms.DataGridViewTextBoxColumn SalonID;
        private System.Windows.Forms.DataGridViewTextBoxColumn SalonAdi;
        private System.Windows.Forms.DataGridViewTextBoxColumn KoltukSayisi;
        private System.Windows.Forms.DataGridViewTextBoxColumn BosTarih;
        private System.Windows.Forms.NumericUpDown nudHafta;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dgvSeanslar;
        private System.Windows.Forms.DataGridViewTextBoxColumn Seanslar;
        private System.Windows.Forms.GroupBox gbVizyonda;
        private System.Windows.Forms.DataGridView dgvSeanslarVizyon;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown nudHaftayayin;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox tbVizyon;
        private System.Windows.Forms.MonthCalendar mcVizyon;
        private System.Windows.Forms.DataGridViewTextBoxColumn FilmID;
        private System.Windows.Forms.DataGridViewTextBoxColumn FilmAdi;
        private System.Windows.Forms.DataGridViewTextBoxColumn FilmSure;
        private System.Windows.Forms.DataGridViewTextBoxColumn Sayi;
        private System.Windows.Forms.DataGridViewTextBoxColumn FilmVizyonTarihi;
        private System.Windows.Forms.DataGridViewTextBoxColumn FilmVizyonSon;
        private System.Windows.Forms.DataGridViewTextBoxColumn FilmVizyonHafta;
        private System.Windows.Forms.DataGridViewTextBoxColumn VizyonID;
        private System.Windows.Forms.DataGridViewTextBoxColumn SalonAdi1;
        private System.Windows.Forms.GroupBox gbFilm;
    }
}