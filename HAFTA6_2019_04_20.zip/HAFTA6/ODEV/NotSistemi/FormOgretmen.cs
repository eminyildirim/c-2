﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NotSistemi
{
    public partial class FormOgretmen : Form
    {
        public int ID { get; set; }
        public string user { get; set; }
        public string username { get; set; }

        private SqlDbConEy cn;
        public FormOgretmen()
        {
            InitializeComponent();
            cn = new SqlDbConEy();
        }

        private void FormOgretmen_Load(object sender, EventArgs e)
        {
            // this.ogretmenOgrenciTableAdapter.Fill(this.ogrenciKayitDBDataSet.OgretmenOgrenci);
            cn = new SqlDbConEy();
            this.Text = username;

            OgrenciListesi();
            KimeListesi();
            pOgrenciButon.Visible = false;
            btnVazgec.PerformClick();
            btnVazgec_Click(sender, e);


        }
        void goster(int rowIndex)
        {

            DataGridViewRow row = dgvOgrenciler.Rows[rowIndex];
            tbONo.Text = row.Cells[1].Value.ToString();
            tbOAd.Text = row.Cells[10].Value.ToString();
            tbOSoyad.Text = row.Cells[11].Value.ToString();

        }
        private void tcOgretmen_TabIndexChanged(object sender, EventArgs e)
        {

        }

        private void tcOgretmen_SelectedIndexChanged(object sender, EventArgs e)
        {

            switch (tcOgretmen.SelectedIndex)
            {
                case 0: { OgrenciListesi(); break; }
                case 1:
                    {
                        MesajListesi(ID);
                        KimeListesi();
                        break;
                    }
                case 2: { break; }
                default:
                    break;
            }
        }

        private void btnKimeEkle_Click(object sender, EventArgs e)
        {
            lbKime.Items.Add(cbKime.Text);
        }
        void OgrenciListesi()
        {
            String s = "";
            s = "SELECT O.OID, O.ONo, O.OAd + ' ' + O.OSoyad AS AdSoyad, N.ID, N.Not1, N.Not2, N.Not3, N.PNotu,N.Ortalama, CASE N.Durumu WHEN 0 THEN 'Kaldı' WHEN 1 THEN 'Geçti' ELSE '' END AS Durumu,O.OAd,O.OSoyad FROM dbo.OgretmenOgrenci AS O INNER JOIN dbo.Notlar AS N ON O.OID = N.OID WHERE (O.OTipi = 2) ORDER BY ONo";
            cn.SqlDbQuery(s);
            dgvOgrenciler.DataSource = cn.QueryEx();
        }
        void MesajListesi(int kimeID)
        {
            cn.SqlDbQuery("SELECT O.OAd+' '+O.OSoyad AS AdSoyad, M.MBaslik As Konu, M.MIcerik AS Mesaj FROM dbo.Mesajlar AS M INNER JOIN dbo.OgretmenOgrenci AS O ON M.MGonderenID = O.OID WHERE M.MAliciID=" + ID.ToString());
            dgvMesajlar.DataSource = cn.QueryEx();
        }
        void KimeListesi()
        {
            cn.SqlDbQuery("SELECT O.ONo+'-'+ O.OAd + ' ' + O.OSoyad AS AdSoyad FROM dbo.OgretmenOgrenci AS O ORDER BY O.OTipi,ONo");
            cbKime.Items.Clear();
            cbKime.Items.Add("{Tümü}");
            foreach (DataRow dr in cn.QueryEx().Rows)
            {
                cbKime.Items.Add(dr[0].ToString());
            }
            cbKime.SelectedIndex = 0;
        }
        void DuyuruListesi()
        {

        }

        private void btnOgrenciEkleAc_Click(object sender, EventArgs e)
        {
            int i = 1 - Convert.ToInt16(gbOgrenciKayit.Visible);

            gbOgrenciKayit.Visible = Convert.ToBoolean(i);
            pOgrenciButon.Visible = false;

            tbONo.Text = "";
            tbONo.Enabled = true;
            tbOAd.Text = "";
            tbOSoyad.Text = "";
            btnNumaraVer.Enabled = true;
            dgvOgrenciler.Enabled = false;
            btnKayit.Tag = "insert";
        }

        private void btnKayit_Click(object sender, EventArgs e)
        {
            if (tbONo.Text != "" && tbOAd.Text != "" && tbOSoyad.Text != "")
            {
                if (btnKayit.Tag.Equals("insert"))
                {
                    cn.SqlDbQuery("INSERT INTO dbo.OgretmenOgrenci (OTipi,ONo,OAd,OSoyad,OSifre,OResim) VALUES (2,@ONo,@OAd,@OSoyad,'1234','')");
                    cn.cmd.Parameters.AddWithValue("@ONo", tbONo.Text);
                    cn.cmd.Parameters.AddWithValue("@OAd", tbOAd.Text);
                    cn.cmd.Parameters.AddWithValue("@OSoyad", tbOSoyad.Text);
                    cn.NonQueryEx();
                    OgrenciListesi();
                    int r = dgvOgrenciler.RowCount-1;
                    dgvOgrenciler.ClearSelection();
                    dgvOgrenciler.Rows[r].Selected = true;
                    dgvOgrenciler.CurrentCell = dgvOgrenciler.Rows[r].Cells[1];

                }
                else
                {
                    int r = dgvOgrenciler.CurrentRow.Index;
                    cn.SqlDbQuery("UPDATE dbo.OgretmenOgrenci SET OAd=@OAd,OSoyad=@OSoyad WHERE (ONo=@ONo AND OTipi = 2)");
                    cn.cmd.Parameters.AddWithValue("@OAd", tbOAd.Text);
                    cn.cmd.Parameters.AddWithValue("@OSoyad", tbOSoyad.Text);
                    cn.cmd.Parameters.AddWithValue("@ONo", tbONo.Text);
                    //  cn.cmd.Parameters.AddWithValue("@p4", Decimal.Parse(fiyattext));
                    cn.NonQueryEx();
                    OgrenciListesi();
                    // dgvOgrenciler.Enabled = true;
                    dgvOgrenciler.ClearSelection();
                    dgvOgrenciler.Rows[r].Selected = true;
                    dgvOgrenciler.CurrentCell = dgvOgrenciler.Rows[r].Cells[1];

                }
                btnVazgec.PerformClick();
            }
            else
            {
                MessageBox.Show("Bilgileriniz Hatalı!");
                tbOAd.Focus();
            }

        }

        private void btnVazgec_Click(object sender, EventArgs e)
        {
            gbOgrenciKayit.Visible = false;
            pOgrenciButon.Top = gbOgrenciKayit.Top;
            tbONo.Enabled = true;
            pOgrenciButon.Visible = true;
            dgvOgrenciler.Enabled = true;
        }

        private void FormOgretmen_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void btnOgrenciDegistir_Click(object sender, EventArgs e)
        {
            gbOgrenciKayit.Visible = true;
            pOgrenciButon.Visible = false;
            if (dgvOgrenciler.RowCount > 0)
            {
                if (dgvOgrenciler.CurrentRow.Index > -1)
                {
                    goster(dgvOgrenciler.CurrentRow.Index);
                    tbONo.Enabled = false;
                    btnNumaraVer.Enabled = false;
                    dgvOgrenciler.Enabled = false;
                    btnKayit.Tag = "update";
                }
            }
        }

        private void dgvOgrenciler_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int rowIndex = e.RowIndex;
            goster(rowIndex);
        }

        private void btnOgrenciSil_Click(object sender, EventArgs e)
        {
            if (dgvOgrenciler.RowCount > 0)
            {
                gbOgrenciKayit.Visible = true;
                pOgrenciButon.Visible = false;
                if (dgvOgrenciler.CurrentRow.Index > -1)
                {
                    goster(dgvOgrenciler.CurrentRow.Index);
                    tbONo.Enabled = false;
                    btnNumaraVer.Enabled = false;
                    dgvOgrenciler.Enabled = false;
                }
            }
        }

        private void btnNumaraVer_Click(object sender, EventArgs e)
        {
            tbONo.Text = "0001";
            cn.SqlDbQuery("SELECT TOP 1 REPLACE(STR(ONo+1,LEN(ONo)),' ','0') FROM dbo.OgretmenOgrenci WHERE OTipi = 2 AND ISNUMERIC(ONo)=1 ORDER BY ONo DESC");
            foreach (DataRow dr in cn.QueryEx().Rows)
            {
                tbONo.Text = dr[0].ToString();
            }
            tbOAd.Focus();
        }

        private void btnNotGir_Click(object sender, EventArgs e)
        {
            for (int i = 4; i < 8; i++)
            {
                dgvOgrenciler.Columns[i].ReadOnly = true;
            }
            if (cbNot1.Checked)
            {
                dgvOgrenciler.Columns[4].ReadOnly = false;
                btnNotKayit.Visible = true;
            }
            if (cbNot2.Checked)
            {
                dgvOgrenciler.Columns[5].ReadOnly = false;
                btnNotKayit.Visible = true;
            }
            if (cbNot3.Checked)
            {
                dgvOgrenciler.Columns[6].ReadOnly = false;
                btnNotKayit.Visible = true;
            }
            if (cbNotProje.Checked)
            {
                dgvOgrenciler.Columns[7].ReadOnly = false;
                btnNotKayit.Visible = true;
            }
            btnNotVazgec.Visible = btnNotKayit.Visible;
            btnNotGir.Visible = Convert.ToBoolean(1 - Convert.ToInt16(btnNotKayit.Visible));
        }

        private void btnNotKayit_Click(object sender, EventArgs e)
        {
            Boolean kontrol = true;
            String kontroltxt = "";
            foreach (DataGridViewRow row in dgvOgrenciler.Rows)
            {
                try
                {
                    for (int i = 4; i < 8; i++)
                    {
                        Decimal d = Convert.ToDecimal(row.Cells[i].Value.ToString());
                        if (d > 100 || d < 0)
                        {
                            kontroltxt = kontroltxt + row.Cells[1].Value.ToString() + " Nolu Öğrenci Not hatası" + (char)10;
                            kontrol = false;
                        }
                    }

                }
                catch (Exception)
                {

                    kontroltxt = kontroltxt + row.Cells[1].Value.ToString() + " Nolu Öğrenci Not hatası" + (char)10;
                    kontrol = false;
                }

            }
           
            if (kontrol)
            {
                String updatesql = "UPDATE dbo.Notlar SET";
                String x = "";
                if (cbNot1.Checked)
                {
                    updatesql = updatesql + x + " Not1=@Not1";
                    x = ",";
                }
                if (cbNot2.Checked)
                {
                    updatesql = updatesql + x + " Not2=@Not2";
                    x = ",";
                }
                if (cbNot3.Checked)
                {
                    updatesql = updatesql + x + " Not3=@Not3";
                    x = ",";
                }
                if (cbNotProje.Checked)
                {
                    updatesql = updatesql + x + " PNotu=@PNotu";

                }
                updatesql = updatesql + " WHERE ID=@ID";

                foreach (DataGridViewRow row in dgvOgrenciler.Rows)
                {
                    String usql = updatesql.Replace("@ID", row.Cells[3].Value.ToString());
                    usql = usql.Replace("@Not1", row.Cells[4].Value.ToString().Replace(",", "."));
                    usql = usql.Replace("@Not2", row.Cells[5].Value.ToString().Replace(",", "."));
                    usql = usql.Replace("@Not3", row.Cells[6].Value.ToString().Replace(",", "."));
                    usql = usql.Replace("@PNotu", row.Cells[7].Value.ToString().Replace(",", "."));
                    cn.SqlDbQuery(usql);
                    cn.NonQueryEx();
                }
                btnNotVazgec.PerformClick();
            }
            else
            {
                MessageBox.Show(kontroltxt);
            }
        }

        private void btnNotVazgec_Click(object sender, EventArgs e)
        {
            btnNotKayit.Visible = false;
            btnNotGir.Visible = true;
            btnNotVazgec.Visible = false;
            cbNot1.Checked = false;
            cbNot2.Checked = false;
            cbNot3.Checked = false;
            cbNotProje.Checked = false;
            for (int i = 4; i < 8; i++)
            {
                dgvOgrenciler.Columns[i].ReadOnly = true;
            }
            OgrenciListesi();


        }
    }
}
