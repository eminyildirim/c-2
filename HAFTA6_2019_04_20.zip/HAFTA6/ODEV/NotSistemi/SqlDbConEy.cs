﻿
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data;

namespace NotSistemi
{
    public class SqlDbConEy
    {
        private SqlConnection _cn;
        public SqlCommand cmd;
        private SqlDataAdapter _da;
        private SqlDataReader _dr;
        private DataTable _dt;
        public SqlDbConEy()
        {
            // _cn = new SqlConnection(@"Data Source=LAB02-12;Initial Catalog=Rehber;Integrated Security=True");
            _cn = new SqlConnection(@"Data Source=LAB02-12;Initial Catalog=OgrenciKayitDB;Integrated Security=True");
            _cn.Open();
        }
        public void SqlDbQuery(string qtext)
        {
            cmd = new SqlCommand(qtext, _cn);
        }
        public DataTable QueryEx()
        {
            _da = new SqlDataAdapter(cmd);
            _dt = new DataTable();
            _da.Fill(_dt);
            return _dt;
        }
        public void NonQueryEx()
        {
            cmd.ExecuteNonQuery();
        }
    }
}
