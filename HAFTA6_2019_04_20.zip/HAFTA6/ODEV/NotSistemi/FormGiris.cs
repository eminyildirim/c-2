﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NotSistemi
{
    public partial class frmGiris : Form
    {
        private SqlDbConEy cn;
        public frmGiris()
        {
            InitializeComponent();
        }

        private void frmGiris_Load(object sender, EventArgs e)
        {
            cbKim.SelectedIndex = 0;
        }

        private void cbKim_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.Text= cbKim.Text + " Girişi";
            //labelNo.Text = cbKim.Text + " No:";
        }

        private void btnGiris_Click(object sender, EventArgs e)
        {
            cn = new SqlDbConEy();
            if (cbKim.SelectedIndex==0)
            {
                cn.SqlDbQuery("SELECT * FROM dbo.OgretmenOgrenci WHERE ONo=@ONo AND OSifre=@OSifre");
            }
            else
            {
                cn.SqlDbQuery("SELECT * FROM dbo.OgretmenOgrenci WHERE ONo=@ONo AND OSifre=@OSifre");
            }
            cn.cmd.Parameters.Add("@ONo", tbuser.Text.ToString());
            cn.cmd.Parameters.Add("@OSifre", tbsifre.Text.ToString());
            using (var reader = cn.cmd.ExecuteReader())
            {
                if (reader.Read()) // Don't assume we have any rows.
                {
                    int ord = reader.GetOrdinal("ONo");
   
                    FormOgretmen frm = new FormOgretmen();
                    frm.ID = reader.GetInt32(0);
                    frm.user = reader.GetString(2);
                    frm.username = reader.GetString(reader.GetOrdinal("OAd"))+" "+ reader.GetString(reader.GetOrdinal("OSoyad"));
                    this.Hide();
                    frm.Show();
                }
                else                MessageBox.Show("Bilgileriniz Hatalı");
            }
            /*
            cn.NonQueryEx();
            if (cn.QueryEx().Rows.Count > 0)
            {
                // cn.ID = cn.QueryEx().Columns[0].ToString();
                cn.user= cn.QueryEx().Rows;
                FormOgretmen frm = new FormOgretmen();
                this.Hide();
                frm.Show();
            }
            else
            {
                MessageBox.Show("Bilgileriniz Hatalı");
            }
            */
        }
    }
}
