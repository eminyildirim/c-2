﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Ogrenci_Not_Kayit
{
    public partial class Ogretmen : Form
    {
        public int ID { get; set; }
        public string numara { get; set; }
        public string adsoyad { get; set; }
        SqlBaglantisi bgl = new SqlBaglantisi();
        public Ogretmen()
        {
            InitializeComponent();
        }

        private void Ogretmen_Load(object sender, EventArgs e)
        {
            ladsoyad.Text = adsoyad;
            lnumara.Text = numara;
            Listele();
            Goster(0);
            NotListele();
           
        }
        void Listele()
        {
            SqlCommand cmd = new SqlCommand("Select * from dbo.TblOgrenci order by Numara", bgl.baglanti());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }
        void NotListele()
        {
            // SqlCommand cmd = new SqlCommand("Select * from dbo.TblNotlar order by OgrnciID", bgl.baglanti());
            SqlCommand cmd = new SqlCommand("Select * FROM dbo.TblNotlar WHERE OgrnciID = (Select ID FROM dbo.TblOgrenci WHERE Numara = @Numara)", bgl.baglanti());
            cmd.Parameters.AddWithValue("@Numara", mtbNumara.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView2.DataSource = dt;
            dataGridView2.Columns[0].Visible = false;
            dataGridView2.Columns[1].Width = 45;
            dataGridView2.Columns[2].Width = 45;
            dataGridView2.Columns[3].Width = 45;
            dataGridView2.Columns[4].Width = 45;
            dataGridView2.Columns[5].Width = 45;

            dataGridView2.Columns[1].HeaderText = "Sınav (1)";
            dataGridView2.Columns[2].HeaderText = "Sınav (2)";
            dataGridView2.Columns[3].HeaderText = "Sınav (3)";
            dataGridView2.Columns[4].HeaderText = "Proje (Notu)";

            for (int i = 1; i < 5; i++)
            {
                dataGridView2.Columns[i].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            }
        }
            
        void Goster(int r)
        {
            tbAd.Text = dataGridView1.Rows[r].Cells[1].Value.ToString();
            tbSoyad.Text = dataGridView1.Rows[r].Cells[2].Value.ToString();
            mtbNumara.Text = dataGridView1.Rows[r].Cells[3].Value.ToString();
            tbSifre.Text = dataGridView1.Rows[r].Cells[4].Value.ToString();
            lFotograf.Text = dataGridView1.Rows[r].Cells[5].Value.ToString();
            pbResim.ImageLocation = lFotograf.Text;

            SqlCommand cmd = new SqlCommand("Select * FROM dbo.TblNotlar WHERE OgrnciID = (Select ID FROM dbo.TblOgrenci WHERE Numara = @Numara)", bgl.baglanti());
            cmd.Parameters.AddWithValue("@Numara", mtbNumara.Text);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
          
                tbSinav1.Text = dr.GetByte(1).ToString().ToString();
                tbSinav2.Text = dr.GetByte(2).ToString().ToString();
                tbSinav3.Text = dr.GetByte(3).ToString().ToString();
                tbProje.Text = dr.GetByte(4).ToString().ToString();

            }
        }
        private void btnFotoSec_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Resim Dosyası|*.jpg;*.png;*.jpeg";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                lFotograf.Text = ofd.FileName;

            }
            ofd = null;
        }

        private void btnKayit_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO dbo.TblOgrenci (Ad,Soyad,Numara,Sifre,Fotograf) VALUES (@Ad,@Soyad,@Numara,@Sifre,@Fotograf)", bgl.baglanti());
            cmd.Parameters.AddWithValue("@Ad", tbAd.Text);
            cmd.Parameters.AddWithValue("@Soyad", tbSoyad.Text);
            cmd.Parameters.AddWithValue("@Numara", mtbNumara.Text);
            cmd.Parameters.AddWithValue("@Sifre", tbSifre.Text);
            cmd.Parameters.AddWithValue("@Fotograf", lFotograf.Text);
            cmd.ExecuteNonQuery();
            btnGuncelle_Click(sender, e);
            Listele();

        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("UPDATE dbo.TblNotlar SET Sinav1 = @Sinav1,Sinav2 = @Sinav2,Sinav3 = @Sinav3,Proje = @Proje WHERE OgrnciID = (Select ID FROM [dbo].[TblOgrenci] WHERE Numara = @Numara)", bgl.baglanti());
            cmd.Parameters.AddWithValue("@Sinav1", tbSinav1.Text);
            cmd.Parameters.AddWithValue("@Sinav2", tbSinav2.Text);
            cmd.Parameters.AddWithValue("@Sinav3", tbSinav3.Text);
            cmd.Parameters.AddWithValue("@Proje", tbProje.Text);
            cmd.Parameters.AddWithValue("@Numara", mtbNumara.Text);
            cmd.ExecuteNonQuery();
            Listele();
            NotListele();
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("DELETE dbo.TblOgrenci WHERE Numara = @Numara", bgl.baglanti());
            cmd.Parameters.AddWithValue("@Numara", mtbNumara.Text);

            cmd.ExecuteNonQuery();
            Listele();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            Goster(e.RowIndex);
            NotListele();
        }
    }
}
