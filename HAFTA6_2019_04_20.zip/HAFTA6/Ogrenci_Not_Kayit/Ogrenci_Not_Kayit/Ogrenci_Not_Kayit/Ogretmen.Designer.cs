﻿namespace Ogrenci_Not_Kayit
{
    partial class Ogretmen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lnumara = new System.Windows.Forms.Label();
            this.ladsoyad = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pbResim = new System.Windows.Forms.PictureBox();
            this.btnFotoSec = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.tbOrtalama = new System.Windows.Forms.TextBox();
            this.tbProje = new System.Windows.Forms.TextBox();
            this.tbSinav3 = new System.Windows.Forms.TextBox();
            this.tbSinav2 = new System.Windows.Forms.TextBox();
            this.tbSinav1 = new System.Windows.Forms.TextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button5 = new System.Windows.Forms.Button();
            this.btnGuncelle = new System.Windows.Forms.Button();
            this.btnSil = new System.Windows.Forms.Button();
            this.btnKayit = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel6 = new System.Windows.Forms.Panel();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.panel7 = new System.Windows.Forms.Panel();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.mtbNumara = new System.Windows.Forms.MaskedTextBox();
            this.tbAd = new System.Windows.Forms.TextBox();
            this.tbSoyad = new System.Windows.Forms.TextBox();
            this.tbSifre = new System.Windows.Forms.TextBox();
            this.lFotograf = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbResim)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.panel7.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lnumara);
            this.panel1.Controls.Add(this.ladsoyad);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(231, 100);
            this.panel1.TabIndex = 0;
            // 
            // lnumara
            // 
            this.lnumara.AutoSize = true;
            this.lnumara.Location = new System.Drawing.Point(102, 55);
            this.lnumara.Name = "lnumara";
            this.lnumara.Size = new System.Drawing.Size(81, 22);
            this.lnumara.TabIndex = 3;
            this.lnumara.Text = "lnumara";
            // 
            // ladsoyad
            // 
            this.ladsoyad.AutoSize = true;
            this.ladsoyad.Location = new System.Drawing.Point(17, 31);
            this.ladsoyad.Name = "ladsoyad";
            this.ladsoyad.Size = new System.Drawing.Size(79, 22);
            this.ladsoyad.TabIndex = 2;
            this.ladsoyad.Text = "ad soyad";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 22);
            this.label2.TabIndex = 1;
            this.label2.Text = "Numara:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "Hoşgeldiniz";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lFotograf);
            this.panel2.Controls.Add(this.tbSifre);
            this.panel2.Controls.Add(this.tbSoyad);
            this.panel2.Controls.Add(this.tbAd);
            this.panel2.Controls.Add(this.mtbNumara);
            this.panel2.Controls.Add(this.pbResim);
            this.panel2.Controls.Add(this.btnFotoSec);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.panel2.Location = new System.Drawing.Point(12, 129);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(231, 309);
            this.panel2.TabIndex = 1;
            // 
            // pbResim
            // 
            this.pbResim.Location = new System.Drawing.Point(87, 171);
            this.pbResim.Name = "pbResim";
            this.pbResim.Size = new System.Drawing.Size(127, 93);
            this.pbResim.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbResim.TabIndex = 6;
            this.pbResim.TabStop = false;
            // 
            // btnFotoSec
            // 
            this.btnFotoSec.Location = new System.Drawing.Point(79, 270);
            this.btnFotoSec.Name = "btnFotoSec";
            this.btnFotoSec.Size = new System.Drawing.Size(135, 27);
            this.btnFotoSec.TabIndex = 5;
            this.btnFotoSec.Text = "Fotoğraf Seç";
            this.btnFotoSec.UseVisualStyleBackColor = true;
            this.btnFotoSec.Click += new System.EventHandler(this.btnFotoSec_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(8, 184);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(73, 19);
            this.label9.TabIndex = 4;
            this.label9.Text = "Fotoğraf:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(8, 142);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(46, 19);
            this.label8.TabIndex = 3;
            this.label8.Text = "Şifre:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(8, 100);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 19);
            this.label7.TabIndex = 2;
            this.label7.Text = "Soyad:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(8, 58);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(33, 19);
            this.label6.TabIndex = 1;
            this.label6.Text = "Ad:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(8, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 19);
            this.label5.TabIndex = 0;
            this.label5.Text = "Numara:";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label16);
            this.panel3.Controls.Add(this.label17);
            this.panel3.Controls.Add(this.label18);
            this.panel3.Controls.Add(this.label19);
            this.panel3.Controls.Add(this.label20);
            this.panel3.Controls.Add(this.label21);
            this.panel3.Controls.Add(this.textBox6);
            this.panel3.Controls.Add(this.tbOrtalama);
            this.panel3.Controls.Add(this.tbProje);
            this.panel3.Controls.Add(this.tbSinav3);
            this.panel3.Controls.Add(this.tbSinav2);
            this.panel3.Controls.Add(this.tbSinav1);
            this.panel3.Controls.Add(this.button6);
            this.panel3.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.panel3.Location = new System.Drawing.Point(249, 12);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(200, 236);
            this.panel3.TabIndex = 2;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(4, 165);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(74, 22);
            this.label16.TabIndex = 17;
            this.label16.Text = "Durum:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(1, 133);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(94, 22);
            this.label17.TabIndex = 16;
            this.label17.Text = "Ortalama:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(4, 101);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(57, 22);
            this.label18.TabIndex = 15;
            this.label18.Text = "Proje:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(4, 69);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(77, 22);
            this.label19.TabIndex = 14;
            this.label19.Text = "Sınav 3:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(4, 37);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(77, 22);
            this.label20.TabIndex = 13;
            this.label20.Text = "Sınav 2:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(4, 5);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(77, 22);
            this.label21.TabIndex = 12;
            this.label21.Text = "Sınav 1:";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(97, 162);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 29);
            this.textBox6.TabIndex = 11;
            // 
            // tbOrtalama
            // 
            this.tbOrtalama.Location = new System.Drawing.Point(97, 130);
            this.tbOrtalama.Name = "tbOrtalama";
            this.tbOrtalama.Size = new System.Drawing.Size(100, 29);
            this.tbOrtalama.TabIndex = 10;
            // 
            // tbProje
            // 
            this.tbProje.Location = new System.Drawing.Point(97, 98);
            this.tbProje.Name = "tbProje";
            this.tbProje.Size = new System.Drawing.Size(100, 29);
            this.tbProje.TabIndex = 9;
            // 
            // tbSinav3
            // 
            this.tbSinav3.Location = new System.Drawing.Point(97, 66);
            this.tbSinav3.Name = "tbSinav3";
            this.tbSinav3.Size = new System.Drawing.Size(100, 29);
            this.tbSinav3.TabIndex = 8;
            // 
            // tbSinav2
            // 
            this.tbSinav2.Location = new System.Drawing.Point(97, 34);
            this.tbSinav2.Name = "tbSinav2";
            this.tbSinav2.Size = new System.Drawing.Size(100, 29);
            this.tbSinav2.TabIndex = 7;
            // 
            // tbSinav1
            // 
            this.tbSinav1.Location = new System.Drawing.Point(97, 2);
            this.tbSinav1.Name = "tbSinav1";
            this.tbSinav1.Size = new System.Drawing.Size(100, 29);
            this.tbSinav1.TabIndex = 3;
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button6.Location = new System.Drawing.Point(0, 206);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(194, 27);
            this.button6.TabIndex = 6;
            this.button6.Text = "Hesapla";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.button5);
            this.panel4.Controls.Add(this.btnGuncelle);
            this.panel4.Controls.Add(this.btnSil);
            this.panel4.Controls.Add(this.btnKayit);
            this.panel4.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.panel4.Location = new System.Drawing.Point(249, 254);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(200, 184);
            this.panel4.TabIndex = 0;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(0, 141);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(197, 35);
            this.button5.TabIndex = 3;
            this.button5.Text = "Listele";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // btnGuncelle
            // 
            this.btnGuncelle.Location = new System.Drawing.Point(0, 98);
            this.btnGuncelle.Name = "btnGuncelle";
            this.btnGuncelle.Size = new System.Drawing.Size(197, 35);
            this.btnGuncelle.TabIndex = 2;
            this.btnGuncelle.Text = "Güncelle";
            this.btnGuncelle.UseVisualStyleBackColor = true;
            this.btnGuncelle.Click += new System.EventHandler(this.btnGuncelle_Click);
            // 
            // btnSil
            // 
            this.btnSil.Location = new System.Drawing.Point(0, 55);
            this.btnSil.Name = "btnSil";
            this.btnSil.Size = new System.Drawing.Size(197, 35);
            this.btnSil.TabIndex = 1;
            this.btnSil.Text = "Sil";
            this.btnSil.UseVisualStyleBackColor = true;
            this.btnSil.Click += new System.EventHandler(this.btnSil_Click);
            // 
            // btnKayit
            // 
            this.btnKayit.Location = new System.Drawing.Point(0, 12);
            this.btnKayit.Name = "btnKayit";
            this.btnKayit.Size = new System.Drawing.Size(197, 35);
            this.btnKayit.TabIndex = 0;
            this.btnKayit.Text = "Kaydet";
            this.btnKayit.UseVisualStyleBackColor = true;
            this.btnKayit.Click += new System.EventHandler(this.btnKayit_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.dataGridView1);
            this.panel5.Location = new System.Drawing.Point(458, 12);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(447, 211);
            this.panel5.TabIndex = 3;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(-3, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(444, 208);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.dataGridView2);
            this.panel6.Location = new System.Drawing.Point(455, 229);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(450, 164);
            this.panel6.TabIndex = 4;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(0, 0);
            this.dataGridView2.MultiSelect = false;
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersVisible = false;
            this.dataGridView2.Size = new System.Drawing.Size(447, 158);
            this.dataGridView2.TabIndex = 0;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.button10);
            this.panel7.Controls.Add(this.button9);
            this.panel7.Controls.Add(this.button8);
            this.panel7.Controls.Add(this.button7);
            this.panel7.Font = new System.Drawing.Font("Times New Roman", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.panel7.Location = new System.Drawing.Point(455, 399);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(447, 39);
            this.panel7.TabIndex = 5;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(335, 6);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(105, 27);
            this.button10.TabIndex = 3;
            this.button10.Text = "Yardım";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(224, 6);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(105, 27);
            this.button9.TabIndex = 2;
            this.button9.Text = "Mesajlar";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(113, 6);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(105, 27);
            this.button8.TabIndex = 1;
            this.button8.Text = "Duyuru Listesi";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(3, 6);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(104, 27);
            this.button7.TabIndex = 0;
            this.button7.Text = "Duyuru Oluştur";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // mtbNumara
            // 
            this.mtbNumara.Location = new System.Drawing.Point(79, 16);
            this.mtbNumara.Mask = "0000";
            this.mtbNumara.Name = "mtbNumara";
            this.mtbNumara.Size = new System.Drawing.Size(100, 26);
            this.mtbNumara.TabIndex = 7;
            // 
            // tbAd
            // 
            this.tbAd.Location = new System.Drawing.Point(79, 51);
            this.tbAd.Name = "tbAd";
            this.tbAd.Size = new System.Drawing.Size(149, 26);
            this.tbAd.TabIndex = 8;
            // 
            // tbSoyad
            // 
            this.tbSoyad.Location = new System.Drawing.Point(79, 93);
            this.tbSoyad.Name = "tbSoyad";
            this.tbSoyad.Size = new System.Drawing.Size(149, 26);
            this.tbSoyad.TabIndex = 9;
            // 
            // tbSifre
            // 
            this.tbSifre.Location = new System.Drawing.Point(79, 139);
            this.tbSifre.Name = "tbSifre";
            this.tbSifre.Size = new System.Drawing.Size(84, 26);
            this.tbSifre.TabIndex = 10;
            // 
            // lFotograf
            // 
            this.lFotograf.AutoSize = true;
            this.lFotograf.Location = new System.Drawing.Point(12, 244);
            this.lFotograf.Name = "lFotograf";
            this.lFotograf.Size = new System.Drawing.Size(50, 19);
            this.lFotograf.TabIndex = 11;
            this.lFotograf.Text = "label3";
            this.lFotograf.Visible = false;
            // 
            // Ogretmen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(917, 450);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Ogretmen";
            this.Text = "Ogretmen";
            this.Load += new System.EventHandler(this.Ogretmen_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbResim)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.panel7.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lnumara;
        private System.Windows.Forms.Label ladsoyad;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pbResim;
        private System.Windows.Forms.Button btnFotoSec;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox tbOrtalama;
        private System.Windows.Forms.TextBox tbProje;
        private System.Windows.Forms.TextBox tbSinav3;
        private System.Windows.Forms.TextBox tbSinav2;
        private System.Windows.Forms.TextBox tbSinav1;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button btnGuncelle;
        private System.Windows.Forms.Button btnSil;
        private System.Windows.Forms.Button btnKayit;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.MaskedTextBox mtbNumara;
        private System.Windows.Forms.Label lFotograf;
        private System.Windows.Forms.TextBox tbSifre;
        private System.Windows.Forms.TextBox tbSoyad;
        private System.Windows.Forms.TextBox tbAd;
    }
}