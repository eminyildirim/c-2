﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Ogrenci_Not_Kayit
{
    public partial class Giris : Form
    {
        public Giris()
        {
            InitializeComponent();
        }
        SqlBaglantisi bgl = new SqlBaglantisi();
        private void button1_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("Select * from dbo.TblOgretmen Where Numara=@Numara and Sifre = @Sifre", bgl.baglanti());
            cmd.Parameters.AddWithValue("@Numara", mtbNumara.Text);
            cmd.Parameters.AddWithValue("@Sifre", tbSifre.Text);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {

                int bid = dr.GetInt16(0);
                Ogretmen frm = new Ogretmen();
                frm.ID = bid;
                frm.ogretmenogrenci = 1;
                frm.numara = dr.GetString(dr.GetOrdinal("Numara"));
                frm.adsoyad = dr.GetString(dr.GetOrdinal("Ad")) + " " + dr.GetString(dr.GetOrdinal("Soyad"));
                this.Hide();
                frm.Show();
            }
            bgl.baglanti().Close();
        }

        private void btnOgrenci_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("Select * from dbo.TblOgrenci Where Numara=@Numara and Sifre = @Sifre", bgl.baglanti());
            cmd.Parameters.AddWithValue("@Numara", onumara.Text);
            cmd.Parameters.AddWithValue("@Sifre", osifre.Text);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                int bid = dr.GetInt16(0);
                Ogenci frm = new Ogenci();
                frm.ID = (int)bid;
                frm.ogretmenogrenci = 2;
                frm.numara = dr.GetString(dr.GetOrdinal("Numara"));
                frm.adsoyad = dr.GetString(dr.GetOrdinal("Ad")) + " " + dr.GetString(dr.GetOrdinal("Soyad"));
                this.Hide();
                frm.Show();
            }
            else MessageBox.Show("kayıt yok");
            bgl.baglanti().Close();
        }
    }
}
