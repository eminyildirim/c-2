﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Ogrenci_Not_Kayit
{
    public partial class Duyurular : Form
    {
        SqlBaglantisi bgl = new SqlBaglantisi();
        public Duyurular()
        {
            InitializeComponent();
        }

        private void Duyurular_Load(object sender, EventArgs e)
        {
            Listele();
            if (pDuyuruGiris.Visible)
            {
                rtbDuyuru.Text = dgwDuyurular.Rows[dgwDuyurular.CurrentRow.Index].Cells[1].Value.ToString();
            }
        }
        void Listele()
        {
            SqlCommand cmd = new SqlCommand("Select * from dbo.TblDuyurular order by DuyuruID DESC", bgl.baglanti());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dgwDuyurular.DataSource = dt;
        }
        private void dgwDuyurular_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            MessageBox.Show(dgwDuyurular.Rows[e.RowIndex].Cells[1].Value.ToString());
        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("INSERT INTO dbo.TblDuyurular (İcerik) VALUES (@Duyuru)", bgl.baglanti());
            cmd.Parameters.AddWithValue("@Duyuru", rtbDuyuru.Text);
            cmd.ExecuteNonQuery();
            Listele();
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            int i = dgwDuyurular.CurrentRow.Index;
            SqlCommand cmd = new SqlCommand("DELETE FROM dbo.TblDuyurular WHERE DuyuruID=@DuyuruID", bgl.baglanti());
            cmd.Parameters.AddWithValue("@DuyuruID", dgwDuyurular.Rows[i].Cells[0].Value.ToString());
            cmd.ExecuteNonQuery();
            Listele();
        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            int i = dgwDuyurular.CurrentRow.Index;
            SqlCommand cmd = new SqlCommand("UPDATE dbo.TblDuyurular SET İcerik=@Duyuru WHERE DuyuruID=@DuyuruID", bgl.baglanti());
            cmd.Parameters.AddWithValue("@Duyuru", rtbDuyuru.Text);
            cmd.Parameters.AddWithValue("@DuyuruID", dgwDuyurular.Rows[i].Cells[0].Value.ToString());
            cmd.ExecuteNonQuery();
            Listele();
        }

        private void dgwDuyurular_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (pDuyuruGiris.Visible)
            {
                rtbDuyuru.Text = dgwDuyurular.Rows[e.RowIndex].Cells[1].Value.ToString();
            }
        }
    }
}
