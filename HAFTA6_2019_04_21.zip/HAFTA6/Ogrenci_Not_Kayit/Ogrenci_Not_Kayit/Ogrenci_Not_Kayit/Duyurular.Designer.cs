﻿namespace Ogrenci_Not_Kayit
{
    partial class Duyurular
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pDuyuruGiris = new System.Windows.Forms.Panel();
            this.btnEkle = new System.Windows.Forms.Button();
            this.btnSil = new System.Windows.Forms.Button();
            this.btnGuncelle = new System.Windows.Forms.Button();
            this.rtbDuyuru = new System.Windows.Forms.RichTextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.flpDuyuruListesi = new System.Windows.Forms.FlowLayoutPanel();
            this.dgwDuyurular = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Duyuru = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pDuyuruGiris.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.flpDuyuruListesi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgwDuyurular)).BeginInit();
            this.SuspendLayout();
            // 
            // pDuyuruGiris
            // 
            this.pDuyuruGiris.Controls.Add(this.btnEkle);
            this.pDuyuruGiris.Controls.Add(this.btnSil);
            this.pDuyuruGiris.Controls.Add(this.btnGuncelle);
            this.pDuyuruGiris.Controls.Add(this.rtbDuyuru);
            this.pDuyuruGiris.Controls.Add(this.pictureBox1);
            this.pDuyuruGiris.Font = new System.Drawing.Font("Times New Roman", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.pDuyuruGiris.Location = new System.Drawing.Point(12, 12);
            this.pDuyuruGiris.Name = "pDuyuruGiris";
            this.pDuyuruGiris.Size = new System.Drawing.Size(480, 138);
            this.pDuyuruGiris.TabIndex = 0;
            // 
            // btnEkle
            // 
            this.btnEkle.Location = new System.Drawing.Point(3, 104);
            this.btnEkle.Name = "btnEkle";
            this.btnEkle.Size = new System.Drawing.Size(75, 23);
            this.btnEkle.TabIndex = 2;
            this.btnEkle.Text = "Ekle";
            this.btnEkle.UseVisualStyleBackColor = true;
            this.btnEkle.Click += new System.EventHandler(this.btnEkle_Click);
            // 
            // btnSil
            // 
            this.btnSil.Location = new System.Drawing.Point(106, 104);
            this.btnSil.Name = "btnSil";
            this.btnSil.Size = new System.Drawing.Size(75, 23);
            this.btnSil.TabIndex = 3;
            this.btnSil.Text = "Sil";
            this.btnSil.UseVisualStyleBackColor = true;
            this.btnSil.Click += new System.EventHandler(this.btnSil_Click);
            // 
            // btnGuncelle
            // 
            this.btnGuncelle.Location = new System.Drawing.Point(222, 104);
            this.btnGuncelle.Name = "btnGuncelle";
            this.btnGuncelle.Size = new System.Drawing.Size(75, 23);
            this.btnGuncelle.TabIndex = 4;
            this.btnGuncelle.Text = "Güncelle";
            this.btnGuncelle.UseVisualStyleBackColor = true;
            this.btnGuncelle.Click += new System.EventHandler(this.btnGuncelle_Click);
            // 
            // rtbDuyuru
            // 
            this.rtbDuyuru.Location = new System.Drawing.Point(3, 3);
            this.rtbDuyuru.Name = "rtbDuyuru";
            this.rtbDuyuru.Size = new System.Drawing.Size(294, 96);
            this.rtbDuyuru.TabIndex = 2;
            this.rtbDuyuru.Text = "";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Ogrenci_Not_Kayit.Properties.Resources.duyuru;
            this.pictureBox1.Location = new System.Drawing.Point(346, 13);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(119, 114);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // flpDuyuruListesi
            // 
            this.flpDuyuruListesi.Controls.Add(this.dgwDuyurular);
            this.flpDuyuruListesi.Location = new System.Drawing.Point(12, 156);
            this.flpDuyuruListesi.Name = "flpDuyuruListesi";
            this.flpDuyuruListesi.Size = new System.Drawing.Size(480, 251);
            this.flpDuyuruListesi.TabIndex = 1;
            // 
            // dgwDuyurular
            // 
            this.dgwDuyurular.AllowUserToAddRows = false;
            this.dgwDuyurular.AllowUserToDeleteRows = false;
            this.dgwDuyurular.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgwDuyurular.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.Duyuru});
            this.dgwDuyurular.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dgwDuyurular.Location = new System.Drawing.Point(3, 3);
            this.dgwDuyurular.Name = "dgwDuyurular";
            this.dgwDuyurular.ReadOnly = true;
            this.dgwDuyurular.RowHeadersVisible = false;
            this.dgwDuyurular.Size = new System.Drawing.Size(462, 236);
            this.dgwDuyurular.TabIndex = 2;
            this.dgwDuyurular.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgwDuyurular_CellClick);
            this.dgwDuyurular.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgwDuyurular_CellDoubleClick);
            // 
            // ID
            // 
            this.ID.DataPropertyName = "DuyuruID";
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            this.ID.Visible = false;
            this.ID.Width = 40;
            // 
            // Duyuru
            // 
            this.Duyuru.DataPropertyName = "İcerik";
            this.Duyuru.HeaderText = "Duyuru";
            this.Duyuru.Name = "Duyuru";
            this.Duyuru.ReadOnly = true;
            this.Duyuru.Width = 400;
            // 
            // Duyurular
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(510, 423);
            this.Controls.Add(this.flpDuyuruListesi);
            this.Controls.Add(this.pDuyuruGiris);
            this.Name = "Duyurular";
            this.Text = "Duyurular";
            this.Load += new System.EventHandler(this.Duyurular_Load);
            this.pDuyuruGiris.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.flpDuyuruListesi.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgwDuyurular)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.Panel pDuyuruGiris;
        private System.Windows.Forms.Button btnEkle;
        private System.Windows.Forms.Button btnSil;
        private System.Windows.Forms.Button btnGuncelle;
        private System.Windows.Forms.RichTextBox rtbDuyuru;
        private System.Windows.Forms.PictureBox pictureBox1;
        public System.Windows.Forms.FlowLayoutPanel flpDuyuruListesi;
        public System.Windows.Forms.DataGridView dgwDuyurular;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Duyuru;
    }
}