﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Ogrenci_Not_Kayit
{
    public partial class Mesajlar : Form
    {
        public int ID { get; set; }
        public byte ogretmenogrenci { get; set; }
        public string numara { get; set; }
        public string adsoyad { get; set; }
        SqlBaglantisi bgl = new SqlBaglantisi();
        List<string> arrProjectList;
        public Mesajlar()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Mesajlar_Load(object sender, EventArgs e)
        {
            mtbGonderen.Text = adsoyad;
            GelenMesaj();
            GidenMesaj();
            //View_Alicilar

            SqlCommand cmd = new SqlCommand("Select * from dbo.View_Alicilar ORDER BY Alici", bgl.baglanti());
            SqlDataReader dr = cmd.ExecuteReader();

            arrProjectList = new List<string>();
            while (dr.Read())
            {
                // cbAlicilar.Items.Add(dr.GetString(0));
                // cbNumaralar.Items.Add(dr.GetString(1));
                arrProjectList.Add(dr.GetString(2).ToString());
            }
            arrProjectList.Sort();

            // then just bind it to the DataSource of the ComboBox
            cbAlicilar.DataSource = arrProjectList;
            lbAlicilar.DataSource = arrProjectList;
            // don't select automatically the first item
            cbAlicilar.SelectedIndex = -1;

        }
        void GelenMesaj()
        {
            SqlCommand cmd = new SqlCommand("Select GonderenAd,baslik,İcerik from dbo.View_Mesajlar WHERE Alici=@Alici and AliciTipi=@AliciTipi order by ID DESC", bgl.baglanti());
            cmd.Parameters.AddWithValue("@Alici", numara);
            cmd.Parameters.AddWithValue("@AliciTipi", ogretmenogrenci);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dgvGelenMesaj.DataSource = dt;
        }
        void GidenMesaj()
        {
            SqlCommand cmd = new SqlCommand("Select AliciAd,baslik,İcerik from dbo.View_Mesajlar WHERE Gonderen=@Gonderen and GonderenTipi=@GonderenTipi order by ID", bgl.baglanti());
            cmd.Parameters.AddWithValue("@Gonderen", numara);
            cmd.Parameters.AddWithValue("@GonderenTipi", ogretmenogrenci);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dgvGidenMesaj.DataSource = dt;
        }

        private void btnGonder_Click(object sender, EventArgs e)
        {
            if (lbAlicilar.Items.Count > 0 && tbBaslik.Text != "" && rtbicerik.Text != "")
            {
                String x = lbAlicilar.Items[0].ToString();
                mtbAlici.Text = x.Substring(x.Length - 4);
                x = lbAlicilar.Items[0].ToString();
                byte gtipi= Convert.ToByte(x.Substring(x.Length - 6,1));

                SqlCommand cmd = new SqlCommand("INSERT INTO dbo.TblMesajlar (Gonderen,Alici,Baslik,İcerik,GonderenTipi,AliciTipi) VALUES (@Gonderen,@Alici,@Baslik,@İcerik,@GonderenTipi,@AliciTipi)", bgl.baglanti());
                cmd.Parameters.AddWithValue("@Gonderen", numara);
                cmd.Parameters.AddWithValue("Alici", mtbAlici.Text);
                cmd.Parameters.AddWithValue("@Baslik", tbBaslik.Text);
                cmd.Parameters.AddWithValue("@İcerik", rtbicerik.Text);
                cmd.Parameters.AddWithValue("@GonderenTipi", ogretmenogrenci);
                cmd.Parameters.AddWithValue("@AliciTipi", gtipi);
                cmd.ExecuteNonQuery();
                GidenMesaj();
                tcMesajlar.SelectedIndex = 1;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string filter_param = textBox1.Text.ToUpper();

            // List<string> filteredItems = arrProjectList.FindAll(x => x.Contains(filter_param));
            // another variant for filtering using StartsWith:
            List<string> filteredItems = arrProjectList.FindAll(x => x.StartsWith(filter_param));

     
            lbAlicilar.DataSource = filteredItems;
            lbAlicilar.Visible = true;
            // if all values removed, bind the original full list again
            if (String.IsNullOrWhiteSpace(textBox1.Text))
            {         
                lbAlicilar.DataSource = arrProjectList;
                lbAlicilar.Visible = false;
            }
            
        }

        private void cbAlicilar_TextChanged(object sender, EventArgs e)
        {
            /*  string filter_param = cbAlicilar.Text;

            //  List<string> filteredItems = arrProjectList.FindAll(x => x.Contains(filter_param));
              // another variant for filtering using StartsWith:
              List<string> filteredItems = arrProjectList.FindAll(x => x.StartsWith(filter_param));

              cbAlicilar.DataSource = filteredItems;

              // if all values removed, bind the original full list again
              if (String.IsNullOrWhiteSpace(textBox1.Text))
              {
                  cbAlicilar.DataSource = arrProjectList;
              }
              */
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String x = lbAlicilar.Items[0].ToString();
            MessageBox.Show(x.Substring(x.Length - 4));
        }

        private void cbAlicilar_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lbAlicilar_Click(object sender, EventArgs e)
        {
            string x = lbAlicilar.Items[0].ToString();
            textBox1.Text = x.Substring(0,45).TrimEnd();
            lbAlicilar.Visible = false;
            tbBaslik.Focus();
        }
    }
}
