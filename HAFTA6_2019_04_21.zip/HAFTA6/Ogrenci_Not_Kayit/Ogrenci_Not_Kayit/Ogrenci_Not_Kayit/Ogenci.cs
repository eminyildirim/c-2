﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Ogrenci_Not_Kayit
{
    public partial class Ogenci : Form
    {
        public int ID { get; set; }
        public byte ogretmenogrenci { get; set; }
        public string numara { get; set; }
        public string adsoyad { get; set; }
        SqlBaglantisi bgl = new SqlBaglantisi();
        public Ogenci()
        {
            InitializeComponent();
        }
        private void Ogenci_Load(object sender, EventArgs e)
        {
            lnumara.Text = numara;
            ladsoyad.Text = adsoyad;

            SqlCommand cmd = new SqlCommand("Select * FROM dbo.TblNotlar WHERE OgrnciID = @ID", bgl.baglanti());
            cmd.Parameters.AddWithValue("@ID", ID);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {

                tbSinav1.Text = dr.GetByte(1).ToString().ToString();
                tbSinav2.Text = dr.GetByte(2).ToString().ToString();
                tbSinav3.Text = dr.GetByte(3).ToString().ToString();
                tbProje.Text = dr.GetByte(4).ToString().ToString();

            }
        }
         private void btnDuyurular_Click(object sender, EventArgs e)
        {
            Duyurular frm = new Duyurular();
            frm.pDuyuruGiris.Visible = false;
            frm.flpDuyuruListesi.Top = frm.pDuyuruGiris.Top;
            frm.flpDuyuruListesi.Height = frm.pDuyuruGiris.Height + 250;
            frm.dgwDuyurular.Height = frm.flpDuyuruListesi.Height - 14;
            frm.ShowDialog();
        }




        private void btnMesajlar_Click(object sender, EventArgs e)
        {
            Mesajlar frm = new Mesajlar();
            frm.tcMesajlar.TabIndex = 0;
            frm.ID = ID;
            frm.ogretmenogrenci = ogretmenogrenci;
            frm.numara = numara;
            frm.adsoyad = adsoyad;
            frm.ShowDialog();
        }

        private void btnCikis_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnHesapMak_Click(object sender, EventArgs e)
        {
            string hesap;
            hesap = @"calc.exe";
            System.Diagnostics.Process.Start(hesap);
        }
    }
}
