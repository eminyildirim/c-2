﻿namespace Ogrenci_Not_Kayit
{
    partial class Mesajlar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.tcMesajlar = new System.Windows.Forms.TabControl();
            this.gelenkutusu = new System.Windows.Forms.TabPage();
            this.dgvGelenMesaj = new System.Windows.Forms.DataGridView();
            this.gidenkutusu = new System.Windows.Forms.TabPage();
            this.dgvGidenMesaj = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnGonder = new System.Windows.Forms.Button();
            this.rtbicerik = new System.Windows.Forms.RichTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbBaslik = new System.Windows.Forms.TextBox();
            this.mtbAlici = new System.Windows.Forms.MaskedTextBox();
            this.mtbGonderen = new System.Windows.Forms.MaskedTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cbAlicilar = new System.Windows.Forms.ComboBox();
            this.cbNumaralar = new System.Windows.Forms.ComboBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lbAlicilar = new System.Windows.Forms.ListBox();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.tcMesajlar.SuspendLayout();
            this.gelenkutusu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGelenMesaj)).BeginInit();
            this.gidenkutusu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGidenMesaj)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tcMesajlar);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(776, 315);
            this.panel1.TabIndex = 0;
            // 
            // tcMesajlar
            // 
            this.tcMesajlar.Controls.Add(this.gelenkutusu);
            this.tcMesajlar.Controls.Add(this.gidenkutusu);
            this.tcMesajlar.Location = new System.Drawing.Point(0, 0);
            this.tcMesajlar.Name = "tcMesajlar";
            this.tcMesajlar.SelectedIndex = 0;
            this.tcMesajlar.Size = new System.Drawing.Size(776, 312);
            this.tcMesajlar.TabIndex = 0;
            // 
            // gelenkutusu
            // 
            this.gelenkutusu.Controls.Add(this.dgvGelenMesaj);
            this.gelenkutusu.Location = new System.Drawing.Point(4, 22);
            this.gelenkutusu.Name = "gelenkutusu";
            this.gelenkutusu.Padding = new System.Windows.Forms.Padding(3);
            this.gelenkutusu.Size = new System.Drawing.Size(768, 286);
            this.gelenkutusu.TabIndex = 0;
            this.gelenkutusu.Text = "Gelen Kutusu";
            this.gelenkutusu.UseVisualStyleBackColor = true;
            // 
            // dgvGelenMesaj
            // 
            this.dgvGelenMesaj.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGelenMesaj.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvGelenMesaj.Location = new System.Drawing.Point(3, 3);
            this.dgvGelenMesaj.Name = "dgvGelenMesaj";
            this.dgvGelenMesaj.Size = new System.Drawing.Size(762, 280);
            this.dgvGelenMesaj.TabIndex = 0;
            // 
            // gidenkutusu
            // 
            this.gidenkutusu.Controls.Add(this.dgvGidenMesaj);
            this.gidenkutusu.Location = new System.Drawing.Point(4, 22);
            this.gidenkutusu.Name = "gidenkutusu";
            this.gidenkutusu.Padding = new System.Windows.Forms.Padding(3);
            this.gidenkutusu.Size = new System.Drawing.Size(768, 286);
            this.gidenkutusu.TabIndex = 1;
            this.gidenkutusu.Text = "Giden Kutusu";
            this.gidenkutusu.UseVisualStyleBackColor = true;
            // 
            // dgvGidenMesaj
            // 
            this.dgvGidenMesaj.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGidenMesaj.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvGidenMesaj.Location = new System.Drawing.Point(3, 3);
            this.dgvGidenMesaj.Name = "dgvGidenMesaj";
            this.dgvGidenMesaj.Size = new System.Drawing.Size(762, 280);
            this.dgvGidenMesaj.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lbAlicilar);
            this.groupBox1.Controls.Add(this.cbAlicilar);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.btnGonder);
            this.groupBox1.Controls.Add(this.rtbicerik);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.tbBaslik);
            this.groupBox1.Controls.Add(this.mtbAlici);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox1.Location = new System.Drawing.Point(12, 338);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(776, 190);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Mesaj Gönderme";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // btnGonder
            // 
            this.btnGonder.Location = new System.Drawing.Point(648, 151);
            this.btnGonder.Name = "btnGonder";
            this.btnGonder.Size = new System.Drawing.Size(95, 33);
            this.btnGonder.TabIndex = 8;
            this.btnGonder.Text = "Gönder";
            this.btnGonder.UseVisualStyleBackColor = true;
            this.btnGonder.Click += new System.EventHandler(this.btnGonder_Click);
            // 
            // rtbicerik
            // 
            this.rtbicerik.Location = new System.Drawing.Point(436, 43);
            this.rtbicerik.Name = "rtbicerik";
            this.rtbicerik.Size = new System.Drawing.Size(307, 94);
            this.rtbicerik.TabIndex = 7;
            this.rtbicerik.Text = "";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(364, 43);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 19);
            this.label4.TabIndex = 6;
            this.label4.Text = "Mesaj:";
            // 
            // tbBaslik
            // 
            this.tbBaslik.Location = new System.Drawing.Point(436, 11);
            this.tbBaslik.Name = "tbBaslik";
            this.tbBaslik.Size = new System.Drawing.Size(307, 26);
            this.tbBaslik.TabIndex = 5;
            // 
            // mtbAlici
            // 
            this.mtbAlici.Location = new System.Drawing.Point(355, 146);
            this.mtbAlici.Mask = "0000";
            this.mtbAlici.Name = "mtbAlici";
            this.mtbAlici.Size = new System.Drawing.Size(29, 26);
            this.mtbAlici.TabIndex = 4;
            this.mtbAlici.Visible = false;
            // 
            // mtbGonderen
            // 
            this.mtbGonderen.Location = new System.Drawing.Point(80, 549);
            this.mtbGonderen.Mask = "0000";
            this.mtbGonderen.Name = "mtbGonderen";
            this.mtbGonderen.ReadOnly = true;
            this.mtbGonderen.Size = new System.Drawing.Size(100, 20);
            this.mtbGonderen.TabIndex = 3;
            this.mtbGonderen.ValidatingType = typeof(int);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(364, 14);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 19);
            this.label3.TabIndex = 2;
            this.label3.Text = "Konu:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 19);
            this.label2.TabIndex = 1;
            this.label2.Text = "Alıcı:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 549);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Gönderen:";
            // 
            // cbAlicilar
            // 
            this.cbAlicilar.AllowDrop = true;
            this.cbAlicilar.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbAlicilar.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.cbAlicilar.FormattingEnabled = true;
            this.cbAlicilar.Location = new System.Drawing.Point(68, 151);
            this.cbAlicilar.Name = "cbAlicilar";
            this.cbAlicilar.Size = new System.Drawing.Size(221, 21);
            this.cbAlicilar.TabIndex = 9;
            this.cbAlicilar.Visible = false;
            this.cbAlicilar.SelectedIndexChanged += new System.EventHandler(this.cbAlicilar_SelectedIndexChanged);
            this.cbAlicilar.TextChanged += new System.EventHandler(this.cbAlicilar_TextChanged);
            // 
            // cbNumaralar
            // 
            this.cbNumaralar.FormattingEnabled = true;
            this.cbNumaralar.Location = new System.Drawing.Point(198, 549);
            this.cbNumaralar.Name = "cbNumaralar";
            this.cbNumaralar.Size = new System.Drawing.Size(306, 21);
            this.cbNumaralar.TabIndex = 10;
            this.cbNumaralar.Visible = false;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.textBox1.Location = new System.Drawing.Point(59, 22);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(258, 22);
            this.textBox1.TabIndex = 11;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // lbAlicilar
            // 
            this.lbAlicilar.Font = new System.Drawing.Font("Times New Roman", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbAlicilar.FormattingEnabled = true;
            this.lbAlicilar.ItemHeight = 14;
            this.lbAlicilar.Location = new System.Drawing.Point(68, 43);
            this.lbAlicilar.Name = "lbAlicilar";
            this.lbAlicilar.Size = new System.Drawing.Size(249, 88);
            this.lbAlicilar.TabIndex = 11;
            this.lbAlicilar.Visible = false;
            this.lbAlicilar.Click += new System.EventHandler(this.lbAlicilar_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(680, 546);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 12;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Mesajlar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(893, 624);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.cbNumaralar);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.mtbGonderen);
            this.Controls.Add(this.label1);
            this.Name = "Mesajlar";
            this.Text = "Mesajlar";
            this.Load += new System.EventHandler(this.Mesajlar_Load);
            this.panel1.ResumeLayout(false);
            this.tcMesajlar.ResumeLayout(false);
            this.gelenkutusu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvGelenMesaj)).EndInit();
            this.gidenkutusu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvGidenMesaj)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.TabControl tcMesajlar;
        private System.Windows.Forms.TabPage gelenkutusu;
        private System.Windows.Forms.DataGridView dgvGelenMesaj;
        private System.Windows.Forms.TabPage gidenkutusu;
        private System.Windows.Forms.DataGridView dgvGidenMesaj;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox tbBaslik;
        private System.Windows.Forms.MaskedTextBox mtbAlici;
        private System.Windows.Forms.MaskedTextBox mtbGonderen;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnGonder;
        private System.Windows.Forms.RichTextBox rtbicerik;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbAlicilar;
        private System.Windows.Forms.ComboBox cbNumaralar;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ListBox lbAlicilar;
        private System.Windows.Forms.Button button1;
    }
}