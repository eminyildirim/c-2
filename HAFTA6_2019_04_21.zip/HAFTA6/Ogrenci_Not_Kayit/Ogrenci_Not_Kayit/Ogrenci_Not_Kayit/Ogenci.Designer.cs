﻿namespace Ogrenci_Not_Kayit
{
    partial class Ogenci
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lnumara = new System.Windows.Forms.Label();
            this.ladsoyad = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.tbProje = new System.Windows.Forms.TextBox();
            this.tbSinav3 = new System.Windows.Forms.TextBox();
            this.tbSinav2 = new System.Windows.Forms.TextBox();
            this.tbSinav1 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnCikis = new System.Windows.Forms.Button();
            this.btnHesapMak = new System.Windows.Forms.Button();
            this.btnDuyurular = new System.Windows.Forms.Button();
            this.btnMesajlar = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lnumara);
            this.panel1.Controls.Add(this.ladsoyad);
            this.panel1.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(231, 100);
            this.panel1.TabIndex = 1;
            // 
            // lnumara
            // 
            this.lnumara.AutoSize = true;
            this.lnumara.Location = new System.Drawing.Point(13, 55);
            this.lnumara.Name = "lnumara";
            this.lnumara.Size = new System.Drawing.Size(60, 22);
            this.lnumara.TabIndex = 3;
            this.lnumara.Text = "label4";
            // 
            // ladsoyad
            // 
            this.ladsoyad.AutoSize = true;
            this.ladsoyad.Location = new System.Drawing.Point(13, 12);
            this.ladsoyad.Name = "ladsoyad";
            this.ladsoyad.Size = new System.Drawing.Size(60, 22);
            this.ladsoyad.TabIndex = 2;
            this.ladsoyad.Text = "label3";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.textBox6);
            this.panel3.Controls.Add(this.textBox5);
            this.panel3.Controls.Add(this.tbProje);
            this.panel3.Controls.Add(this.tbSinav3);
            this.panel3.Controls.Add(this.tbSinav2);
            this.panel3.Controls.Add(this.tbSinav1);
            this.panel3.Controls.Add(this.label15);
            this.panel3.Controls.Add(this.label14);
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.label12);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.panel3.Location = new System.Drawing.Point(12, 118);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(231, 236);
            this.panel3.TabIndex = 3;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(105, 171);
            this.textBox6.Name = "textBox6";
            this.textBox6.ReadOnly = true;
            this.textBox6.Size = new System.Drawing.Size(100, 29);
            this.textBox6.TabIndex = 11;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(105, 139);
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(100, 29);
            this.textBox5.TabIndex = 10;
            // 
            // tbProje
            // 
            this.tbProje.Location = new System.Drawing.Point(105, 107);
            this.tbProje.Name = "tbProje";
            this.tbProje.ReadOnly = true;
            this.tbProje.Size = new System.Drawing.Size(100, 29);
            this.tbProje.TabIndex = 9;
            // 
            // tbSinav3
            // 
            this.tbSinav3.Location = new System.Drawing.Point(105, 75);
            this.tbSinav3.Name = "tbSinav3";
            this.tbSinav3.ReadOnly = true;
            this.tbSinav3.Size = new System.Drawing.Size(100, 29);
            this.tbSinav3.TabIndex = 8;
            // 
            // tbSinav2
            // 
            this.tbSinav2.Location = new System.Drawing.Point(105, 43);
            this.tbSinav2.Name = "tbSinav2";
            this.tbSinav2.ReadOnly = true;
            this.tbSinav2.Size = new System.Drawing.Size(100, 29);
            this.tbSinav2.TabIndex = 7;
            // 
            // tbSinav1
            // 
            this.tbSinav1.Location = new System.Drawing.Point(105, 11);
            this.tbSinav1.Name = "tbSinav1";
            this.tbSinav1.ReadOnly = true;
            this.tbSinav1.Size = new System.Drawing.Size(100, 29);
            this.tbSinav1.TabIndex = 3;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(4, 171);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(74, 22);
            this.label15.TabIndex = 5;
            this.label15.Text = "Durum:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(4, 139);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(94, 22);
            this.label14.TabIndex = 4;
            this.label14.Text = "Ortalama:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(4, 107);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(57, 22);
            this.label13.TabIndex = 3;
            this.label13.Text = "Proje:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(4, 75);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(77, 22);
            this.label12.TabIndex = 2;
            this.label12.Text = "Sınav 3:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(4, 43);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(77, 22);
            this.label11.TabIndex = 1;
            this.label11.Text = "Sınav 2:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(3, 11);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(77, 22);
            this.label10.TabIndex = 0;
            this.label10.Text = "Sınav 1:";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.panel2.Location = new System.Drawing.Point(249, 206);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(201, 148);
            this.panel2.TabIndex = 4;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(3, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(193, 142);
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btnCikis);
            this.panel4.Controls.Add(this.btnHesapMak);
            this.panel4.Controls.Add(this.btnDuyurular);
            this.panel4.Controls.Add(this.btnMesajlar);
            this.panel4.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.panel4.Location = new System.Drawing.Point(249, 12);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(201, 188);
            this.panel4.TabIndex = 5;
            // 
            // btnCikis
            // 
            this.btnCikis.Location = new System.Drawing.Point(3, 138);
            this.btnCikis.Name = "btnCikis";
            this.btnCikis.Size = new System.Drawing.Size(195, 40);
            this.btnCikis.TabIndex = 3;
            this.btnCikis.Text = "Çıkış";
            this.btnCikis.UseVisualStyleBackColor = true;
            this.btnCikis.Click += new System.EventHandler(this.btnCikis_Click);
            // 
            // btnHesapMak
            // 
            this.btnHesapMak.Location = new System.Drawing.Point(3, 92);
            this.btnHesapMak.Name = "btnHesapMak";
            this.btnHesapMak.Size = new System.Drawing.Size(195, 40);
            this.btnHesapMak.TabIndex = 2;
            this.btnHesapMak.Text = "Hesap Makinası";
            this.btnHesapMak.UseVisualStyleBackColor = true;
            this.btnHesapMak.Click += new System.EventHandler(this.btnHesapMak_Click);
            // 
            // btnDuyurular
            // 
            this.btnDuyurular.Location = new System.Drawing.Point(3, 46);
            this.btnDuyurular.Name = "btnDuyurular";
            this.btnDuyurular.Size = new System.Drawing.Size(195, 40);
            this.btnDuyurular.TabIndex = 1;
            this.btnDuyurular.Text = "Duyurular";
            this.btnDuyurular.UseVisualStyleBackColor = true;
            this.btnDuyurular.Click += new System.EventHandler(this.btnDuyurular_Click);
            // 
            // btnMesajlar
            // 
            this.btnMesajlar.Location = new System.Drawing.Point(3, 3);
            this.btnMesajlar.Name = "btnMesajlar";
            this.btnMesajlar.Size = new System.Drawing.Size(195, 40);
            this.btnMesajlar.TabIndex = 0;
            this.btnMesajlar.Text = "Mesajlar";
            this.btnMesajlar.UseVisualStyleBackColor = true;
            this.btnMesajlar.Click += new System.EventHandler(this.btnMesajlar_Click);
            // 
            // Ogenci
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ClientSize = new System.Drawing.Size(454, 357);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "Ogenci";
            this.Text = "Ogenci";
            this.Load += new System.EventHandler(this.Ogenci_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lnumara;
        private System.Windows.Forms.Label ladsoyad;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox tbProje;
        private System.Windows.Forms.TextBox tbSinav3;
        private System.Windows.Forms.TextBox tbSinav2;
        private System.Windows.Forms.TextBox tbSinav1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnCikis;
        private System.Windows.Forms.Button btnHesapMak;
        private System.Windows.Forms.Button btnDuyurular;
        private System.Windows.Forms.Button btnMesajlar;
    }
}