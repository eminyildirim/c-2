﻿namespace NotSistemi
{
    partial class FormOgretmen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pOgretmen = new System.Windows.Forms.Panel();
            this.tcOgretmen = new System.Windows.Forms.TabControl();
            this.tpOgrenci = new System.Windows.Forms.TabPage();
            this.pOgrenciButon = new System.Windows.Forms.Panel();
            this.btnNotVazgec = new System.Windows.Forms.Button();
            this.btnNotKayit = new System.Windows.Forms.Button();
            this.cbNotProje = new System.Windows.Forms.CheckBox();
            this.btnNotGir = new System.Windows.Forms.Button();
            this.cbNot3 = new System.Windows.Forms.CheckBox();
            this.cbNot2 = new System.Windows.Forms.CheckBox();
            this.cbNot1 = new System.Windows.Forms.CheckBox();
            this.btnOgrenciSil = new System.Windows.Forms.Button();
            this.btnOgrenciDegistir = new System.Windows.Forms.Button();
            this.btnOgrenciEkleAc = new System.Windows.Forms.Button();
            this.gbOgrenciKayit = new System.Windows.Forms.GroupBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnVazgec = new System.Windows.Forms.Button();
            this.btnKayit = new System.Windows.Forms.Button();
            this.btnNumaraVer = new System.Windows.Forms.Button();
            this.tbOSoyad = new System.Windows.Forms.TextBox();
            this.tbOAd = new System.Windows.Forms.TextBox();
            this.tbONo = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.ogrenciKayitDBDataSet = new NotSistemi.OgrenciKayitDBDataSet();
            this.dgvOgrenciler = new System.Windows.Forms.DataGridView();
            this.OID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ONo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AdSoyad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ID_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Not1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Not2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Not3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PNotu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Ortalama = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Durumu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Ad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Soyad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cMSOgrenci = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.cMSOgrenciEkle = new System.Windows.Forms.ToolStripMenuItem();
            this.cMSOgrenciDegistir = new System.Windows.Forms.ToolStripMenuItem();
            this.cMSOgrenciSil = new System.Windows.Forms.ToolStripMenuItem();
            this.tpMesaj = new System.Windows.Forms.TabPage();
            this.dgvMesajlar = new System.Windows.Forms.DataGridView();
            this.Kimden = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Konu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Mesaj = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnKimeEkle = new System.Windows.Forms.Button();
            this.lbKime = new System.Windows.Forms.ListBox();
            this.cbKime = new System.Windows.Forms.ComboBox();
            this.tpDuyuru = new System.Windows.Forms.TabPage();
            this.pOgrenci = new System.Windows.Forms.Panel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.pOgretmen.SuspendLayout();
            this.tcOgretmen.SuspendLayout();
            this.tpOgrenci.SuspendLayout();
            this.pOgrenciButon.SuspendLayout();
            this.gbOgrenciKayit.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ogrenciKayitDBDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOgrenciler)).BeginInit();
            this.cMSOgrenci.SuspendLayout();
            this.tpMesaj.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMesajlar)).BeginInit();
            this.panel1.SuspendLayout();
            this.pOgrenci.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // pOgretmen
            // 
            this.pOgretmen.Controls.Add(this.tcOgretmen);
            this.pOgretmen.Location = new System.Drawing.Point(12, 6);
            this.pOgretmen.Name = "pOgretmen";
            this.pOgretmen.Size = new System.Drawing.Size(860, 738);
            this.pOgretmen.TabIndex = 1;
            // 
            // tcOgretmen
            // 
            this.tcOgretmen.Controls.Add(this.tpOgrenci);
            this.tcOgretmen.Controls.Add(this.tpMesaj);
            this.tcOgretmen.Controls.Add(this.tpDuyuru);
            this.tcOgretmen.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tcOgretmen.ItemSize = new System.Drawing.Size(100, 18);
            this.tcOgretmen.Location = new System.Drawing.Point(0, 0);
            this.tcOgretmen.Name = "tcOgretmen";
            this.tcOgretmen.SelectedIndex = 0;
            this.tcOgretmen.Size = new System.Drawing.Size(860, 738);
            this.tcOgretmen.TabIndex = 1;
            this.tcOgretmen.SelectedIndexChanged += new System.EventHandler(this.tcOgretmen_SelectedIndexChanged);
            this.tcOgretmen.TabIndexChanged += new System.EventHandler(this.tcOgretmen_TabIndexChanged);
            // 
            // tpOgrenci
            // 
            this.tpOgrenci.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.tpOgrenci.Controls.Add(this.pOgrenciButon);
            this.tpOgrenci.Controls.Add(this.gbOgrenciKayit);
            this.tpOgrenci.Controls.Add(this.textBox1);
            this.tpOgrenci.Controls.Add(this.dgvOgrenciler);
            this.tpOgrenci.Location = new System.Drawing.Point(4, 22);
            this.tpOgrenci.Name = "tpOgrenci";
            this.tpOgrenci.Padding = new System.Windows.Forms.Padding(3);
            this.tpOgrenci.Size = new System.Drawing.Size(852, 712);
            this.tpOgrenci.TabIndex = 0;
            this.tpOgrenci.Text = "Öğrenciler";
            // 
            // pOgrenciButon
            // 
            this.pOgrenciButon.BackColor = System.Drawing.Color.Azure;
            this.pOgrenciButon.Controls.Add(this.btnNotVazgec);
            this.pOgrenciButon.Controls.Add(this.btnNotKayit);
            this.pOgrenciButon.Controls.Add(this.cbNotProje);
            this.pOgrenciButon.Controls.Add(this.btnNotGir);
            this.pOgrenciButon.Controls.Add(this.cbNot3);
            this.pOgrenciButon.Controls.Add(this.cbNot2);
            this.pOgrenciButon.Controls.Add(this.cbNot1);
            this.pOgrenciButon.Controls.Add(this.btnOgrenciSil);
            this.pOgrenciButon.Controls.Add(this.btnOgrenciDegistir);
            this.pOgrenciButon.Controls.Add(this.btnOgrenciEkleAc);
            this.pOgrenciButon.Location = new System.Drawing.Point(599, 182);
            this.pOgrenciButon.Name = "pOgrenciButon";
            this.pOgrenciButon.Size = new System.Drawing.Size(250, 129);
            this.pOgrenciButon.TabIndex = 6;
            // 
            // btnNotVazgec
            // 
            this.btnNotVazgec.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnNotVazgec.Location = new System.Drawing.Point(179, 82);
            this.btnNotVazgec.Name = "btnNotVazgec";
            this.btnNotVazgec.Size = new System.Drawing.Size(65, 23);
            this.btnNotVazgec.TabIndex = 13;
            this.btnNotVazgec.Text = "Vazgeç";
            this.btnNotVazgec.UseVisualStyleBackColor = true;
            this.btnNotVazgec.Visible = false;
            this.btnNotVazgec.Click += new System.EventHandler(this.btnNotVazgec_Click);
            // 
            // btnNotKayit
            // 
            this.btnNotKayit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnNotKayit.Location = new System.Drawing.Point(84, 82);
            this.btnNotKayit.Name = "btnNotKayit";
            this.btnNotKayit.Size = new System.Drawing.Size(89, 23);
            this.btnNotKayit.TabIndex = 12;
            this.btnNotKayit.Text = "Notları Kayıt";
            this.btnNotKayit.UseVisualStyleBackColor = true;
            this.btnNotKayit.Visible = false;
            this.btnNotKayit.Click += new System.EventHandler(this.btnNotKayit_Click);
            // 
            // cbNotProje
            // 
            this.cbNotProje.AutoSize = true;
            this.cbNotProje.Location = new System.Drawing.Point(167, 48);
            this.cbNotProje.Name = "cbNotProje";
            this.cbNotProje.Size = new System.Drawing.Size(76, 17);
            this.cbNotProje.TabIndex = 11;
            this.cbNotProje.Tag = "3";
            this.cbNotProje.Text = "Proje Notu";
            this.cbNotProje.UseVisualStyleBackColor = true;
            // 
            // btnNotGir
            // 
            this.btnNotGir.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnNotGir.Location = new System.Drawing.Point(12, 82);
            this.btnNotGir.Name = "btnNotGir";
            this.btnNotGir.Size = new System.Drawing.Size(66, 23);
            this.btnNotGir.TabIndex = 10;
            this.btnNotGir.Text = "Not Gir";
            this.btnNotGir.UseVisualStyleBackColor = true;
            this.btnNotGir.Click += new System.EventHandler(this.btnNotGir_Click);
            // 
            // cbNot3
            // 
            this.cbNot3.AutoSize = true;
            this.cbNot3.Location = new System.Drawing.Point(112, 48);
            this.cbNot3.Name = "cbNot3";
            this.cbNot3.Size = new System.Drawing.Size(49, 17);
            this.cbNot3.TabIndex = 9;
            this.cbNot3.Tag = "3";
            this.cbNot3.Text = "Not3";
            this.cbNot3.UseVisualStyleBackColor = true;
            // 
            // cbNot2
            // 
            this.cbNot2.AutoSize = true;
            this.cbNot2.Location = new System.Drawing.Point(57, 48);
            this.cbNot2.Name = "cbNot2";
            this.cbNot2.Size = new System.Drawing.Size(49, 17);
            this.cbNot2.TabIndex = 8;
            this.cbNot2.Tag = "2";
            this.cbNot2.Text = "Not2";
            this.cbNot2.UseVisualStyleBackColor = true;
            // 
            // cbNot1
            // 
            this.cbNot1.AutoSize = true;
            this.cbNot1.Location = new System.Drawing.Point(4, 48);
            this.cbNot1.Name = "cbNot1";
            this.cbNot1.Size = new System.Drawing.Size(49, 17);
            this.cbNot1.TabIndex = 7;
            this.cbNot1.Tag = "1";
            this.cbNot1.Text = "Not1";
            this.cbNot1.UseVisualStyleBackColor = true;
            // 
            // btnOgrenciSil
            // 
            this.btnOgrenciSil.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnOgrenciSil.Location = new System.Drawing.Point(165, 3);
            this.btnOgrenciSil.Name = "btnOgrenciSil";
            this.btnOgrenciSil.Size = new System.Drawing.Size(75, 23);
            this.btnOgrenciSil.TabIndex = 6;
            this.btnOgrenciSil.Text = "Çıkar";
            this.btnOgrenciSil.UseVisualStyleBackColor = true;
            this.btnOgrenciSil.Click += new System.EventHandler(this.btnOgrenciSil_Click);
            // 
            // btnOgrenciDegistir
            // 
            this.btnOgrenciDegistir.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnOgrenciDegistir.Location = new System.Drawing.Point(84, 3);
            this.btnOgrenciDegistir.Name = "btnOgrenciDegistir";
            this.btnOgrenciDegistir.Size = new System.Drawing.Size(75, 23);
            this.btnOgrenciDegistir.TabIndex = 5;
            this.btnOgrenciDegistir.Text = "Değiştir";
            this.btnOgrenciDegistir.UseVisualStyleBackColor = true;
            this.btnOgrenciDegistir.Click += new System.EventHandler(this.btnOgrenciDegistir_Click);
            // 
            // btnOgrenciEkleAc
            // 
            this.btnOgrenciEkleAc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnOgrenciEkleAc.Location = new System.Drawing.Point(3, 3);
            this.btnOgrenciEkleAc.Name = "btnOgrenciEkleAc";
            this.btnOgrenciEkleAc.Size = new System.Drawing.Size(75, 23);
            this.btnOgrenciEkleAc.TabIndex = 4;
            this.btnOgrenciEkleAc.Text = "Ekle";
            this.btnOgrenciEkleAc.UseVisualStyleBackColor = true;
            this.btnOgrenciEkleAc.Click += new System.EventHandler(this.btnOgrenciEkleAc_Click);
            // 
            // gbOgrenciKayit
            // 
            this.gbOgrenciKayit.BackColor = System.Drawing.Color.Honeydew;
            this.gbOgrenciKayit.Controls.Add(this.panel2);
            this.gbOgrenciKayit.Location = new System.Drawing.Point(597, 12);
            this.gbOgrenciKayit.Name = "gbOgrenciKayit";
            this.gbOgrenciKayit.Size = new System.Drawing.Size(250, 164);
            this.gbOgrenciKayit.TabIndex = 5;
            this.gbOgrenciKayit.TabStop = false;
            this.gbOgrenciKayit.Text = "[  ÖĞRENCİ ]";
            this.gbOgrenciKayit.Visible = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.OldLace;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.btnVazgec);
            this.panel2.Controls.Add(this.btnKayit);
            this.panel2.Controls.Add(this.btnNumaraVer);
            this.panel2.Controls.Add(this.tbOSoyad);
            this.panel2.Controls.Add(this.tbOAd);
            this.panel2.Controls.Add(this.tbONo);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(3, 16);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(244, 145);
            this.panel2.TabIndex = 0;
            // 
            // btnVazgec
            // 
            this.btnVazgec.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnVazgec.FlatAppearance.BorderSize = 3;
            this.btnVazgec.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnVazgec.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnVazgec.Location = new System.Drawing.Point(151, 107);
            this.btnVazgec.Name = "btnVazgec";
            this.btnVazgec.Size = new System.Drawing.Size(75, 23);
            this.btnVazgec.TabIndex = 17;
            this.btnVazgec.Text = "Vazgeç";
            this.btnVazgec.UseVisualStyleBackColor = true;
            this.btnVazgec.Click += new System.EventHandler(this.btnVazgec_Click);
            // 
            // btnKayit
            // 
            this.btnKayit.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
            this.btnKayit.FlatAppearance.BorderSize = 3;
            this.btnKayit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnKayit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKayit.Location = new System.Drawing.Point(53, 107);
            this.btnKayit.Name = "btnKayit";
            this.btnKayit.Size = new System.Drawing.Size(75, 23);
            this.btnKayit.TabIndex = 16;
            this.btnKayit.Text = "Kayıt";
            this.btnKayit.UseVisualStyleBackColor = true;
            this.btnKayit.Click += new System.EventHandler(this.btnKayit_Click);
            // 
            // btnNumaraVer
            // 
            this.btnNumaraVer.Location = new System.Drawing.Point(147, 10);
            this.btnNumaraVer.Name = "btnNumaraVer";
            this.btnNumaraVer.Size = new System.Drawing.Size(75, 23);
            this.btnNumaraVer.TabIndex = 15;
            this.btnNumaraVer.Text = "Numara Ver";
            this.btnNumaraVer.UseVisualStyleBackColor = true;
            this.btnNumaraVer.Click += new System.EventHandler(this.btnNumaraVer_Click);
            // 
            // tbOSoyad
            // 
            this.tbOSoyad.Location = new System.Drawing.Point(53, 66);
            this.tbOSoyad.Name = "tbOSoyad";
            this.tbOSoyad.Size = new System.Drawing.Size(173, 20);
            this.tbOSoyad.TabIndex = 14;
            // 
            // tbOAd
            // 
            this.tbOAd.Location = new System.Drawing.Point(53, 39);
            this.tbOAd.Name = "tbOAd";
            this.tbOAd.Size = new System.Drawing.Size(173, 20);
            this.tbOAd.TabIndex = 13;
            // 
            // tbONo
            // 
            this.tbONo.Location = new System.Drawing.Point(53, 12);
            this.tbONo.MaxLength = 10;
            this.tbONo.Name = "tbONo";
            this.tbONo.Size = new System.Drawing.Size(88, 20);
            this.tbONo.TabIndex = 12;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(5, 69);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Soyadı:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(22, 46);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(25, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Adı:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(24, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "No:";
            // 
            // textBox1
            // 
            this.textBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bindingSource1, "OAd", true, System.Windows.Forms.DataSourceUpdateMode.Never));
            this.textBox1.Location = new System.Drawing.Point(597, 317);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(185, 20);
            this.textBox1.TabIndex = 3;
            this.textBox1.Visible = false;
            // 
            // bindingSource1
            // 
            this.bindingSource1.DataMember = "OgretmenOgrenci";
            this.bindingSource1.DataSource = this.ogrenciKayitDBDataSet;
            // 
            // ogrenciKayitDBDataSet
            // 
            this.ogrenciKayitDBDataSet.DataSetName = "OgrenciKayitDBDataSet";
            this.ogrenciKayitDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dgvOgrenciler
            // 
            this.dgvOgrenciler.AllowUserToAddRows = false;
            this.dgvOgrenciler.AllowUserToDeleteRows = false;
            this.dgvOgrenciler.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOgrenciler.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.OID,
            this.ONo,
            this.AdSoyad,
            this.ID_ID,
            this.Not1,
            this.Not2,
            this.Not3,
            this.PNotu,
            this.Ortalama,
            this.Durumu,
            this.Ad,
            this.Soyad});
            this.dgvOgrenciler.ContextMenuStrip = this.cMSOgrenci;
            this.dgvOgrenciler.GridColor = System.Drawing.SystemColors.Info;
            this.dgvOgrenciler.Location = new System.Drawing.Point(0, 0);
            this.dgvOgrenciler.MultiSelect = false;
            this.dgvOgrenciler.Name = "dgvOgrenciler";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.Azure;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvOgrenciler.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvOgrenciler.RowHeadersVisible = false;
            this.dgvOgrenciler.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgvOgrenciler.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvOgrenciler.Size = new System.Drawing.Size(591, 697);
            this.dgvOgrenciler.TabIndex = 0;
            this.dgvOgrenciler.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvOgrenciler_CellClick);
            // 
            // OID
            // 
            this.OID.DataPropertyName = "OID";
            this.OID.HeaderText = "OID";
            this.OID.Name = "OID";
            this.OID.ReadOnly = true;
            this.OID.Visible = false;
            // 
            // ONo
            // 
            this.ONo.DataPropertyName = "ONo";
            this.ONo.HeaderText = "Öğrenci No";
            this.ONo.Name = "ONo";
            this.ONo.ReadOnly = true;
            this.ONo.Width = 50;
            // 
            // AdSoyad
            // 
            this.AdSoyad.DataPropertyName = "AdSoyad";
            this.AdSoyad.HeaderText = "Adı Soyadı";
            this.AdSoyad.Name = "AdSoyad";
            this.AdSoyad.ReadOnly = true;
            this.AdSoyad.Width = 200;
            // 
            // ID_ID
            // 
            this.ID_ID.DataPropertyName = "ID";
            this.ID_ID.HeaderText = "ID";
            this.ID_ID.Name = "ID_ID";
            this.ID_ID.ReadOnly = true;
            this.ID_ID.Visible = false;
            // 
            // Not1
            // 
            this.Not1.DataPropertyName = "Not1";
            dataGridViewCellStyle1.Format = "N2";
            dataGridViewCellStyle1.NullValue = null;
            this.Not1.DefaultCellStyle = dataGridViewCellStyle1;
            this.Not1.HeaderText = "Not1";
            this.Not1.Name = "Not1";
            this.Not1.ReadOnly = true;
            this.Not1.Width = 45;
            // 
            // Not2
            // 
            this.Not2.DataPropertyName = "Not2";
            dataGridViewCellStyle2.Format = "N2";
            dataGridViewCellStyle2.NullValue = null;
            this.Not2.DefaultCellStyle = dataGridViewCellStyle2;
            this.Not2.HeaderText = "Not2";
            this.Not2.Name = "Not2";
            this.Not2.ReadOnly = true;
            this.Not2.Width = 45;
            // 
            // Not3
            // 
            this.Not3.DataPropertyName = "Not3";
            this.Not3.HeaderText = "Not3";
            this.Not3.Name = "Not3";
            this.Not3.ReadOnly = true;
            this.Not3.Width = 45;
            // 
            // PNotu
            // 
            this.PNotu.DataPropertyName = "PNotu";
            this.PNotu.HeaderText = "Proje Notu";
            this.PNotu.Name = "PNotu";
            this.PNotu.ReadOnly = true;
            this.PNotu.Width = 45;
            // 
            // Ortalama
            // 
            this.Ortalama.DataPropertyName = "Ortalama";
            this.Ortalama.HeaderText = "Ort";
            this.Ortalama.Name = "Ortalama";
            this.Ortalama.ReadOnly = true;
            this.Ortalama.Width = 45;
            // 
            // Durumu
            // 
            this.Durumu.DataPropertyName = "Durumu";
            this.Durumu.HeaderText = "Durumu";
            this.Durumu.Name = "Durumu";
            this.Durumu.ReadOnly = true;
            this.Durumu.Width = 50;
            // 
            // Ad
            // 
            this.Ad.DataPropertyName = "OAd";
            this.Ad.HeaderText = "Ad";
            this.Ad.Name = "Ad";
            this.Ad.ReadOnly = true;
            this.Ad.Visible = false;
            // 
            // Soyad
            // 
            this.Soyad.DataPropertyName = "OSoyad";
            this.Soyad.HeaderText = "Soyad";
            this.Soyad.Name = "Soyad";
            this.Soyad.ReadOnly = true;
            this.Soyad.Visible = false;
            // 
            // cMSOgrenci
            // 
            this.cMSOgrenci.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cMSOgrenciEkle,
            this.cMSOgrenciDegistir,
            this.cMSOgrenciSil});
            this.cMSOgrenci.Name = "cMSOgrenci";
            this.cMSOgrenci.Size = new System.Drawing.Size(115, 70);
            // 
            // cMSOgrenciEkle
            // 
            this.cMSOgrenciEkle.Name = "cMSOgrenciEkle";
            this.cMSOgrenciEkle.Size = new System.Drawing.Size(114, 22);
            this.cMSOgrenciEkle.Text = "Ekle";
            this.cMSOgrenciEkle.Click += new System.EventHandler(this.btnOgrenciEkleAc_Click);
            // 
            // cMSOgrenciDegistir
            // 
            this.cMSOgrenciDegistir.Name = "cMSOgrenciDegistir";
            this.cMSOgrenciDegistir.Size = new System.Drawing.Size(114, 22);
            this.cMSOgrenciDegistir.Text = "Değiştir";
            this.cMSOgrenciDegistir.Click += new System.EventHandler(this.btnOgrenciDegistir_Click);
            // 
            // cMSOgrenciSil
            // 
            this.cMSOgrenciSil.Name = "cMSOgrenciSil";
            this.cMSOgrenciSil.Size = new System.Drawing.Size(114, 22);
            this.cMSOgrenciSil.Text = "Çikar";
            this.cMSOgrenciSil.Click += new System.EventHandler(this.btnOgrenciSil_Click);
            // 
            // tpMesaj
            // 
            this.tpMesaj.BackColor = System.Drawing.Color.AntiqueWhite;
            this.tpMesaj.Controls.Add(this.dgvMesajlar);
            this.tpMesaj.Controls.Add(this.panel1);
            this.tpMesaj.Location = new System.Drawing.Point(4, 22);
            this.tpMesaj.Name = "tpMesaj";
            this.tpMesaj.Padding = new System.Windows.Forms.Padding(3);
            this.tpMesaj.Size = new System.Drawing.Size(852, 712);
            this.tpMesaj.TabIndex = 1;
            this.tpMesaj.Text = "Mesajlar";
            // 
            // dgvMesajlar
            // 
            this.dgvMesajlar.AllowUserToAddRows = false;
            this.dgvMesajlar.AllowUserToDeleteRows = false;
            this.dgvMesajlar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMesajlar.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Kimden,
            this.Konu,
            this.Mesaj});
            this.dgvMesajlar.Location = new System.Drawing.Point(6, 12);
            this.dgvMesajlar.Name = "dgvMesajlar";
            this.dgvMesajlar.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvMesajlar.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvMesajlar.RowHeadersVisible = false;
            this.dgvMesajlar.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvMesajlar.Size = new System.Drawing.Size(720, 320);
            this.dgvMesajlar.TabIndex = 1;
            // 
            // Kimden
            // 
            this.Kimden.DataPropertyName = "AdSoyad";
            this.Kimden.HeaderText = "Kimden";
            this.Kimden.Name = "Kimden";
            this.Kimden.ReadOnly = true;
            this.Kimden.Width = 150;
            // 
            // Konu
            // 
            this.Konu.DataPropertyName = "Konu";
            this.Konu.HeaderText = "Konu";
            this.Konu.Name = "Konu";
            this.Konu.ReadOnly = true;
            this.Konu.Width = 200;
            // 
            // Mesaj
            // 
            this.Mesaj.DataPropertyName = "Mesaj";
            this.Mesaj.HeaderText = "Mesaj";
            this.Mesaj.Name = "Mesaj";
            this.Mesaj.ReadOnly = true;
            this.Mesaj.Width = 300;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.btnKimeEkle);
            this.panel1.Controls.Add(this.lbKime);
            this.panel1.Controls.Add(this.cbKime);
            this.panel1.Location = new System.Drawing.Point(400, 426);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(364, 207);
            this.panel1.TabIndex = 0;
            // 
            // btnKimeEkle
            // 
            this.btnKimeEkle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKimeEkle.Location = new System.Drawing.Point(273, 22);
            this.btnKimeEkle.Name = "btnKimeEkle";
            this.btnKimeEkle.Size = new System.Drawing.Size(21, 23);
            this.btnKimeEkle.TabIndex = 3;
            this.btnKimeEkle.Text = ">";
            this.btnKimeEkle.UseVisualStyleBackColor = true;
            this.btnKimeEkle.Click += new System.EventHandler(this.btnKimeEkle_Click);
            // 
            // lbKime
            // 
            this.lbKime.FormattingEnabled = true;
            this.lbKime.Location = new System.Drawing.Point(301, 24);
            this.lbKime.Name = "lbKime";
            this.lbKime.Size = new System.Drawing.Size(204, 121);
            this.lbKime.TabIndex = 2;
            // 
            // cbKime
            // 
            this.cbKime.FormattingEnabled = true;
            this.cbKime.Location = new System.Drawing.Point(40, 24);
            this.cbKime.MaxDropDownItems = 15;
            this.cbKime.Name = "cbKime";
            this.cbKime.Size = new System.Drawing.Size(227, 21);
            this.cbKime.TabIndex = 0;
            // 
            // tpDuyuru
            // 
            this.tpDuyuru.BackColor = System.Drawing.Color.PaleTurquoise;
            this.tpDuyuru.Location = new System.Drawing.Point(4, 22);
            this.tpDuyuru.Name = "tpDuyuru";
            this.tpDuyuru.Padding = new System.Windows.Forms.Padding(3);
            this.tpDuyuru.Size = new System.Drawing.Size(852, 712);
            this.tpDuyuru.TabIndex = 2;
            this.tpDuyuru.Text = "Duyurular";
            // 
            // pOgrenci
            // 
            this.pOgrenci.Controls.Add(this.tabControl1);
            this.pOgrenci.Location = new System.Drawing.Point(869, 12);
            this.pOgrenci.Name = "pOgrenci";
            this.pOgrenci.Size = new System.Drawing.Size(806, 738);
            this.pOgrenci.TabIndex = 2;
            this.pOgrenci.Visible = false;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.ItemSize = new System.Drawing.Size(100, 18);
            this.tabControl1.Location = new System.Drawing.Point(3, 6);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(563, 729);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.SkyBlue;
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(555, 703);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Öğrenciler";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.AntiqueWhite;
            this.tabPage2.Controls.Add(this.panel4);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(555, 703);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Mesajlar";
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Location = new System.Drawing.Point(260, 53);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(351, 305);
            this.panel4.TabIndex = 0;
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Location = new System.Drawing.Point(61, 3);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(283, 295);
            this.panel5.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.PaleTurquoise;
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(555, 703);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Duyurular";
            // 
            // FormOgretmen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1171, 815);
            this.Controls.Add(this.pOgrenci);
            this.Controls.Add(this.pOgretmen);
            this.Name = "FormOgretmen";
            this.Text = "FormOgretmen";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormOgretmen_FormClosed);
            this.Load += new System.EventHandler(this.FormOgretmen_Load);
            this.pOgretmen.ResumeLayout(false);
            this.tcOgretmen.ResumeLayout(false);
            this.tpOgrenci.ResumeLayout(false);
            this.tpOgrenci.PerformLayout();
            this.pOgrenciButon.ResumeLayout(false);
            this.pOgrenciButon.PerformLayout();
            this.gbOgrenciKayit.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ogrenciKayitDBDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOgrenciler)).EndInit();
            this.cMSOgrenci.ResumeLayout(false);
            this.tpMesaj.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvMesajlar)).EndInit();
            this.panel1.ResumeLayout(false);
            this.pOgrenci.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pOgretmen;
        private System.Windows.Forms.TabControl tcOgretmen;
        private System.Windows.Forms.TabPage tpOgrenci;
        private System.Windows.Forms.TabPage tpMesaj;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TabPage tpDuyuru;
        private System.Windows.Forms.Panel pOgrenci;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView dgvOgrenciler;
        private System.Windows.Forms.BindingSource bindingSource1;
        private OgrenciKayitDBDataSet ogrenciKayitDBDataSet;
        private System.Windows.Forms.ComboBox cbKime;
        private System.Windows.Forms.ListBox lbKime;
        private System.Windows.Forms.Button btnKimeEkle;
        private System.Windows.Forms.DataGridView dgvMesajlar;
        private System.Windows.Forms.DataGridViewTextBoxColumn Kimden;
        private System.Windows.Forms.DataGridViewTextBoxColumn Konu;
        private System.Windows.Forms.DataGridViewTextBoxColumn Mesaj;
        private System.Windows.Forms.Button btnOgrenciEkleAc;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.GroupBox gbOgrenciKayit;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnNumaraVer;
        private System.Windows.Forms.TextBox tbOSoyad;
        private System.Windows.Forms.TextBox tbOAd;
        private System.Windows.Forms.TextBox tbONo;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pOgrenciButon;
        private System.Windows.Forms.Button btnKayit;
        private System.Windows.Forms.Button btnVazgec;
        private System.Windows.Forms.Button btnOgrenciDegistir;
        private System.Windows.Forms.ContextMenuStrip cMSOgrenci;
        private System.Windows.Forms.ToolStripMenuItem cMSOgrenciEkle;
        private System.Windows.Forms.ToolStripMenuItem cMSOgrenciDegistir;
        private System.Windows.Forms.ToolStripMenuItem cMSOgrenciSil;
        private System.Windows.Forms.Button btnOgrenciSil;
        private System.Windows.Forms.Button btnNotGir;
        private System.Windows.Forms.CheckBox cbNot3;
        private System.Windows.Forms.CheckBox cbNot2;
        private System.Windows.Forms.CheckBox cbNot1;
        private System.Windows.Forms.CheckBox cbNotProje;
        private System.Windows.Forms.Button btnNotKayit;
        private System.Windows.Forms.Button btnNotVazgec;
        private System.Windows.Forms.DataGridViewTextBoxColumn OID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ONo;
        private System.Windows.Forms.DataGridViewTextBoxColumn AdSoyad;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Not1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Not2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Not3;
        private System.Windows.Forms.DataGridViewTextBoxColumn PNotu;
        private System.Windows.Forms.DataGridViewTextBoxColumn Ortalama;
        private System.Windows.Forms.DataGridViewTextBoxColumn Durumu;
        private System.Windows.Forms.DataGridViewTextBoxColumn Ad;
        private System.Windows.Forms.DataGridViewTextBoxColumn Soyad;
    }
}