﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace form_kitaplar
{
    public partial class frmKitaplar : Form
    {
        public frmKitaplar()
        {
            InitializeComponent();
        }
        SqlConnection cn = new SqlConnection(@"Data Source=LAB02-12;Initial Catalog=Kitaplar;Integrated Security=True");

        private void frmKitaplar_Load(object sender, EventArgs e)
        {
            cn.Open();

        }

        private void btnliste_Click(object sender, EventArgs e)
        {
            listele();
        }
        void listele()
        {
            cn.Close();
            cn.Open();
            SqlCommand scmd = new SqlCommand("SELECT  [kitapad],[yazar],[sayfa],[fiyat],[yayinevi], dbo.turler.turad FROM  dbo.kitap INNER JOIN dbo.turler ON dbo.kitap.turid = dbo.turler.turid", cn);
            SqlDataAdapter sadp = new SqlDataAdapter(scmd);
            DataTable dtkitap = new DataTable();
            sadp.Fill(dtkitap);
            dgwkitaplar.DataSource = dtkitap;
        }

        private void btnkayit_Click(object sender, EventArgs e)
        {
            cn.Close();
            cn.Open();
            String v = "'" + tbkitapadi.Text + "','" + tbyazar.Text + "'," + tbsayfa.Text + "," + tbfiyat.Text + ",'" + cbyayinevi.Text + "'," + cbturu.Text + ")";
            MessageBox.Show(v);
            SqlCommand scmd = new SqlCommand("INSERT INTO dbo.kitap (kitapad,yazar,sayfa,fiyat,yayinevi,turid) VALUES ("+v, cn);
            scmd.ExecuteNonQuery();
        }
    }
}
