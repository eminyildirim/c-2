﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SERVIS
{
    public partial class frmGIRIS : Form
    {
        public int sifredene = 0;
        public frmGIRIS()
        {

            InitializeComponent();
        }

        private void btnGiris_Click(object sender, EventArgs e)
        {
            if (tbUser.Text == "admin" || tbUser.Text == "ADMIN")
            {
                if (tbSifre.Text == "123")
                {   
                    frmSrvGiris frm = new frmSrvGiris();
                    frm.kullaniciAdi = tbUser.Text;
                    frm.sifre = tbSifre.Text;
                    frm.Show();
                    this.Hide();
                }
                else
                {
                    sifredene++;
                    if (sifredene > 2)
                    {
                        MessageBox.Show("Hatalı giriş Denemesi");
                        Application.Exit();
                    }
                    else
                    {
                        MessageBox.Show("hatalı Şifre");
                        tbSifre.Focus();
                    }

                }
            }
            else
            {
                sifredene++;
                if (sifredene > 2)
                {
                    MessageBox.Show("Hatalı Kullanıcı Denemesi");
                    Application.Exit();
                }
                else
                {
                    MessageBox.Show("Hatalı Kullanıcı");
                    tbUser.Focus();
                }
            }

        }
    }
}
