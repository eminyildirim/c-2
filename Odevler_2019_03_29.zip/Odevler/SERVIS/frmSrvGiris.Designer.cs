﻿namespace SERVIS
{
    partial class frmSrvGiris
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.luser = new System.Windows.Forms.Label();
            this.lsifre = new System.Windows.Forms.Label();
            this.btnEkle = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lZaman = new System.Windows.Forms.Label();
            this.btnTemizle = new System.Windows.Forms.Button();
            this.gbKayit = new System.Windows.Forms.GroupBox();
            this.btnTest = new System.Windows.Forms.Button();
            this.tbMFiyat = new System.Windows.Forms.TextBox();
            this.tbRYapilan = new System.Windows.Forms.RichTextBox();
            this.tbMKm = new System.Windows.Forms.MaskedTextBox();
            this.cbModel = new System.Windows.Forms.ComboBox();
            this.cbMarka = new System.Windows.Forms.ComboBox();
            this.tbMTel = new System.Windows.Forms.MaskedTextBox();
            this.tbMusPlaka = new System.Windows.Forms.TextBox();
            this.tbMusSoyad = new System.Windows.Forms.TextBox();
            this.tbMusAdi = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbListe = new System.Windows.Forms.ListBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.pMTasi = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripComboBox1 = new System.Windows.Forms.ToolStripComboBox();
            this.gbKayit.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // luser
            // 
            this.luser.AutoSize = true;
            this.luser.Location = new System.Drawing.Point(519, 20);
            this.luser.Name = "luser";
            this.luser.Size = new System.Drawing.Size(41, 13);
            this.luser.TabIndex = 15;
            this.luser.Text = "label10";
            this.luser.Visible = false;
            // 
            // lsifre
            // 
            this.lsifre.AutoSize = true;
            this.lsifre.Location = new System.Drawing.Point(519, 33);
            this.lsifre.Name = "lsifre";
            this.lsifre.Size = new System.Drawing.Size(41, 13);
            this.lsifre.TabIndex = 16;
            this.lsifre.Text = "label11";
            this.lsifre.Visible = false;
            // 
            // btnEkle
            // 
            this.btnEkle.Location = new System.Drawing.Point(227, 411);
            this.btnEkle.Name = "btnEkle";
            this.btnEkle.Size = new System.Drawing.Size(75, 23);
            this.btnEkle.TabIndex = 20;
            this.btnEkle.Text = "&EKLE";
            this.btnEkle.UseVisualStyleBackColor = true;
            this.btnEkle.Click += new System.EventHandler(this.btnEkle_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lZaman
            // 
            this.lZaman.AutoSize = true;
            this.lZaman.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lZaman.Location = new System.Drawing.Point(576, 9);
            this.lZaman.Name = "lZaman";
            this.lZaman.Size = new System.Drawing.Size(49, 13);
            this.lZaman.TabIndex = 21;
            this.lZaman.Text = "123333";
            // 
            // btnTemizle
            // 
            this.btnTemizle.Location = new System.Drawing.Point(321, 411);
            this.btnTemizle.Name = "btnTemizle";
            this.btnTemizle.Size = new System.Drawing.Size(75, 23);
            this.btnTemizle.TabIndex = 23;
            this.btnTemizle.Text = "Temizle";
            this.btnTemizle.UseVisualStyleBackColor = true;
            this.btnTemizle.Click += new System.EventHandler(this.btnTemizle_Click);
            // 
            // gbKayit
            // 
            this.gbKayit.Controls.Add(this.btnTest);
            this.gbKayit.Controls.Add(this.tbMFiyat);
            this.gbKayit.Controls.Add(this.btnTemizle);
            this.gbKayit.Controls.Add(this.tbRYapilan);
            this.gbKayit.Controls.Add(this.tbMKm);
            this.gbKayit.Controls.Add(this.cbModel);
            this.gbKayit.Controls.Add(this.btnEkle);
            this.gbKayit.Controls.Add(this.cbMarka);
            this.gbKayit.Controls.Add(this.tbMTel);
            this.gbKayit.Controls.Add(this.tbMusPlaka);
            this.gbKayit.Controls.Add(this.tbMusSoyad);
            this.gbKayit.Controls.Add(this.tbMusAdi);
            this.gbKayit.Controls.Add(this.label9);
            this.gbKayit.Controls.Add(this.label8);
            this.gbKayit.Controls.Add(this.label7);
            this.gbKayit.Controls.Add(this.label6);
            this.gbKayit.Controls.Add(this.label5);
            this.gbKayit.Controls.Add(this.label4);
            this.gbKayit.Controls.Add(this.label3);
            this.gbKayit.Controls.Add(this.label2);
            this.gbKayit.Controls.Add(this.label1);
            this.gbKayit.Location = new System.Drawing.Point(12, 36);
            this.gbKayit.Name = "gbKayit";
            this.gbKayit.Size = new System.Drawing.Size(541, 449);
            this.gbKayit.TabIndex = 24;
            this.gbKayit.TabStop = false;
            this.gbKayit.Text = "[ Servis Bilgi Kayıt ]";
            // 
            // btnTest
            // 
            this.btnTest.Location = new System.Drawing.Point(430, 411);
            this.btnTest.Name = "btnTest";
            this.btnTest.Size = new System.Drawing.Size(83, 23);
            this.btnTest.TabIndex = 36;
            this.btnTest.Text = "TEST DATA";
            this.btnTest.UseVisualStyleBackColor = true;
            this.btnTest.Click += new System.EventHandler(this.btnTest_Click);
            // 
            // tbMFiyat
            // 
            this.tbMFiyat.Location = new System.Drawing.Point(117, 414);
            this.tbMFiyat.Name = "tbMFiyat";
            this.tbMFiyat.Size = new System.Drawing.Size(74, 20);
            this.tbMFiyat.TabIndex = 35;
            this.tbMFiyat.Tag = "8";
            this.tbMFiyat.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.tbMFiyat.Leave += new System.EventHandler(this.tbMFiyat_Leave);
            // 
            // tbRYapilan
            // 
            this.tbRYapilan.Location = new System.Drawing.Point(117, 310);
            this.tbRYapilan.Name = "tbRYapilan";
            this.tbRYapilan.Size = new System.Drawing.Size(410, 92);
            this.tbRYapilan.TabIndex = 34;
            this.tbRYapilan.Tag = "7";
            this.tbRYapilan.Text = "";
            // 
            // tbMKm
            // 
            this.tbMKm.Location = new System.Drawing.Point(117, 276);
            this.tbMKm.Mask = "000000";
            this.tbMKm.Name = "tbMKm";
            this.tbMKm.Size = new System.Drawing.Size(48, 20);
            this.tbMKm.TabIndex = 33;
            this.tbMKm.Tag = "6";
            this.tbMKm.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // cbModel
            // 
            this.cbModel.FormattingEnabled = true;
            this.cbModel.Items.AddRange(new object[] {
            "2005",
            "2006",
            "2007",
            "2008",
            "2009",
            "2010",
            "2011",
            "2012",
            "2013",
            "2014",
            "2015",
            "2016",
            "2017",
            "2018",
            "2019"});
            this.cbModel.Location = new System.Drawing.Point(117, 230);
            this.cbModel.Name = "cbModel";
            this.cbModel.Size = new System.Drawing.Size(121, 21);
            this.cbModel.TabIndex = 32;
            this.cbModel.Tag = "5";
            // 
            // cbMarka
            // 
            this.cbMarka.FormattingEnabled = true;
            this.cbMarka.Items.AddRange(new object[] {
            "Renault",
            "Opel",
            "Ford",
            "Mersedes",
            "Fiat"});
            this.cbMarka.Location = new System.Drawing.Point(117, 172);
            this.cbMarka.Name = "cbMarka";
            this.cbMarka.Size = new System.Drawing.Size(161, 21);
            this.cbMarka.TabIndex = 31;
            this.cbMarka.Tag = "4";
            // 
            // tbMTel
            // 
            this.tbMTel.Location = new System.Drawing.Point(117, 92);
            this.tbMTel.Mask = "(999) 000-0000";
            this.tbMTel.Name = "tbMTel";
            this.tbMTel.Size = new System.Drawing.Size(100, 20);
            this.tbMTel.TabIndex = 29;
            this.tbMTel.Tag = "2";
            // 
            // tbMusPlaka
            // 
            this.tbMusPlaka.Location = new System.Drawing.Point(117, 133);
            this.tbMusPlaka.MaxLength = 8;
            this.tbMusPlaka.Name = "tbMusPlaka";
            this.tbMusPlaka.Size = new System.Drawing.Size(100, 20);
            this.tbMusPlaka.TabIndex = 30;
            this.tbMusPlaka.Tag = "3";
            // 
            // tbMusSoyad
            // 
            this.tbMusSoyad.Location = new System.Drawing.Point(117, 57);
            this.tbMusSoyad.MaxLength = 25;
            this.tbMusSoyad.Name = "tbMusSoyad";
            this.tbMusSoyad.Size = new System.Drawing.Size(205, 20);
            this.tbMusSoyad.TabIndex = 28;
            this.tbMusSoyad.Tag = "1";
            // 
            // tbMusAdi
            // 
            this.tbMusAdi.Location = new System.Drawing.Point(117, 21);
            this.tbMusAdi.MaxLength = 25;
            this.tbMusAdi.Name = "tbMusAdi";
            this.tbMusAdi.Size = new System.Drawing.Size(205, 20);
            this.tbMusAdi.TabIndex = 27;
            this.tbMusAdi.Tag = "0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(23, 414);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(32, 13);
            this.label9.TabIndex = 26;
            this.label9.Text = "Fiyat:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(20, 310);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(72, 13);
            this.label8.TabIndex = 25;
            this.label8.Text = "Yapılan İşlem:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(19, 276);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(25, 13);
            this.label7.TabIndex = 24;
            this.label7.Text = "Km:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(19, 230);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(36, 13);
            this.label6.TabIndex = 23;
            this.label6.Text = "Model";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(19, 181);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 13);
            this.label5.TabIndex = 22;
            this.label5.Text = "Marka:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(19, 140);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 13);
            this.label4.TabIndex = 21;
            this.label4.Text = "Plaka:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(19, 100);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 13);
            this.label3.TabIndex = 20;
            this.label3.Text = "Tel Numarası:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 13);
            this.label2.TabIndex = 19;
            this.label2.Text = "Müşteri Soyadı:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 13);
            this.label1.TabIndex = 18;
            this.label1.Text = "Müşteri Adı:";
            // 
            // lbListe
            // 
            this.lbListe.ContextMenuStrip = this.contextMenuStrip1;
            this.lbListe.FormattingEnabled = true;
            this.lbListe.Location = new System.Drawing.Point(579, 65);
            this.lbListe.Name = "lbListe";
            this.lbListe.Size = new System.Drawing.Size(222, 420);
            this.lbListe.TabIndex = 25;
            this.lbListe.DoubleClick += new System.EventHandler(this.lbListe_DoubleClick);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.AllowDrop = true;
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator1,
            this.pMTasi,
            this.toolStripSeparator2,
            this.toolStripComboBox1});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(182, 87);
            this.contextMenuStrip1.Click += new System.EventHandler(this.lbListe_DoubleClick);
            // 
            // pMTasi
            // 
            this.pMTasi.Name = "pMTasi";
            this.pMTasi.Size = new System.Drawing.Size(152, 22);
            this.pMTasi.Text = "Göster";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(149, 6);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(149, 6);
            // 
            // toolStripComboBox1
            // 
            this.toolStripComboBox1.AutoToolTip = true;
            this.toolStripComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.toolStripComboBox1.Items.AddRange(new object[] {
            "Göster1",
            "Deneme1",
            "ppmenu1"});
            this.toolStripComboBox1.Name = "toolStripComboBox1";
            this.toolStripComboBox1.Overflow = System.Windows.Forms.ToolStripItemOverflow.Always;
            this.toolStripComboBox1.Size = new System.Drawing.Size(121, 23);
            this.toolStripComboBox1.SelectedIndexChanged += new System.EventHandler(this.toolStripComboBox1_SelectedIndexChanged);
            // 
            // frmSrvGiris
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(867, 538);
            this.Controls.Add(this.lbListe);
            this.Controls.Add(this.gbKayit);
            this.Controls.Add(this.lZaman);
            this.Controls.Add(this.lsifre);
            this.Controls.Add(this.luser);
            this.Name = "frmSrvGiris";
            this.Tag = "OTO BAKIM SERVİS KAYIT";
            this.Text = "OTO BAKIM SERVİS KAYIT";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmSrvGiris_FormClosed);
            this.Load += new System.EventHandler(this.frmSrvGiris_Load);
            this.gbKayit.ResumeLayout(false);
            this.gbKayit.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label luser;
        private System.Windows.Forms.Label lsifre;
        private System.Windows.Forms.Button btnEkle;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lZaman;
        private System.Windows.Forms.Button btnTemizle;
        private System.Windows.Forms.GroupBox gbKayit;
        private System.Windows.Forms.TextBox tbMFiyat;
        private System.Windows.Forms.RichTextBox tbRYapilan;
        private System.Windows.Forms.MaskedTextBox tbMKm;
        private System.Windows.Forms.ComboBox cbModel;
        private System.Windows.Forms.ComboBox cbMarka;
        private System.Windows.Forms.MaskedTextBox tbMTel;
        private System.Windows.Forms.TextBox tbMusPlaka;
        private System.Windows.Forms.TextBox tbMusSoyad;
        private System.Windows.Forms.TextBox tbMusAdi;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lbListe;
        private System.Windows.Forms.Button btnTest;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem pMTasi;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBox1;
    }
}