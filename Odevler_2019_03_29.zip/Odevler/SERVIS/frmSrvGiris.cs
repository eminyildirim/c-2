﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace SERVIS
{
    public partial class frmSrvGiris : Form
    {
        public frmSrvGiris()
        {
            InitializeComponent();
        }
        public string kullaniciAdi { get; set; }
        public string sifre { get; set; }
        public List<String> Musteriler = new List<String>();
        private void frmSrvGiris_Load(object sender, EventArgs e)
        {
            luser.Text = kullaniciAdi;
            lsifre.Text = sifre;
            this.Text = this.Tag + " (" + kullaniciAdi + ")";
            lZaman.Text = DateTime.Now.ToString();
            frmGIRIS frm = new frmGIRIS();
            frm.Close();
            cbModel.SelectedIndex = cbModel.Items.Count - 1;
            cbMarka.SelectedIndex = 0;
        }

        private void frmSrvGiris_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lZaman.Text = DateTime.Now.ToString();
        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            if (tbMusAdi.Text != "" && tbMusSoyad.Text != "" && tbMTel.Text != "" && tbMusPlaka.Text != "" && tbMKm.Text != "" && tbMFiyat.Text != "" && tbRYapilan.Text != "" && cbMarka.Text != "" && cbModel.Text != "")
            {
                String[] x = new String[] { tbMusAdi.Text, tbMusSoyad.Text, tbMTel.Text, tbMusPlaka.Text, cbMarka.Text, cbModel.Text, tbMKm.Text, tbRYapilan.Text, tbMFiyat.Text };
                Musteriler.Add(String.Join("\r\n", x));
                // lbData.Items.Add(String.Join("\r\n", x));
                lbListe.Items.Add(tbMusPlaka.Text+" "+tbMusAdi.Text+" "+tbMusSoyad.Text);


            }
            else
            {
                MessageBox.Show("Bilgileri Tamam layınız");
            }
        }

        private void btnTemizle_Click(object sender, EventArgs e)
        {
            tbMusAdi.Clear(); tbMusSoyad.Clear(); tbMTel.Clear(); tbMusPlaka.Clear(); tbMKm.Clear(); tbMFiyat.Clear(); tbRYapilan.Clear();

        }

        private void listBox1_DoubleClick(object sender, EventArgs e)
        {
 
        }

        private void btnTest_Click(object sender, EventArgs e)
        {
            tbMusAdi.Text = "EMİN";
            tbMusSoyad.Text = "YILDIRIM";
            tbMTel.Text = "1231234567";
            tbMusPlaka.Text = "34AA1234";
            tbMKm.Text = "13345";
            tbMFiyat.Text = "545,50";

        }

        private void tbMFiyat_Leave(object sender, EventArgs e)
        {

            Double d;
            String x = tbMFiyat.Text.Replace(" ", "");
            Boolean kontrol = Double.TryParse(x, out d);
            if (!kontrol)
            {
                tbMFiyat.Focus();
            }
            else
            {
               // tbMFiyat.Text = d.ToString();
            }
                
        }

        private void lbListe_DoubleClick(object sender, EventArgs e)
        {
            if (lbListe.Items.Count > 0 && lbListe.SelectedIndex > -1)
            {
                // String[] x = Regex.Split(lbData.Items[lbListe.SelectedIndex].ToString(), "\r\n");
                String[] x = Regex.Split(Musteriler[lbListe.SelectedIndex].ToString(), "\r\n");
                int i = 0;

                foreach (var item in gbKayit.Controls)
                {

                    if (item is TextBox)
                    {
                        i = int.Parse((item as TextBox).Tag.ToString());
                        (item as TextBox).Text = x[i];

                    }
                    else
                    if (item is MaskedTextBox)
                    {
                        i = int.Parse((item as MaskedTextBox).Tag.ToString());
                        (item as MaskedTextBox).Text = x[i];
                    }
                    else
                    if (item is ComboBox)
                    {
                        i = int.Parse((item as ComboBox).Tag.ToString());
                        (item as ComboBox).Text = x[i];

                    }
                    else
                    if (item is RichTextBox)
                    {
                        i = int.Parse((item as RichTextBox).Tag.ToString());
                        (item as RichTextBox).Text = x[i];

                    }
                }
            }
        }

        private void toolStripComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            MessageBox.Show(toolStripComboBox1.SelectedItem.ToString());
        }
    }
}
